# 02 — Existing Frontend Architecture

All paths relative to `mash-unified/frontend/`. Line numbers reference the current master (`657546c`).

## 1. Stack identification

| Concern | Technology | Evidence |
|---|---|---|
| Framework | **Next.js 16.2.12** (App Router, Turbopack) | `package.json`, `next dev` output |
| Language | **TypeScript 5** (strict-ish; several `any` escapes) | `tsconfig.json` |
| UI runtime | **React 19.2.4** / react-dom 19.2.4 | `package.json` |
| Styling | **Tailwind CSS 4** via `@tailwindcss/postcss`; `@theme` + `@custom-variant dark` | `postcss.config.mjs`, `src/app/globals.css` |
| Component primitives | **shadcn/ui-style** local components on **Radix** (`dialog`, `dropdown-menu`, `label`, `separator`, `slot`, `tabs`, `tooltip`) | `src/components/ui/*` |
| Variant utility | `class-variance-authority` + `clsx` + `tailwind-merge` (`cn()` in `src/lib/utils.ts`) | `ui/button.tsx` etc. |
| Icons | **lucide-react** 1.28 (+ two hand-drawn SVG icons in `FileIcon.tsx`: Python, React atom) | throughout |
| Markdown | `react-markdown` 10 + `remark-gfm` + `remark-math` + `rehype-katex` | `AssistantMessage.tsx`, `SafeFileViewer.tsx` |
| Math | KaTeX 0.18 (`throwOnError:false, errorColor:'#71717a', strict:false`) | `AssistantMessage.tsx` |
| Diagrams | `mermaid` 11.17, dynamically imported (`ssr:false`), `securityLevel:'strict'`, SVG sanitizer | `MermaidRenderer.tsx` |
| Code editor | `@monaco-editor/react` 4.7 (viewer only in right sidebar) | `SafeFileViewer.tsx` |
| Spreadsheets | `@univerjs/presets` 0.25 (read-only sheets core preset) | `UniverExcelViewerInner.tsx` |
| Animation | **None of** framer-motion/react-spring. Tailwind `animate-in` utilities + hand-rolled keyframes (`loadingEllipsis`) + CSS transitions | `globals.css` |
| State | React `useState/useRef` + **module-level stores** (no Redux/Zustand/Context) | see §4 |
| API layer | Hand-rolled `fetch` wrapper (`safeFetch`) + hand-rolled SSE reader | `src/utils/apiClient.ts` |
| Tests | `eslint` 9, `fast-check` 4 (property fuzzing of session store), scenario scripts in `tests/` | `tests/fuzz_session_store.ts` |

## 2. Application architecture map (actual)

```text
MASh Frontend (Next.js, single route "/")
│
├── App shell — src/app/page.tsx (400 L, "use client")
│   ├── Fake desktop window frame (title bar: MASH / File / View / Window / min-max-close)
│   ├── Theme state (isDark, default true) → sets <html>.dark + data-theme
│   ├── Auth gate — DEFAULT_LOCAL_USER fallback → DesktopSignInView (Google OAuth polling)
│   ├── ErrorBoundary (scope="workbench-root") with "Restore Workspace" fallback
│   ├── Layout state: sidebarOpen/Width(260), rightSidebarOpen/Maximized, historyActive, settingsOpen/Tab
│   ├── Session selection: selectedSessionId/Title/Repo + archivedSessionIds (localStorage)
│   └── TooltipProvider (delayDuration 150ms) wrapping the workbench
│
├── Navigation
│   ├── Sidebar.tsx (1101 L) — logo, New Conversation, Conversation History,
│   │   Pinned / Workspaces (projects) / Conversations sections, context menu,
│   │   drag-resize 220–450px, Settings footer, 5s polling
│   ├── Chat toolbar (in page.tsx) — breadcrumb (Repo › Session), PanelLeft/Right,
│   │   back/forward, PanelRight toggle when right sidebar closed
│   └── ConversationHistory.tsx (333 L) — full-page list, search, Active/Archived tabs
│
├── Chat — ChatCanvas.tsx (426 L)
│   ├── Welcome/empty state ("MASH Statutory Audit AI")
│   ├── Turn feed (buildTurns → Turn[]), 100-live-turn DOM window, pagination pills
│   ├── Queued message card, QuotaBanner, ScrollToBottomButton
│   └── ChatComposer.tsx (330 L) — textarea, attachments, send/queue/stop
│
├── Composer — ChatComposer (Enter send / Shift+Enter newline, paste+drag-drop upload,
│   300ms double-send lock, auto-resize ≤220px, attachment chips)
│
├── Agent activity — TaskWorkLogAccordion.tsx (1074 L)
│   ├── "Worked for Xs" collapsed header; streaming "Thinking for Xs…" + animated dots
│   ├── Tool rows: command / file_read / edit / search / subagent / timer / task / other
│   ├── FilePill, durations, expandable command console with output
│   └── Group cards (command_group / exploration_group / edit_group) — implemented but DISABLED
│
├── Tool calls — parsed from steps/tools (ToolCallItem), rendered in accordion
│
├── File handling — uploads (POST /api/uploads/{sid}), file pills in markdown,
│   FilesChangedDrawer.tsx (edited-file list, +/− counts), FileIcon.tsx (brand colors)
│
├── Artifact handling — lib/artifactExtraction.ts (regex classification from tool args
│   + markdown links), ArtifactCard.tsx, canonical-group suppression across turns
│
├── Viewer — RightSidebar.tsx (1285 L)
│   ├── Explorer mode: Working Papers list + Audit Procedures (background tasks)
│   ├── Editor mode: multi-tab (file/image/terminal), breadcrumb, Preview/Raw pill
│   ├── SafeFileViewer.tsx (551 L) — image/Excel(Univer)/PDF(embed)/markdown/code(Monaco)/raw
│   └── Terminal viewer — SSE live log with line-numbered gutter
│
├── Settings — SettingsModal.tsx (852 L, portal) — Appearance (theme engine:
│   6 presets + custom colors → CSS vars), Projects, Account (toggles, plan, sign-out)
│
├── Authentication — DesktopSignInView.tsx (189 L) — Google OAuth via cloud gateway,
│   polls /api/auth/me every 1500ms up to 3 min; page.tsx falls back to local user
│
├── API communication — utils/apiClient.ts (1028 L) — 30 functions, safeFetch
│   (1 retry, 350ms, GET/HEAD only, synthetic 503), streamQuery (SSE reader),
│   title generation, deleted-session tombstones, LRU file-content cache (25)
│
└── Global state — hooks/useChatStream.ts (1182 L)
    ├── Module-level sessionStore Map<sid, SessionRuntimeState> (LRU 25)
    ├── Store pub/sub (subscribeToSessionStore) for cross-hook reactivity
    ├── rAF-batched token/thought buffer flush
    └── useScrollToBottom (velocity-aware autoscroll), useIsDarkMode (MutationObserver)
```

## 3. Backend integration (connector)

- **Base URL:** `process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000"` (apiClient.ts:5).
- **Streaming:** `POST /stream` with `{session_id, messages: "<text>", context}` → SSE `data: {json}\n\n` frames. The connector (`connector/app/routers/chat.py:170-296`) resolves workspace/sandbox bindings, then delegates to NexAU's `SSETransportServer.handle_streaming_request`. Client disconnect → agent force-stopped server-side; post-stream, `last_user_view_time` is synced (powers the unread dot).
- **Persistence:** server-side SQLite (WAL) via the connector; the client refetches transcripts (`GET /sessions/{id}/transcript?limit=100&offset=`) and re-parses raw lines with `parseTranscriptLines`.
- **Desktop/runtime communication:** no Electron/Tauri bridge in the running app; the "window frame" is purely visual. `Sidebar.tsx` opportunistically calls `window.electronAPI.selectFolder` / `showDirectoryPicker` when present, falling back to backend folder pickers.
- **Auth:** no Authorization headers, no token storage — session/cookie-implied identity via `GET /api/auth/me`; OAuth loopback flow opens `${NEXT_PUBLIC_GATEWAY_URL||https://api.mash.ai}/v1/auth/oauth/google` in a browser tab and polls.

## 4. State management (actual)

1. **Local component state** — the default everywhere.
2. **Module-level singletons** (the interesting part):
   - `sessionStore: Map<string, SessionRuntimeState>` (useChatStream.ts:42) — chatMessages, activeTurnId, buffers, abortController, drafts, unread — survives unmounts and session switches; LRU eviction at 25 with streaming/viewing protection.
   - `storeListeners: Set<() => void>` — pub/sub so Sidebar re-renders on queue/stream changes without prop drilling.
   - `messageArtifactCache: WeakMap<Message, ArtifactItem[]>` — artifact extraction memoized per message object identity.
   - `globalRightSidebarMemory: Map<sessionId, {tabs, activeId, mode}>` — per-session viewer tab memory (in-memory only).
   - `deletedSessionIds: Set<string>` — tombstones so the 5s sidebar poll can't resurrect deleted sessions.
   - `fileContentMemoryCache: Map` (LRU 25) + `inFlightFileFetches` dedup — file content caching.
   - localStorage: `nexau_cached_sessions`, `nexau_cached_projects`, `nexau_pinned_session_ids`, `nexau_archived_session_ids`, `mash_theme_settings`, `mash_telemetry`, `mash_marketing`.
3. **Prop drilling** from `page.tsx` → Sidebar/ChatCanvas/RightSidebar (with `useCallback` stabilization, "ponytail" comments).

## 5. Streaming implementation (summary — full detail in 05/06)

- Raw `fetch` POST → `response.body.getReader()` → `TextDecoder('utf-8')` → split on `"\n\n"` → parse frames starting with `data:` → `JSON.parse` → dispatch on `event.type.toUpperCase()`.
- Six normalized callbacks: `onToken`, `onThought`, `onThinkingEnd`, `onToolCall`, `onTasks`, `onError`.
- Buffers flushed per animation frame; abort via `AbortController`; stall watchdog 300000ms; server keepalives every 15s.

## 6. Error handling

- `safeFetch` normalizes network failure → synthetic `503 {"error":"Backend unavailable"}`.
- `streamQuery` classifies: abort (silent), offline, fetch-type, stall-timeout, HTTP error with `formatErrorMessage` mapping 404/429/401 → friendly strings, truncating to 197 chars.
- Every API function swallows errors to safe defaults + `console.warn`.
- Two `ErrorBoundary` scopes in production tree: `workbench-root` (full recovery UI) and `safe-file-viewer`; the class supports `fallbackRender` for message-level islands (comment suggests intended per-message use, only file viewer uses it today).
- React error surfaced in console during research: "Attempted to synchronously unmount a root while React was already rendering" (Univer/Mermaid dynamic imports) — see 13-performance-findings.

## 7. Persistence / state restoration

- Session transcripts restored from server; 100-line pages with scroll-anchored prepend.
- Composer drafts persisted per-session inside `sessionStore.inputPrompt` (memory only — lost on reload).
- Sidebar width **not** persisted (resets to 260px on reload — documented gap).
- Right-sidebar tabs persist per session in memory only.
- Theme + toggles + pin/archive lists persist to localStorage (mixed `nexau_`/`mash_` prefixes).
