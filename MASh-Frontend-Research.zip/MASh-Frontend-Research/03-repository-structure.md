# 03 — Repository Structure

Repository: `Mash-Unified` @ master (`657546c`). The **frontend under research** is `frontend/`; `connector/` is its backend; `NexAU/` is the agent runtime (out of scope, referenced where relevant).

```text
Mash-Unified/
├── RUN_GUIDE.md                  # Deploy/run instructions (Windows-centric launchers)
├── run_mash.bat / start_mash.ps1 # One-click launchers (connector :8000 + frontend :3000)
├── docker-compose.yml            # Container orchestration
├── requirements.txt              # Python deps for connector + NexAU
│
├── frontend/                     # ◀ THE FRONTEND UNDER RESEARCH (~13.3K lines)
│   ├── package.json              # Next 16.2.12, React 19.2.4, Tailwind 4, Radix, Univer, Monaco…
│   ├── next.config.ts            # (default; optimizePackageImports experiment)
│   ├── postcss.config.mjs        # @tailwindcss/postcss
│   ├── tsconfig.json
│   ├── eslint.config.mjs
│   ├── AGENTS.md                 # Next.js 16 breaking-changes warning for coding agents
│   ├── CLAUDE.md
│   ├── README.md                 # stock create-next-app README (not MASh-specific)
│   ├── .openclaw_min.mjs / .openclaw_parse.mjs / .openclaw_run_mermaid.mjs   # tooling scripts
│   ├── test_right_sidebar_logic.cjs          # node-based logic test
│   ├── tests/
│   │   ├── fuzz_session_store.ts             # fast-check property tests on session store
│   │   └── test_chat_scenarios.mjs           # scripted chat scenario tests
│   │
│   └── src/
│       ├── app/
│       │   ├── layout.tsx        # root layout (metadata, fonts)
│       │   ├── page.tsx          # 400 L — THE app shell (single route)
│       │   └── globals.css       # 126 L — Tailwind theme, CSS vars, markdown styles, scrollbar removal, loading dots
│       │
│       ├── components/
│       │   ├── Sidebar.tsx                 # 1101 L — left session/workspace rail
│       │   ├── ChatCanvas.tsx              #  426 L — chat surface, turn feed, empty state
│       │   ├── RightSidebar.tsx            # 1285 L — explorer + editor + terminal viewer
│       │   ├── ConversationHistory.tsx     #  333 L — full-page session list
│       │   ├── SettingsModal.tsx           #  852 L — settings (theme engine, projects, account)
│       │   ├── SafeFileViewer.tsx           #  551 L — type-dispatched file viewer
│       │   ├── PlanApprovalModal.tsx       #  121 L — ⚠️ DEAD CODE (never imported)
│       │   ├── ErrorBoundary.tsx           #   66 L — scoped error boundary
│       │   ├── auth/
│       │   │   └── DesktopSignInView.tsx   #  189 L — OAuth gate (always-dark)
│       │   ├── chat/
│       │   │   ├── ChatComposer.tsx        #  330 L — input dock, attachments, send/queue/stop
│       │   │   ├── TaskWorkLogAccordion.tsx# 1074 L — agent activity timeline
│       │   │   ├── ArtifactCard.tsx        #  182 L — deliverable card
│       │   │   ├── MermaidRenderer.tsx     #  347 L — diagram viewer + fallback
│       │   │   ├── FilesChangedDrawer.tsx  #  113 L — edited files list
│       │   │   ├── QuotaBanner.tsx         #  123 L — always-dark upsell banner
│       │   │   └── ScrollToBottomButton.tsx#   21 L — always-dark FAB
│       │   ├── messages/
│       │   │   ├── AssistantMessage.tsx    #  775 L — markdown + steps + artifacts + lightbox
│       │   │   ├── UserMessage.tsx         #  130 L — user card with hover actions
│       │   │   ├── CodeBlock.tsx           #  181 L — zero-dep regex syntax highlighter
│       │   │   ├── CalloutBlockquote.tsx   #  135 L — GitHub alerts + color tags
│       │   │   └── TableContainer.tsx      #  112 L — audit table + Excel/CSV export
│       │   ├── common/
│       │   │   ├── FileIcon.tsx            #  225 L — brand-colored file icons
│       │   │   ├── Blockquote.tsx          #  113 L — colored blockquote primitive
│       │   │   ├── UniverExcelViewer.tsx   #  163 L — Univer loader shell
│       │   │   └── UniverExcelViewerInner.tsx # 146 L — Univer instance mgmt
│       │   └── ui/                         # shadcn-style primitives
│       │       ├── badge.tsx breadcrumb.tsx button.tsx card.tsx
│       │       ├── dropdown-menu.tsx input.tsx label.tsx separator.tsx
│       │       └── tabs.tsx tooltip.tsx
│       │
│       ├── hooks/
│       │   ├── useChatStream.ts            # 1182 L — streaming engine + sessionStore
│       │   ├── useScrollToBottom.ts        #   76 L — velocity-aware autoscroll (OpenHands pattern)
│       │   └── useIsDarkMode.ts            #   36 L — MutationObserver theme detector
│       │
│       ├── lib/
│       │   ├── types.ts                    #   39 L — Turn, ArtifactItem, EditedFileItem + re-exports
│       │   ├── turns.ts                    #  283 L — parseTranscriptLines + buildTurns
│       │   ├── artifactExtraction.ts       #  290 L — artifact/edited-file classification
│       │   └── utils.ts                    #    6 L — cn()
│       │
│       ├── utils/
│       │   ├── apiClient.ts                # 1028 L — 30 API fns + streamQuery SSE
│       │   └── parseTranscript.ts          #   71 L — types ONLY (name is misleading)
│       │
│       └── declarations.d.ts               #    2 L
│
├── connector/                    # FastAPI backend for the frontend
│   ├── app/
│   │   ├── main.py               #  218 L — FastAPI app, SSETransportServer wiring
│   │   ├── routers/
│   │   │   ├── chat.py           #  351 L — POST /stream SSE bridge, /stop, /approve
│   │   │   ├── sessions.py       # 1061 L — sessions, transcripts, rename/view/queue/undo
│   │   │   ├── artifacts.py      #  531 L — artifact listing, file content, univer xlsx
│   │   │   ├── tasks.py          #  323 L — background tasks + SSE terminal log stream
│   │   │   ├── uploads.py        #   77 L — multipart uploads
│   │   │   ├── projects.py       #  174 L — project registration
│   │   │   ├── settings.py, system.py, auth.py (400 L)
│   │   ├── services/excel_univer.py      # 501 L — xlsx → Univer JSON (Calamine/DuckDB)
│   │   └── workspace.py                  # 123 L
│   └── tests/                    # 15 test files incl. mock agent stream, SSE concurrency
│
└── NexAU/                        # Agent runtime (Python) — AG-UI protocol events,
                                  # SSE transport, tools (view_file, run_shell_command,
                                  # audit_skill_tool, web_search…), sessions, compaction
```

## Notable structural observations

1. **Single-route app.** All UI lives in `src/app/page.tsx` — no nested routes, no route-level code splitting beyond dynamic imports (Monaco, Mermaid, Univer).
2. **`parseTranscript.ts` contains only types.** The actual parser is `parseTranscriptLines` in `lib/turns.ts`. Anyone following the filename will look in the wrong place (documentation hazard).
3. **Component size distribution is bimodal**: 8 "god components" (Sidebar 1101, RightSidebar 1285, useChatStream 1182, TaskWorkLogAccordion 1074, apiClient 1028, SettingsModal 852, AssistantMessage 775, SafeFileViewer 551) plus many small primitives — 8 files hold ~53% of the code.
4. **The repo mixes three products** (frontend / connector / NexAU runtime) with Windows-first launchers; frontend `README.md` is still the stock create-next-app file.
5. **Tests are logic-level only** (`fuzz_session_store.ts`, `test_chat_scenarios.mjs`, `test_right_sidebar_logic.cjs`) — no rendering tests, no visual regression harness.
