# 08 — Visual Audit of the Existing Frontend

Every value below is extracted from code (Tailwind classes / CSS / hex literals) and cross-checked against the verified screenshots. Dark mode is the primary theme; light values in parentheses where they differ.

## 1. Layout

| Region | Measurement | Source |
|---|---|---|
| Window title bar | `h-7` = 28px, `#0d0d0f`, `px-3`, fixed | page.tsx:163 |
| Sidebar | default 260px, drag-resize **220–450px**, `w-1` hover handle `bg-sky-500/60` | Sidebar.tsx (MIN/MAX_WIDTH) |
| Toolbar rows (sidebar & chat) | `h-9` = 36px, `#121214` hardcoded, border-b `white/[0.06]` | page.tsx:254, Sidebar/RightSidebar |
| Right sidebar | default 420px, resize **320–1100px** (clamped ≤ innerWidth−420), grip `w-[2px] h-12` visible on hover, direct-DOM width mutation during drag | RightSidebar.tsx |
| Editor sub-header | `h-8` = 32px | RightSidebar |
| Chat column | `max-w-3xl` = **768px**, `mx-auto`, `px-4 sm:px-6` | ChatCanvas |
| Chat padding rhythm | turn feed `pt-3 space-y-3.5`; AI msgs `mt-1 px-1 sm:px-2 space-y-2.5`; turn separator `pb-3 border-b white/[0.04]` | ChatCanvas |
| Composer dock | `pb-3 px-4 sm:px-6`, inner `max-w-3xl`; shell `p-3 rounded-2xl` | ChatCanvas/ChatComposer |
| Sidebar session row | `h-[30px]`, `mx-1 px-2.5 rounded-md`, right slot w-6 | Sidebar |
| Modal | 880×580 (`max-w-[95vw] max-h-[90vh]`) | SettingsModal |
| Sticky user header | `sticky top-0 z-20 py-2 bg-[var(--bg-app)]/90 backdrop-blur-md` | ChatCanvas |
| Scroll behavior | all scrollbars hidden globally (`scrollbar-width:none !important` + webkit `display:none`) — `custom-scrollbar` class is a no-op vestige | globals.css:91-106 |
| Fixed vs fluid | sidebars fixed-px (resizable), center fluid, chat column capped 768px; responsive stops at `sm:` tweaks — no true breakpoints | throughout |

**Observed issues:** sticky user header overlaps the first accordion toggle at certain scroll offsets (reproduced during capture); 900px viewport compresses center column to ~180px usable with both panels open (screenshot 23).

## 2. Typography

| Role | Value | Where |
|---|---|---|
| Sans family | `Inter, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto…` | globals.css `--font-sans` |
| Mono family | `Fira Code, Consolas, Menlo, Monaco` | `--font-mono` |
| Body | 14px / 1.6 | body + `.markdown-body` |
| Assistant prose | `text-[14px] leading-[1.72]` | AssistantMessage |
| User message | 13.5px / 22px line | UserMessage |
| Section labels | `text-[11px] font-semibold uppercase tracking-wider` (zinc-500) | all sidebars/modals |
| List item titles | 13px (sessions, artifacts, settings nav) | everywhere |
| Metadata / timestamps | `text-[11.5px] font-mono` (muted) | rows, footers, tabs |
| Headings in markdown | h1 21px bold w/ border-b · h2 17.5px semibold w/ border-b · h3 15.5px · h4 14px | AssistantMessage |
| Code | inline `12px` amber pill; block `13px / 1.5` mono | AssistantMessage/CodeBlock |
| Table | th `11px uppercase tracking-wider`; td `12.5px` (numeric → `12px` mono right) | TableContainer |
| Console/terminal | 11–11.5px mono | TaskWorkLog/RightSidebar |
| Badge | `10–10.5px font-mono font-medium` | status pills, counts |

**Observed issues:** 9 distinct sizes between 10–14px with half-point steps (10, 10.5, 11, 11.5, 12, 12.5, 13, 13.5, 14) — no scale; mono used for both "data" and "labels" inconsistently (timestamps mono, but session titles sans).

## 3. Color

**Token layer** (`globals.css`, consumed via `var(--…)`):

| Token | Light | Dark | Role |
|---|---|---|---|
| `--bg-app` | #F8F9FA | #101010 | app background |
| `--bg-surface` | #FFFFFF | #141416 | cards, composer, code blocks |
| `--bg-hover` | #F1F3F5 | rgba(255,255,255,0.05) | hover fills |
| `--bg-active` | #E9ECEF | rgba(255,255,255,0.08) | active fills |
| `--border-subtle` | #E5E7EB | rgba(255,255,255,0.08) | hairlines |
| `--border-strong` | #D1D5DB | rgba(255,255,255,0.15) | table rules, dividers |
| `--text-primary` | #18181B | #ECECED | body text |
| `--text-secondary` | #52525B | #A1A1AA | subtitles |
| `--text-muted` | #71717A | #71717A | metadata (same both modes) |
| `--accent` / hover | #007ACC / #0062A3 | same | links, focus, spinners, welcome icon |

**Zinc Tailwind layer** (with `dark:` variants) carries most chrome: zinc-100/200/300 light vs `white/[0.04]–[0.14]` alpha stack dark; zinc-400/500/600 muted icons; zinc-800/900 selected fills.

**Hardcoded hex inventory** (theme-blind — the root of light-mode breakage):

| Hex | Used for |
|---|---|
| `#0d0d0f` | window title bar |
| `#121214` | sidebar/toolbar/right-sidebar header rows (both themes!) |
| `#141414` `#141416` `#151518` `#161616–161619` `#181818` `#18181a/b` `#1a1a1c/d` `#1c1c1f` `#1e1e22` `#1f1f1f` `#202022` `#242424` `#252528` `#27272c` | ~15 near-identical dark surfaces across cards, menus, viewers, tabs |
| `#2d86e6` `#1a73e8`/`#1557b0`/`#174ea6` | QuotaBanner action, Proceed button (two different blues) |
| `#2f81f7` (+ dot bg `#182433`) | unread indicator |
| `#007acc` `#0062a3` | settings switches, links (duplicates token values as literals) |
| `#dc3545`/`#c82333`/`#bd2130` | Danger Zone delete (bootstrap reds) |
| `#1b6d51` | avatar green |
| `#34d399` `#f87171` | FilesChanged +/− counts |
| `#0a0a0c` `#161618` `#e4e4e7` | sign-in view (always dark) |
| `#e5c07b` `#ececed` | file-pill amber text, assistant prose dark |

**Semantic colors** (Tailwind alpha recipes, consistent): success emerald-500/10–20; error rose/red-500/10–20; warning amber-500/10–20; info sky/blue; running sky-500 spinner; tool type accents — PDF red-400, images purple-400, Excel emerald-400, walkthrough blue-400, plan sky-400, search sky. FileIcon uses brand hexes (xlsx #107C41, pdf #F40F02, ts #3178C6, py #2dd4bf two-tone SVG…).

**Observed issues:** three accent blues coexist (#007ACC token, #1a73e8 Proceed, #2d86e6 Quota); muted text #71717A on #101010 = ~4.0:1 contrast (below AA 4.5 for body); the `custom-scrollbar` class referenced in 6+ places styles nothing.

## 4. Shape

| Element | Radius |
|---|---|
| Modals / composer / user card / queued card | `rounded-2xl` (16px) |
| Cards (artifact, table, diagram, callout, settings cards) | `rounded-xl` (12px) |
| Rows, inputs, buttons, menu items, tabs | `rounded-lg` (8px) / `rounded-md` (6px) |
| Small chips: status badges `rounded-[4px]`, file pills `rounded-[5-6px]`, extension badges `rounded` (4px) |
| Pills (pagination, Preview/Raw, count) | `rounded-full` |
| Section icons | `rounded-lg` tiles 32–56px (empty-state 48px `rounded-2xl`) |
| Separators | 1px hairlines (`--border-subtle`); `border-l-[3px]` on callouts/blockquotes |
| Shadows | `shadow-xs/2xs` on rows/buttons; `shadow-sm` cards; `shadow-lg/xl/2xl` overlays (Settings `0_25px_60px_-15px_rgba(0,0,0,0.25/0.8)`; menus `shadow-2xl shadow-black/10|80`) |

## 5. Depth & elevation

- **No blur layers except overlays**: settings overlay `backdrop-blur-sm`, lightbox `backdrop-blur-md`, sign-out confirm `backdrop-blur-xs`, context menu `backdrop-blur-md`.
- Sticky user header: `bg-[var(--bg-app)]/90 + backdrop-blur-md` (the only in-flow blur).
- Elevation ladder is coherent: flat rows (0) → cards (`shadow-xs/sm`) → popovers/menus (`shadow-xl/2xl`) → modals (deepest). Dark shadows use explicit `shadow-black/80` since default black shadows vanish on #101010.
- Hover fills use the white-alpha stack (0.04 → 0.06 → 0.08 → 0.12) instead of discrete colors.

## 6. Motion

| Motion | Spec | Where |
|---|---|---|
| Color/hover transitions | `transition-colors` (Tailwind default 150ms) | nearly every interactive element |
| Accordion expand | `animate-in fade-in-50 slide-in-from-top-1 duration-200 ease-out` | TaskWorkLog |
| Popover/menu | `animate-in fade-in zoom-in-95` | workspace menu, dropdowns |
| Loading dots | keyframes `loadingEllipsis` 1.3s infinite, staggered 0.22s/0.44s, translateY(-1.5px) | "Working…" |
| Spinners | `animate-spin` (lucide Loader2 10–24px) | thinking, tool rows, tasks, loading states |
| Live timer | 1s `setInterval` while thinking, latched after | TaskWorkLog |
| Theme transition | body `background-color .15s ease, color .15s ease` | globals.css |
| Streaming | **no cursor/typewriter effect** — text appears on rAF flushes; activity signaled by accordion + dots | AssistantMessage |
| Mermaid zoom | `transform: scale() transition .15s ease` | MermaidRenderer |
| Drag resize | right sidebar mutates width directly (no transition during drag; `duration-75` when idle) | RightSidebar |
| Scroll-to-bottom FAB | `transition-all active:scale-95` | ScrollToBottomButton |
| Reduced motion | **not handled anywhere** (no `prefers-reduced-motion` usage) | — |
