# 01 — Executive Summary

## The system in one paragraph

MASh's frontend is a **Next.js 16 (App Router) + React 19 + Tailwind CSS 4** single-page desktop-style application (~13.3K lines across 47 source files). It renders a three-column "IDE-like" workbench — left session/workspace sidebar, center chat canvas (768px max column), right artifact/file viewer — behind a fake desktop window frame (title bar with File/View/Window menus and minimize/maximize/close buttons). It talks to a local FastAPI "connector" (`http://127.0.0.1:8000`) which bridges to the NexAU agent runtime over an **AG-UI-protocol SSE stream**. The frontend receives **structured events** (thinking deltas, text deltas, tool call start/args/end/result, task updates, errors) — it does **not** infer behavior from text — and maintains a sophisticated module-level multi-session state store that survives session switching, with rAF-batched buffer flushing for smooth streaming.

## What already works well (strengths to preserve)

1. **Structured agent events, not text parsing.** The full event vocabulary (`THINKING_TEXT_MESSAGE_CONTENT`, `TOOL_CALL_START/ARGS/END/RESULT`, `TEXT_MESSAGE_CONTENT`, `TASKS_UPDATED`, `RUN_ERROR`…) flows into a clean state machine. The work-log accordion, tool-call rows with verbs ("Analyzed", "Ran", "Edited"), file pills, and durations are all driven by real data.
2. **Serious streaming engineering.** Token/thought deltas accumulate in per-session string buffers and flush once per animation frame (~16.7ms), coalescing re-renders; visibility-change handlers drain buffers when tabs wake; a 5-minute stall watchdog plus offline/fetch-error classification produces human-readable error messages.
3. **Multi-session isolation.** A module-level `sessionStore` Map (LRU, max 25) keeps parallel sessions' chat state, SSE buffers, and drafts from cross-talking; unread badges mark background-completed turns.
4. **Audit-domain-specific UI vocabulary.** Status badges (`[COMPLIANT]`, `[EXCEPTION]`, `[MATERIAL WEAKNESS]`…), right-aligned mono numerals in tables, "Copy for Excel" (TSV) table export, currency-aware cell detection, and a Univer-based read-only Excel viewer with "Read-Only Audit View" badge. This is genuinely differentiated, not a generic chat skin.
5. **Performance-conscious rendering.** Heavy memoization (module-level plugin arrays, custom `memo` comparators, WeakMap artifact caches), a 100-turn DOM window for long chats, scroll-anchored reverse pagination, and direct-DOM width mutation during right-sidebar drag (bypassing React for 120fps).

## What needs the most attention (weaknesses to fix in a redesign)

1. **Two-and-a-half theming systems fighting each other.** Tailwind zinc palette + `dark:` variants, CSS custom properties (`--bg-app`, `--accent`…), a runtime theme engine (6 presets + custom colors persisted to localStorage), and **~40 hardcoded dark hex values** (`#121214`, `#18181b`, `#0d0d0f`…) that stay dark in light mode. Light mode is visibly broken in the title bar, sub-headers, QuotaBanner, and ScrollToBottomButton.
2. **The design system is implicit, not explicit.** No tokens for radius/spacing/motion; values are duplicated per component (at least 6 distinct dark surface hexes within 4 RGB points of each other; font sizes 10/10.5/11/11.5/12/12.5/13/13.5/14px). Visual decisions live in 47 files instead of one source of truth.
3. **Interaction debt in the agent surface.** The sticky user-message header can cover the "Worked for 46s" accordion toggle at certain scroll positions; the left and right sidebar collapse buttons share the identical title "Collapse sidebar"; scroll-bottom detection uses two different thresholds (80px vs 20px) in two hooks; tool-call group cards (`exploration_group`, `command_group`, `edit_group`) are implemented but **disabled** (grouping function returns entries ungrouped).
4. **Dead and duplicated code.** `PlanApprovalModal` (121 lines, fully styled, approval API wired in apiClient) is **never imported** — the approval UX doesn't exist in practice. `showTasksBar` state is dead. `fetchUploads` and `fetchSessionUploads` duplicate each other. PDF and Word files are never classified as artifacts (only xlsx/csv/images/md/plan/walkthrough).
5. **Accessibility is partial.** Good ARIA on menus/dialogs (Radix), `aria-expanded` on collapsibles, keyboard-operable history rows — but icon-only buttons lack labels in places, focus visibility is inconsistent, no reduced-motion handling, no visible focus ring on the chat scroll container, and contrast of muted text (`#71717A` on `#101010` ≈ 4.0:1) falls short of WCAG AA for body text.

## The headline recommendation

The next iteration should **keep the architecture and the audit-domain vocabulary, and replace the styling substrate**: introduce a single token layer (files 18–19), migrate the shell to it (file 22), normalize the agent-chat surface (file 20), finish the artifact system (file 21), and delete the dead paths (file 12). The current codebase is structurally sound enough that this is a **refactor-in-place with a token wedge**, not a rewrite.

## Verification of method

Every claim in this package about runtime behavior was verified by running the app: 28 screenshots covering empty state, history, streaming (thinking/tool/text), completion, artifacts + Mermaid, error, queueing, cancellation, viewers (Univer/Monaco/markdown/terminal), settings, light mode, narrow viewport, attachment, hover actions, and context menus — each screenshot verified by a vision model, with console warnings/errors captured alongside.
