# 06 — Agent Event Flow: Backend Event → Frontend State → Rendered Component

## Verdict on structured events

**The frontend receives fully structured events.** The NexAU runtime emits AG-UI-protocol events (Pydantic models serialized as `data: {json}\n\n`), bridged verbatim by the connector's `POST /stream`. The UI never infers agent behavior from prose — with **three deliberate exceptions** where the frontend re-parses *content*:

1. Artifact detection regexes over tool args/markdown links (Flow F).
2. Quota detection regex over error text (`quota exceeded|rate limit|429…`).
3. Audit status badges regex over markdown text (`[COMPLIANT]`, `[EXCEPTION]`…).

## Complete event → state → component map

| Backend SSE event (type) | Fields used | apiClient callback | sessionStore mutation | Rendered result |
|---|---|---|---|---|
| `THINKING_TEXT_MESSAGE_START` | thinking_message_id, parent_message_id, run_id | *(ignored)* | — | *(no UI — thinking appears on first content)* |
| `THINKING_TEXT_MESSAGE_CONTENT` (+`REASONING_MESSAGE_CONTENT/CHUNK`) | `delta` | `onThought` | `thoughtBuffer += delta` → rAF flush → `thoughts[]` merge + running `thinking` step | TaskWorkLogAccordion: "Thinking for Xs…" live ticker + 3-dot `loadingEllipsis` animation; expanded → markdown card (max-h-60 scroll) |
| `THINKING_TEXT_MESSAGE_END` (+`REASONING_MESSAGE_END`) | — | `onThinkingEnd` | running thinking steps → completed with `thinkingDurationSeconds` | Row becomes "Thought for Xs" (toggle) |
| `TEXT_MESSAGE_START` | message_id | *(ignored)* | — | — |
| `TEXT_MESSAGE_CONTENT` (+`TEXT_MESSAGE_CHUNK`) | `delta` | `onToken` | `tokenBuffer += delta` → rAF flush → running `text` step + `msg.content` | AssistantMessage markdown streams progressively (no cursor; math/fence auto-balance while streaming; CodeBlock unhighlighted while streaming) |
| `TEXT_MESSAGE_END` | — | *(ignored)* | — | — |
| `TOOL_CALL_START` | tool_call_id, run_id, tool_call_name | `onToolCall({status:'running'})` | tools[] push/merge; `tool` step push (running) | Tool row with sky spinner (`Loader2` 10px) + verb ("Running…", "Analyzing…", "Editing…", "Searching…") |
| `TOOL_CALL_ARGS` | tool_call_id, `delta` | `onToolCall({args})` | per-tool arg buffer + incremental JSON parse | Args live-preview inside expanded console |
| `TOOL_CALL_END` | tool_call_id | `onToolCall` | final args parse | — |
| `TOOL_CALL_RESULT` | content/output/result, duration_seconds | `onToolCall({output, status:'completed', durationSeconds})` | tools[i].output; step completed | Row verb → past tense; duration right-aligned mono; console shows output; file tools show FilePill + line counts |
| `TASKS_UPDATED` (+`TASKS`, `TASK_UPDATE`, `BACKGROUND_TASKS`) | `tasks \| data` array | `onTasks` | `msg.tasks = list` | *(SubTask board data — currently no dedicated renderer consumes msg.tasks in chat; background procedures render via /api/tasks polling instead)* |
| `RUN_FINISHED` | — | *(explicit no-op)* | loop ends on `reader.done` | Finalization in `finally`: status → completed; "Worked for Xs" header; artifacts/edited-files extracted; footer timestamp + copy |
| `RUN_ERROR` / `TRANSPORT_ERROR` | message/error_message, run_id/error_id | `onError` | `msg.error`, `errorId`, status='error' | Error disclosure ("Terminated"/"Disconnected") + expandable mono details + Continue; QuotaBanner if quota-keyword match |
| *(server keepalive comment)* `: keepalive` every 15s | — | *(filtered: not `data:`)* | resets 300s stall watchdog | — |

**Additional runtime-emitted types present in the NexAU event vocabulary but NOT handled by streamQuery:** `RUN_STARTED`, `TEXT_MESSAGE_START/END` details, `IMAGE_MESSAGE_*`, `USER_MESSAGE`, `TEAM_MESSAGE`, `USAGE_UPDATE`, `MODEL_CALL_FINISHED`, `RETRY`, `COMPACTION_STARTED/FINISHED`, `CONTENT_BLOCKED` (see `NexAU/nexau/archs/llm/llm_aggregators/events.py`). These are dropped silently at the parser — headroom for future UI (usage meters, compaction notices, team progress).

## Derived state → render pipeline

```text
sessionStore[sid] (module Map, LRU-25)
   ├── chatMessages: Message[]            ──► buildTurns() O(n) memo ──► Turn[]
   │                                                                        │
   │   Message = {role, content, thoughts[], tools[], tasks[], steps[],     │
   │              status: running|completed|error|aborted,                 │
   │              thinkingDurationSeconds, totalDurationSeconds, error}    │
   │                                                                        ├──► ChatCanvas window (last 100 live turns)
   │                                                                        ├──► UserMessage (sticky header card)
   │                                                                        └──► AssistantMessage
   │                                                                              ├── TaskWorkLogAccordion (steps[])
   │                                                                              ├── markdown body (content)
   │                                                                              ├── error/aborted disclosures
   │                                                                              ├── ArtifactCard[] (artifactsByTurnMsg)
   │                                                                              └── FilesChangedDrawer (extractEditedFiles)
   ├── isStreaming / activeTurnId          ──► composer button state, spinners
   ├── queuedMessage                       ──► QueuedMessageCard
   └── hasUnread                           ──► Sidebar unread dot (2f81f7)
```

## Turn status vocabulary (observed)

| Level | Values | Set by |
|---|---|---|
| Message | `running` `completed` `error` `aborted` | send / finally / onError / stop |
| Step (ExecutionStep) | `running` `completed` `failed` `cancelled` | flush / tool events / stop |
| ToolCallItem | `running` `completed` (`failed` typed, never set from RESULT) | TOOL_CALL events |

⚠️ Note: `TOOL_CALL_RESULT` always maps to `status:'completed'` client-side even when the tool failed — tool failure is currently only visible by reading the output text (e.g. a Python traceback renders inside the console box, as reproduced in screenshot 12's run-up).
