# 07 — Screenshot Gallery (Annotated)

All 28 captures are of the **live running application** (Next.js dev server + scripted mock connector driving realistic audit scenarios). Viewport 1512×932 unless noted. Dark mode is the app default (`isDark = useState(true)` in `page.tsx`). Each image filename encodes its state. Images live in `images/`.

> **Method note:** the mock backend emitted the same AG-UI event shapes the real connector produces (verified against `connector/app/routers/chat.py` + NexAU event classes), so component rendering, streaming behavior, and state transitions shown here are the real frontend behavior — only the payload content is synthetic.

---

## App shell & navigation

### `01-empty-state-new-conversation-dark.png`
- **State:** brand-new conversation, zero messages. **Regions:** fake desktop title bar (28px, `#0d0d0f`); left sidebar (260px, `#121214` header row h-9); chat toolbar (36px breadcrumb `Mash › ✨ New Conversation`); centered welcome; composer dock.
- **Components:** `page.tsx` shell, `Sidebar`, `ChatCanvas` empty state, `ChatComposer`.
- **Welcome block:** 48px `rounded-2xl` icon tile with Sparkles (22px, `--accent`), headline **"MASH Statutory Audit AI"** (`text-xl font-bold tracking-tight`), subtitle `13.5px` muted, max-w-md. No prompt suggestions — a gap vs. ChatGPT/Claude starters.
- **Hierarchy:** icon → title → subtitle → generous whitespace → composer. Composer placeholder: *"Ask an audit question or reference file paths…"*; send button disabled (empty input).

### `16-sidebar-collapsed-dark.png`
- Sidebar hidden; a compact cluster (M logo tile, PanelLeft expand, back/forward) appears in the chat toolbar's left side; breadcrumb shifts left; chat column takes full width.

### `17-conversation-history-page-dark.png`
- **Full-page History** replaces ChatCanvas. `max-w-3xl` centered column: H1 "Conversation History", Active/Archived pill tabs, search box (`rounded-xl`, focus-within border), filter button, list rows with title + "Outside of Project"/folder subtitle + relative timestamp; hover reveals Archive/Delete icon buttons.

### `18-session-context-menu-dark.png`
- **Right-click / ⋮ menu** on a sidebar session (Pin to top · Rename · Copy Session ID · Archive · Delete). Fixed-position `rounded-2xl` card, `backdrop-blur-md`, shadow-2xl; viewport-clamped positioning; Delete row hovers red. Pinned state tints the row's Pin icon sky-400.

---

## Chat & agent activity

### `02-session-history-with-tool-calls-and-artifact-dark.png`
- **State:** loaded session (transcript → parseTranscriptLines → buildTurns). Shows: sticky user-message card at top (`#f4f4f6` light / `#18181b` dark, `rounded-2xl`, full column width); collapsed "Worked for 46s" link; markdown answer with **Table Data** header (Copy for Excel / CSV), `[COMPLIANT]` green / `[EXCEPTION]` red badges; **artifact card** ("WP Trade Payables Vouching", DELIVERABLE badge, download); **FilesChangedDrawer** ("1 file changed +1").
- **Mechanism:** all chrome zinc-palette + dark: variants; badges are inline `px-1.5 py-0.2 rounded-[4px] text-[10.5px] font-mono` pills colored per severity.

### `03-work-log-accordion-expanded-tool-calls-dark.png`
- **Expanded work log** ("Worked for 46s" clicked): timeline rows — "Thought for 14s" (toggle → markdown card), "Analyzed Aquamans_Finance · 480ms", "Ran duckdb … 2.8s" (mono command), "Edited WP_Trade_Payables_Vouching.xlsx +0 −0 · 1.9s" with green FilePill. Durations right-aligned `tabular-nums` 10.5px mono; running tools get sky spinners.

### `07-streaming-thinking-phase-dark.png`
- **Live turn, thinking+search:** "Thought for 1s" row, sky spinner + "Searching …", red-square **Stop** button in composer (visible while streaming with empty input), timestamp `04:11 AM` latched at mount.

### `08-streaming-tool-call-running-dark.png`
- Mid-turn: header reads **"Worked for 8s"** (live), partial text/structure already streaming, Stop button present. Demonstrates the accordion header switching from "Thinking…" to "Worked for…" as steps accumulate.

### `09-streaming-text-generation-dark.png`
- Answer streaming: bullet list of deliverables building, **DIAGRAM VIEW** container already mounted (mermaid renders after completion; "Generating diagram…" pill while streaming), Stop button still active.

### `10-completed-response-with-table-and-callout-dark.png`
- **Completed turn:** vendor table (numeric columns right-aligned mono), `[COMPLIANT]` badge, green **TIP callout** (`border-l-[3px] emerald-500` card with Lightbulb header), composer send button re-enabled (disabled gray circle).

### `11-artifact-cards-and-mermaid-diagram-dark.png`
- **Artifact + diagram turn:** two deliverable bullets; **rendered SVG flowchart** inside DIAGRAM VIEW (header with pulsing 2.5px accent dot, zoom cluster `100%` ± reset, `</> Code` / `SVG` buttons); `[MATERIAL WEAKNESS]` red badge; artifact cards for the xlsx (DELIVERABLE, download icon) and PNG (VISUAL CHART).

### `12-error-state-terminated-disclosure-dark.png`
- **Error turn:** "Worked for 2s" then red ⛔ **"Terminated — Agent execution terminated due to error."** disclosure row with chevron; expanded box shows mono details + errorId + Copy + **Continue** (sky). The run's tool console above shows the failed command (PermissionError traceback).

### `13-queued-message-card-while-streaming-dark.png`
- **Steering:** while streaming, a second message was sent → **Queued Messages** card above composer (count pill `1`, hint "Sends after agent finishes working", row actions: inject →, edit ✎, delete 🗑 on hover). Also visible: **QuotaBanner** ("Baseline model quota reached", amber triangle, View Account) triggered by the error-text regex.

### `14-cancelled-stopped-disclosure-dark.png`
- **User-stopped turn:** amber **"Stopped — Agent execution stopped."** disclosure ("stopped by user after Ns" in expanded state). Composer shows disabled Send (empty input).

### `26-user-message-hover-actions.png`
- Hover on user card → bottom-right actions fade in (`opacity-0 group-hover:opacity-100 duration-150`): timestamp `text-[11.5px] font-mono text-sky-400`, Copy (check flips emerald), **Undo2** with tooltip "Undo changes up to this point".

### `24-composer-file-attachment-chip.png`
- Attachment chip state: `test_upload.csv` chip (icon + mono name + ✕) above textarea; drag-over would show emerald ring (`border-emerald-500/60 ring-2`); attach button (+16px) left, send right.

---

## Viewer (right sidebar)

### `04-right-sidebar-excel-viewer-univer-dark.png`
- **Univer spreadsheet canvas** rendering the working paper: column/row headers, 3 sheets, toolbar (emerald FileSpreadsheet icon, filename, "3" sheet-count pill, **READ-ONLY AUDIT VIEW** badge, Download). Breadcrumb `Mash › Audit › Aquamans_Finance` above; Preview/Raw pill; ⋮ menu.

### `05-right-sidebar-explorer-working-papers-and-tasks-dark.png`
- **Explorer mode:** WORKING PAPERS (6) — colored rows (xlsx emerald, png purple, md sky) with extension badges; **See all (6)** expander; AUDIT PROCEDURES IN PROGRESS (2) — expanded here showing mono commands with spinners and kill buttons.

### `06-right-sidebar-markdown-viewer-dark.png`
- **Markdown preview:** audit_summary.md rendered with heading, bold, list, and SQL code block; editor sub-header (h-8) with breadcrumb, Preview|Raw segmented pill, ⋮ dropdown.

### `15-right-sidebar-terminal-task-log-dark.png`
- **Terminal viewer:** task header ("Background Task Output", **RUNNING→COMPLETED** chip with pulsing emerald dot, mono command `text-sky-400`, red Cancel Task button), numbered log gutter (`w-9 text-zinc-600 tabular-nums`) + `whitespace-pre-wrap` content on `#0d0d0f`.

### `25-right-sidebar-monaco-code-viewer.png`
- **Monaco editor** rendering sample_query.py: syntax colors, line numbers, readOnly; minimap suppressed (file <100 lines); toolbar identical to markdown viewer.

---

## Settings, theming, responsive

### `19-settings-modal-appearance-theme-dark.png`
- 880×580 modal (`rounded-2xl`, deep shadow, blur overlay): left nav (SETTINGS sections, PROJECTS, Shortcuts, Provide Feedback, profile chip), right pane **Appearance** — mode segmented control (Monitor/Sun/Moon), Light & Dark theme cards with preset selects (Default Light/Pure White; Default Dark/OLED Black/Antigravity Grey) and hex ColorField rows (swatch + mono input).

### `20-settings-modal-account-tab-dark.png`
- **Account pane:** custom switches (Enable Telemetry, Product Updates; 44×24 track, #007acc on-state), plan card "MASH ENTERPRISE · 999999 credits", email, red-tinted Sign Out button.

### `21-settings-modal-light-mode-active.png`
- Same modal immediately after switching mode to **Light** — content pane flips to light while parts of chrome still dark (see findings).

### `22-light-mode-chat-view.png`
- **Light mode chat:** body surfaces flip correctly (white cards, `#F8F9FA` app bg) — but the **window title bar stays `#0d0d0f` black** and sub-headers stay `#121214` (hardcoded), producing a jarring split. Verified visually; root cause is hardcoded hexes listed in 08-visual-audit.

### `27-light-mode-empty-state.png`
- Light-mode welcome — centered title + subtitle + composer on white; title bar still dark.

### `23-narrow-viewport-900px-layout.png`
- 900px viewport: three columns **compress but hold** (no breakpoint collapse); chat column narrows below `max-w-3xl`; sidebar/right panel fixed pixel widths dominate. No mobile layout exists by design (desktop app metaphor).

### `28-work-log-command-console-expanded-light.png`
- Light-mode work log with **expanded command console**: "Ran duckdb … 2.8s" row; console box shows full command, status, output (`bg-zinc-100/40` light equivalent), copy button; surrounding rows show Analyzed/Edited verbs + durations.
