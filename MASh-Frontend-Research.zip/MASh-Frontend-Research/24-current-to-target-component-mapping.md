# 24 — Current → Target Component Mapping

Conservative, reuse-first. **Every** current component has a destination.

## Legend
→ migrate (same role, moves + tokenized) · ⚠→ split · ✚ new · ⨯ delete · ♻ reuse unchanged

## Map

| Current (path) | Target | Action |
|---|---|---|
| `app/page.tsx` (shell) | `shell/AppShell` | ⚠→ split: layout state → AppShell; auth gate stays; menus become real |
| `app/globals.css` | `foundation/tokens.css + typography/motion/a11y.css` | ⚠→ split; keep markdown-body + scrollbar rules + dots keyframes |
| `components/Sidebar.tsx` | `shell/Sidebar` + `shell/SidebarSection` + `shell/SessionRow` + `primitives/ContextMenu` + `hooks/useSessions` | ⚠→ split (poll/optimistic ops → useSessions; menu → primitive; rename/popover extracted) |
| `components/ChatCanvas.tsx` | `chat/ChatCanvas` | → slim orchestrator; empty state → `primitives/EmptyState` + starters |
| `components/RightSidebar.tsx` | `viewer/ViewerPanel` + `viewer/ViewerTabs/Toolbar/BreadcrumbBar` + `hooks/useArtifacts`, `hooks/useBackgroundTasks` + `agent/ProcedureCard` | ⚠→ split by mode; terminal logic → `viewer/viewers/TerminalViewer`; resize math → `shell/ResizeHandle` |
| `components/SettingsModal.tsx` | `overlays/SettingsDialog` + `foundation/theme-engine.ts` | ⚠→ split (theme writer extracted); fallback tabs themed or removed |
| `components/SafeFileViewer.tsx` | `viewer/viewers/*` (7 viewers) | ⚠→ split by type; safety limits → shared `viewer/limits.ts` |
| `components/ConversationHistory.tsx` | `shell/ConversationHistory` | → tokenized; rows → `shell/SessionRow` variant |
| `components/ErrorBoundary.tsx` | `primitives/ErrorBoundary` | ♻ reuse unchanged (tokenized fallback) |
| `components/auth/DesktopSignInView.tsx` | `shell/SignInView` | → tokenized (stop hardcoding dark; it may stay dark-by-design via tokens) |
| `components/PlanApprovalModal.tsx` | `agent/ApprovalGate` | → **revive + mount** (wired to plan artifacts) — top priority |
| `components/chat/ChatComposer.tsx` | `chat/Composer` + `chat/AttachmentChip` | → buttons restated (Stop always visible); chips extracted |
| `components/chat/TaskWorkLogAccordion.tsx` | `agent/WorkLog` + `agent/ToolRow` + `agent/CommandConsole` + `agent/ThoughtCard` + `lib/agent/toolVerbs.ts` | ⚠→ split; **re-enable groupToolEntries**; add failed state |
| `components/chat/ArtifactCard.tsx` | `artifacts/ArtifactCard` | → + generating/failed/versioned states |
| `components/chat/MermaidRenderer.tsx` | `chat/MermaidRenderer` (under shared markdown) | → tokenized theme vars; fallback kept |
| `components/chat/FilesChangedDrawer.tsx` | `artifacts/FilesChangedSummary` | → (ChangeSetReview ✚ v2) |
| `components/chat/QuotaBanner.tsx` | `overlays/QuotaBanner` | → themed (kill always-dark); fix `#1f1f1` typo |
| `components/chat/ScrollToBottomButton.tsx` | `chat/ScrollToBottomButton` | → themed |
| `components/messages/AssistantMessage.tsx` | `chat/ResponseBlock` + `infra/markdown/shared-renderer` | ⚠→ split (renderer config out; badge/pill lexing → shared) |
| `components/messages/UserMessage.tsx` | `chat/UserBubble` | → |
| `components/messages/CodeBlock.tsx` | `infra/markdown/CodeBlock` | → shared by both stacks |
| `components/messages/CalloutBlockquote.tsx` | `infra/markdown/CalloutBlockquote` | → |
| `components/messages/TableContainer.tsx` | `infra/markdown/TableContainer` | → (single `th` style — kills M11) |
| `components/common/FileIcon.tsx` | `primitives/FileIcon` | ♻ unchanged (already excellent) |
| `components/common/Blockquote.tsx` | `primitives/Blockquote` | ♻ |
| `components/common/UniverExcelViewer(+Inner).tsx` | `viewer/viewers/SheetViewer` | → fix unmount-race warning (H8) |
| `components/ui/*` (11 files) | `primitives/*` | ♻ reuse; add SegmentedControl, ContextMenu, ConfirmDialog, CopyButton, Skeleton, EmptyState ✚ |
| `hooks/useChatStream.ts` | `infra/store/session-store` + `infra/stream/*` + slim `useChatStream` | ⚠→ split (public hook API preserved) |
| `hooks/useScrollToBottom.ts` | `infra/hooks/useScrollToBottom` | → **unify thresholds** (20px everywhere; expose constant) — kills H2 |
| `hooks/useIsDarkMode.ts` | `infra/hooks/useIsDarkMode` | ♻ |
| `lib/turns.ts` | `infra/store/transcript.ts` | → rename/absorb `parseTranscript.ts` types (kills H6 naming trap) |
| `lib/artifactExtraction.ts` | `lib/artifacts/extraction.ts` | → + pdf/docx classification (H5) |
| `lib/types.ts` | `infra/types.ts` | → add failed tool status |
| `utils/apiClient.ts` | `infra/api/{http,sessions,files,tasks,projects,auth,stream}.ts` | ⚠→ split; delete `fetchUploads` dup (M1); title gen → `infra/format/titles.ts` |
| `utils/parseTranscript.ts` | merged into `infra/types.ts` | ⨯ delete file (types-only, misleading) |
| *(none)* | `shell/StatusBar` · `overlays/CommandPalette` · `agent/TurnReceipt` · `artifacts/VersionChip` · `infra/markdown` | ✚ new |

## Deletions (after verification)

`PlanApprovalModal` **not** deleted — revived. Delete: `showTasksBar` state · `fetchUploads` · `clearSessionQueue` (or wire it into discardQueued — pick one) · `custom-scrollbar` usages · dead window-menu labels (or make real) · back/forward dead buttons (or bind to session history stack) · Settings fallback tabs (or theme them).

## Volume estimate

- Reuse unchanged: 8 files · Migrate-in-place: 21 · Split: 8 · New: 7 · Delete: 6 items.
- ≈ 70% of current code survives in place or lightly edited — consistent with "refactor, don't rewrite".
