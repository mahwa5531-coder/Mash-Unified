# 16 — Visual Reference Board

Six external reference images (collected via image search for study; third-party screenshots) + pointers into our own 28 captures where MASh already exhibits a pattern. Each entry states **what specifically to study**.

## How to use this board

For each reference: study the listed properties, compare with the cited MASh screenshot, and note the delta. This board informs files 17–22 (design direction → specs).

---

## Navigation

### `images/ref-chatgpt-sidebar-and-chat-layout.jpg`
**Reference:** ChatGPT app shell with sidebar (New chat, Search, Library, Projects).
**Study:**
- Rail grouping hierarchy: primary actions (New chat) → navigation verbs (Search/Library/Projects) → recents
- Date-bucketed conversation grouping vs MASh's flat "Conversations" list
- Sidebar collapse to icon rail (MASh hides entirely — compare information retention)
- Composer as visual anchor of the empty state
**Compare with:** `01-empty-state-new-conversation-dark.png`, `16-sidebar-collapsed-dark.png`

### `images/ref-claude-sidebar-and-chat.jpg`
**Reference:** Claude sidebar (Chats/Projects/Code) + conversation.
**Study:**
- Three-tab sidebar information architecture vs MASh's four stacked sections
- Minimal chrome around session titles (no per-row metadata clutter)
- Title truncation and hover affordance placement
**Compare with:** `02-session-history-with-tool-calls-and-artifact-dark.png`

## Chat & agent activity

### `images/ref-cursor-ide-editor-panel.jpg`
**Reference:** Cursor IDE with code + agent panel.
**Study:**
- Inline activity adjacent to the artifact being edited (vs MASh's chat-inline accordion)
- Compact tool-call rows: icon + one-line summary + expandable detail
- How diffs surface without leaving the working context
**Compare with:** `03-work-log-accordion-expanded-tool-calls-dark.png`, `28-work-log-command-console-expanded-light.png`

### `images/ref-claude-code-terminal.jpg`
**Reference:** Claude Code terminal welcome (themes, command surface).
**Study:**
- Monospace-first command aesthetic — density and scan-ability
- Status/branding row treatment (thin, dark, low-contrast)
- Keyboard-hint affordances embedded in the UI copy
**Compare with:** `15-right-sidebar-terminal-task-log-dark.png`

## Density, dashboards & polish

### `images/ref-linear-dark-dashboard.png`
**Reference:** Linear-style dark analytics dashboard (issues, charts).
**Study:**
- Near-black surfaces with hairline borders (no heavy shadows in dark mode)
- One accent + semantic dots; everything else neutral
- Chart/figure integration inside a list-first layout (relevant to audit findings summaries)
- Numeric typography: tabular figures, right alignment
**Compare with:** `10-completed-response-with-table-and-callout-dark.png` (MASh already right-aligns numerals — extend this discipline)

### `images/ref-linear-mobile-clean-minimal.png`
**Reference:** Linear welcome/home/task screens (3-up).
**Study:**
- Onboarding/empty-state copy hierarchy: headline → sub → single CTA
- Whitespace rhythm on first-run surfaces vs tool surfaces
- Icon+label pairing consistency
**Compare with:** `01-empty-state-new-conversation-dark.png` (MASh lacks starter prompts — study the CTA pattern here)

---

## Pattern groups → where MASh stands today

| Group | Best reference | MASh today (screenshot) | Delta to study |
|---|---|---|---|
| Navigation | ref-chatgpt, ref-claude | 01, 16, 17 | Date grouping; icon-rail collapse; search placement |
| Chat | ref-chatgpt | 02, 10 | Streaming caret; hover action placement; starters |
| Agent activity | ref-cursor, hatchworks log pattern | 03, 07, 08 | Compact rows; severity filter; group cards (disabled in MASh) |
| Tool calls | ref-cursor | 03, 28 | One-line summaries with expand; failure state |
| Composer | ref-chatgpt | 24 | Persistent stop; attachment previews |
| Artifacts | ref-claude (versions), Antigravity (artifacts-as-verification) | 11 | Version chips; receipt-style turn summary |
| Files | ref-cursor (changeset) | 02 (FilesChangedDrawer) | Per-file diff review; bulk accept |
| Viewer | ref-cursor | 04, 06, 15, 25 | Tab grammar; Preview/Raw consistency |
| Menus/dialogs | (Radix baseline) | 18, 19, 20 | Focus trap; keyboard menus |
| Loading | (ChatGPT/Claude idioms) | 07, 08 | Skeletons vs spinners; button-level loading |
| Errors | (agent-UX literature) | 12 | Severity-coded disclosures + retry policy |
| Dark mode | ref-linear | all dark captures | Consolidate ~18 near-black hexes → 2 tokens |
| Typography | ref-linear | all | Collapse 13 sizes → 6-role scale |
| Spacing | ref-linear | all | 4px grid discipline |
| Motion | (Raycast/Linear restraint) | 07 (dots), 03 (accordion) | Reduced-motion; 150/200ms standard |

## Annotation conventions used above

- "Study" bullets name **specific properties** (hierarchy, truncation, rhythm), never vague "clean/modern" judgments.
- Every reference is paired with MASh's own capture so the comparison is grounded in the actual product, not an imagined one.
