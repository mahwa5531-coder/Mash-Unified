# 19 — Component System (Target)

*Proposed architecture. Conservative: every current component maps forward (file 24); nothing here requires a framework change.*

## Layer model

```text
FOUNDATION     tokens.css · type.css · reset · motion.css · a11y.css
PRIMITIVES     Button · IconButton · Input · Textarea · Pill · Badge ·
               Chip · Tooltip · Menu · Modal · SegmentedControl · Switch ·
               Spinner · Dots · Skeleton · EmptyState · ContextMenu · Lightbox
LAYOUT         AppShell · TitleBar · StatusBar · Sidebar · SidebarSection ·
               SessionRow · ChatColumn · ViewerPanel · ResizeHandle
AGENT          WorkLog · ActivityRow · ToolRow · CommandConsole · ThoughtCard ·
               TurnReceipt · ApprovalGate · ProcedureCard
CHAT           Composer · AttachmentChip · UserBubble · ResponseBlock ·
               StreamingText · MessageFooter · QueuedCard · StatusBadge · FilePill
ARTIFACT       ArtifactCard · ArtifactGrid · VersionChip · FilesChangedSummary ·
               ChangeSetReview
VIEWER         ViewerTabs · ViewerToolbar · BreadcrumbBar · FileViewers
               (Markdown/Code/Sheet/Terminal/Image/Pdf/Unsupported) ·
               PreviewRawToggle · TaskTerminal
OVERLAYS       SettingsDialog · ProjectPicker · CommandPalette · ConfirmDialog ·
               QuotaBanner · ErrorDisclosure
```

## Foundation rules

- Tokens are the only source of color/spacing/radius/shadow/motion (file 18). PRIMITIVES consume tokens; feature components consume primitives.
- a11y.css ships the global `:focus-visible` ring + reduced-motion block + `aria-live` helper classes.

## Primitive specs (key ones)

### Button
- **Anatomy:** icon? + label? (at least one required)
- **Variants:** `primary` (accent bg) · `secondary` (surface + border) · `ghost` (transparent) · `danger` (danger bg) · `danger-soft` (danger-soft bg + danger text)
- **Sizes:** `sm` 28×28 icon / h-7 · `md` h-8 px-3 text-sm · `lg` h-10
- **States:** default · hover (fast) · focus-visible (ring token) · active (scale .99 only on lg) · loading (spinner replaces icon, label stays, `aria-busy`) · disabled (opacity .45, cursor-not-allowed)
- **A11y:** native `<button>`; icon-only requires `aria-label`

### Pill / Badge / Chip
- Pill = status (counts, pagination): `radius-full`, `text-mono-sm`, 2px×8px padding
- Badge = audit status: `radius-xs`, `--m-text-mono-sm`, semantic soft bg/border/text (mapping in file 18)
- Chip = removable input value (attachment, filter): `radius-sm`, ✕ button 16px with 24px hit area

### SegmentedControl (unifies Preview/Raw + mode selectors)
- **Anatomy:** container inset bg + active thumb (surface + shadow-sm) + 2–3 options (icon+label)
- **States:** selected (thumb), hover, focus-visible roving tabindex, keyboard arrows

### Modal (replaces hand-rolled portals)
- Radix Dialog: focus trap, Esc, aria-modal, initial focus on primary action, restore on close
- **Sizes:** sm 400 · md 560 · lg 760 · xl 880 (settings) — max-w 95vw
- Enter: fade 150 + scale .98→1 (slow token); overlay `backdrop-blur-sm`

### ContextMenu (extract from Sidebar)
- Radix ContextMenu: keyboard-openable, arrow keys, `role="menu"`, clamped positioning (keep current math)
- **Items:** label + icon + shortcut? + destructive variant (danger-soft hover)

### Spinner / Dots / Skeleton
- Spinner = running tool/procedure (12px default, `--m-running`)
- Dots = agent thinking/working (kept keyframes, 1.3s, reduced-motion → hidden)
- Skeleton = deferred content (history load, file load) — replaces several spinner+label layouts

## Layout components

### AppShell
Grid: `titlebar(28) / [sidebar | chat | viewer] / statusbar(24)`. Manages open/maximized state + ⌘K + Esc hierarchy + connection status.

### StatusBar (NEW — VS Code-inspired)
`session · model · thinking budget | connection dot | procedures running (N) · tasks`. 24px, `--m-text-mono-sm`, muted. Houses currently-invisible state (file 15 recommendation).

### Sidebar / SessionRow
- Section headers → `SidebarSection` primitive (label + count + collapse, `aria-expanded` kept)
- **SessionRow states:** idle · hover (⋮) · selected · streaming (spinner) · unread (dot) · pinned (accent pin) · renaming — 30px rows kept
- Date grouping under Conversations (ChatGPT pattern): Today / Yesterday / Previous 7 days / Earlier

### ResizeHandle
Shared by both panels: 4px hit area + visible 2px grip on hover; keyboard arrows resize (a11y win); persists width to localStorage (fixes M4).

## AGENT components (the differentiators)

### WorkLog (from TaskWorkLogAccordion)
- **Anatomy:** header (receipt line or live status) + rows
- **Header states:** streaming (`Dots + "Thinking for Xs"`) → completed (`"Worked for Xs ▸"`, 12px text-muted, hover text-primary)
- Re-enable `groupToolEntries` grouping (command_group/edit_group/exploration_group) — the code exists (H1)

### ToolRow (anatomy)
```text
ToolRow
├── status icon     (spinner | check | alert | cancelled)
├── verb + subject  ("Ran", mono command OR FilePill OR pattern)
├── meta            (result count chip · line range)
├── duration        (right, mono-sm, tabular)
└── expand ▸        → CommandConsole | FilePreview
```
- **States:** running (spinner + present tense) · completed (past tense + duration) · **failed (NEW: alert icon + danger verb + auto-expands once)** · cancelled
- Single-open console per WorkLog (current behavior kept)

### CommandConsole
- Header: cwd chip `\Mash >` + full command + copy
- Body: output `<pre>` capped at 2,000 DOM lines + "Show full log" (P4 fix); `file://` links stay interactive; status footer (exit Check/Alert)

### ThoughtCard
- Duration-only summary row; expanded → markdown (max-h-60, auto-scroll rule kept). No chain-of-thought beyond what the backend already sends as thinking summaries.

### TurnReceipt (NEW — "receipts" from agent-UX literature)
- One line under every completed tool-bearing turn: `9 tool calls · 2 files written · 46s · 1 exception` with exception count in danger when >0
- Click → expands WorkLog

### ApprovalGate (revives PlanApprovalModal content)
- Triggered by plan artifact awaiting approval (backend `/approve` exists)
- **Anatomy:** ShieldAlert header + mode select (Manual/Auto/Turbo) + plan markdown + feedback input + Reject/Proceed footer
- Proceed = accent primary; Reject = danger-soft; Esc closes without action

### ProcedureCard (right panel, from task rows)
- **Anatomy:** status icon + mono command + elapsed + kill
- Grouped in "Audit Procedures in Progress" (kept collapsed-by-default, but count chip pulses when N>0)

## CHAT components

### Composer
- Attachment chips row → textarea (auto-resize ≤220) → footer (attach · char count NEW · send/queue/stop)
- **Button logic (fixes discovery issue):** during streaming show BOTH stop (primary, left of send) and queue-as-send; text present → Enter queues (hint in placeholder: "Enter to queue")
- Drag-over: emerald ring kept; a11y labels on all buttons

### ResponseBlock (from AssistantMessage)
- **Anatomy:** WorkLog → TurnReceipt → markdown body → error/aborted disclosures → ArtifactCards → FilesChangedSummary → footer (timestamp, copy)
- Markdown renderer: ONE shared config module for chat + viewer (kills the dual stack, M11) with the audit extensions (badges, pills, numeric cells, callouts)

### StatusBadge / FilePill
- FilePill extracted to shared primitive (kills the duplicate, L5): amber mono chip, click → viewer, `max-w-[280px]` truncate + line-range suffix

## ARTIFACT components

### ArtifactCard
- **Anatomy:** 32px icon tile (type-colored) + title (13px medium) + tag badge + summary (12px muted) + actions (Download | Proceed | Open)
- **States (NEW):** default · hover · generating (skeleton shimmer + "Writing working paper…") · failed (danger border + retry) · versioned (VersionChip v2) · proceeded (Implemented chip)
- Types: spreadsheet / chart / plan / walkthrough / **document (pdf/docx — NEW)** / code

### VersionChip + canonical groups
- `implementation_plan.md` and `walkthrough.md` groups already suppress older turns (file 05-F); expose as visible `v2` chip with a popover listing prior versions

### FilesChangedSummary → ChangeSetReview
- Phase 1: keep summary card (+/− totals, Review opens first file)
- Phase 2 (Cursor pattern): review mode — file list → per-file diff in viewer → Accept all / Reject

## VIEWER components

### ViewerTabs / ViewerToolbar / BreadcrumbBar
- Tabs: file/image/terminal types with icons; close ✕ 16px; overflow scroll with edge fades; per-session memory kept
- Toolbar: `N lines · X KB` (mono-sm) + PreviewRawToggle + Format JSON · Wrap · Copy · Download (icon buttons with tooltips)
- Breadcrumb: root "Mash" button + path crumbs, last crumb pill, wheel→horizontal (kept)

### FileViewers
- MarkdownViewer (shared renderer), CodeViewer (Monaco, config as today), SheetViewer (Univer, read-only badge kept), TerminalViewer (SSE + capped DOM + reconnect notice NEW), ImageViewer (framed + lightbox), PdfViewer (embed + open), UnsupportedCard (download)
- Every viewer: loading = Skeleton; error = tile + Download + Retry

## OVERLAYS

- SettingsDialog (keeps theme engine, writes new tokens; fixes dark-only fallback tabs)
- CommandPalette (NEW ⌘K): sessions, working papers, procedures, actions
- ConfirmDialog (replaces window.confirm in project delete)
- QuotaBanner (themed with tokens — fixes always-dark)
- ErrorDisclosure (Terminated/Disconnected/Stopped — current design kept, + severity colors + retry policy)

## Sizing / spacing summary

- Row heights: session 30 · artifact 28 · tool 24 · menu item 32
- Card padding: 12px (12.5px cards today → 12)
- Icon sizes: 11 (inline) / 14 (rows) / 16 (buttons) / 22 (empty tiles) — mirrors today's dominant choices
