# 20 — Agent Chat Design System

Visual specification for every agent-chat element. Convention: **collapsed form** is what auditors see by default; **expanded** is on demand. No private chain-of-thought is surfaced — thinking appears as duration + backend-provided summary text only (current behavior preserved and codified).

## User message

```text
┌──────────────────────────────────────────────────────────┐
│ Perform vouching on trade payables ledger and prepare     │  13px/22px, zinc-900/#18181b card
│ the working paper… (line-clamp-3, click to expand)        │  bg #f4f4f6 / #18181b, radius-xl,
│                                    04:11 AM  ⧉  ↩ hover  │  border-subtle, shadow-sm
└──────────────────────────────────────────────────────────┘
```
- Full column width (768px), sticky header version keeps `bg-app/90 + blur`
- Hover actions: timestamp (mono-sm, accent) · Copy (✓ emerald 2s) · Undo (tooltip "Undo changes up to this point")
- Attached images render as 64×48 thumbnails appended in-flow

## Assistant message (response block)

```text
[WorkLog — collapsed "Worked for 46s"]        ← activity (see below)
[TurnReceipt: 9 tools · 2 files · 46s · 1 exception]
────────────────────────────────────────────
## Heading (16px semibold, border-b subtle)   ← prose 14px/1.65
Body with **bold**, `inline code` (amber pill),
tables (numeric right-aligned mono), callouts.
[COMPLIANT] badges inline.
[Diagram View — rendered mermaid]
────────────────────────────────────────────
[ArtifactCard × N]                            ← deliverables
[FilesChangedSummary: 2 files changed +41 −3]
────────────────────────────────────────────
04:11 AM · ⧉ Copy response                    ← footer 11px mono muted
```

## Streaming text

- Text appends per rAF flush (existing). **NEW: caret** — 2px×16px accent block, `steps(2)` blink 1s, at end of last text node; removed on completion. (Today: no caret — the accordion dots carry "aliveness"; the caret adds at-a-glance confirmation without new motion vocabulary.)
- Math/fence auto-balance during streaming (existing `formatMathInMarkdown`) — kept.
- CodeBlock renders unhighlighted while streaming (existing perf choice) — kept.

## Thinking / activity summary

```text
Collapsed (default):
  ● Thought for 14s                          ← 12px text-muted, toggle
Streaming:
  ◌ Thinking for 3s…                         ← spinner --m-running + live 1s ticker + dots
```
- Expanded → ThoughtCard: `radius-lg inset bg`, 12px markdown, max-h-60 scroll, auto-scroll while ≤50px from bottom (existing rules)
- **Never** auto-expands; never shows raw reasoning beyond the backend's thinking channel

## Activity group (WorkLog)

```text
Header:  "Worked for 46s ▸"                   ← 12px text-muted link; hover text-primary + bg-hover
         streaming: "Thinking for 3s…" + dots / "Working…" + dots
Body (expand, 200ms ease-out, single-open rows):
  Thought for 14s                    ▸
  Analyzed Aquamans_Finance          480ms
  Ran duckdb -c "SELECT vendor…"     2.8s   ▸ console
  Searched "vendor master" · 20 hits 0.9s
  Edited WP_Trade_Payables.xlsx +41 −3 1.9s
```
- Rows 24px, gap 8px, 12px text; durations right mono-sm tabular
- Group cards (re-enabled): consecutive commands → `command_group` ("Ran 3 commands · 12s"), consecutive edits → `edit_group` ("Edited 4 files +120 −12"), exploration → `exploration_group` ("Searched 5 patterns · 14 hits")

## Tool call (ToolRow spec)

| Type | Collapsed | Expanded | Icon/color |
|---|---|---|---|
| command | `Ran` + mono cmd (truncate 1 line, `max-w-xl`) | CommandConsole | Terminal amber |
| file_read | `Analyzed` + FilePill + `#L12-80` | — | FileIcon (brand) |
| folder_view | `Analyzed` + folder name | — | Folder `#DCB67A` |
| edit | `Edited` + FilePill + `+n −m` | mini diff summary | FileIcon |
| search | `Searched "pattern"` + `N results` chip | result list (capped) | Search sky |
| subagent | `Subagent task` + role badge | output | Bot |
| timer | `Timed 30 seconds` | prompt text | Clock |
| task | taskName + `finished` | output | Check |
| other | `Executed` + raw name (mono) | output | Wrench zinc |
| **failed (NEW)** | verb in danger + `!` icon, auto-expanded once | output + error tail | Alert danger |
| cancelled | verb + `(Cancelled)` | — | zinc slash |

Status icons: running `Loader2 10px --m-running` · completed ✓ (commands only, per current) · failed ! danger · cancelled ⊘ zinc.

## Command execution (CommandConsole)

```text
┌ C:\Audit\Aquamans_Finance >  duckdb -c "SELECT vendor, SUM…" ⧉ ┐  inset bg, radius-md, 11px mono
│ [INFO] loading 1842 rows…                                      │  output pre, max 2000 DOM lines
│ vendor=Reliance Infra total=8420500                            │  file:// links → sky underline buttons
│ [OK] query finished in 1.84s                                   │  ✓ status footer
└────────────────────────────────────────────────────────────────┘
```

## File operation (reads/writes)

- Read → `Analyzed` + FilePill (`#L` range) — no expansion
- Write/Edit → `Edited` + FilePill + `+n −m` (emerald/danger counts); FilesChangedSummary aggregates at turn end; Review opens first file in viewer

## Search

- Row: `Searched "pattern"` + count chip; expanded: top results (path + line, capped 50) with FilePills

## Progress

- Indeterminate everywhere today; spec: keep indeterminate for tools; **procedure-level progress** = elapsed timer in ProcedureCard + count in StatusBar. (No fake percentage bars.)

## Approval (ApprovalGate)

```text
┌ ⚠ Implementation Plan Approval Required    [Manual Approval ▾] ┐  modal lg, radius-xl
│  (plan markdown, scrollable)                                    │
│ ┌ feedback input ─────────────────────────────────────────────┐ │
│ └──────────────────────────────────────────────────────────────┘ │
│                              [Reject / Request Changes] [Proceed] │  danger-soft / accent
└──────────────────────────────────────────────────────────────────┘
```
Modes: MANUAL_APPROVAL / AUTO_APPROVE / TURBO (existing API values). Proceed posts `/approve {action:'proceed'}`; Reject posts `action:'reject'` + feedback.

## Result / task completion

- TurnReceipt: `9 tool calls · 2 files written · 46s · 1 exception` — 12px mono-sm muted; exception count in danger when >0; click → WorkLog
- Final answer flows immediately after receipt; artifacts below

## Artifact (in-chat card)

```text
┌ [▣] WP Trade Payables Vouching        [DELIVERABLE] [v2] ┐
│     MUS sample of 58 items across 12 vendors    ⤓  Open  │
└──────────────────────────────────────────────────────────┘
```
See file 21 for full artifact system.

## Error

```text
Row:    ⛔ Terminated — Agent execution terminated due to error.      ▸   (danger)
        ⚠ Disconnected — network interrupted.                        ▸   (warning)
        ■ Stopped — stopped by user after 12s.                       ▸   (muted)
Expanded: mono details (inset bg) + errorId + ⧉ + [Continue →] (accent-soft)
```
Continue re-sends the original prompt (existing onContinue).

## Cancellation

- Stop button: always visible during streaming (left of send in new composer); 28px circle, danger ■
- On stop: steps → cancelled; aborted disclosure (above); server `/stop` force-posted (existing)
- Queued message behavior: queue survives a manual stop and dispatches after (existing) — surface this in the QueuedCard hint

## Streaming state summary table

| Phase | Composer | WorkLog header | Row state |
|---|---|---|---|
| Thinking | Stop visible | "Thinking for Xs…" + dots | — |
| Tool running | Stop visible | "Worked for Xs" (live) | spinner + present verb |
| Text streaming | Stop + caret in text | "Worked for Xs" | — |
| Queued message | Queue-as-send | — | QueuedCard above composer |
| Completed | Send (disabled if empty) | "Worked for Xs ▸" | past tense + durations |
| Error | Send | receipt + error row | failed rows flagged |
| Aborted | Send | "Worked for Xs ▸" + stopped row | "(Cancelled)" suffix |
