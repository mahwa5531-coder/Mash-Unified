# 26 — Visual QA Specification

Checklist for comparing implementation against the target design, plus screenshot comparison methodology.

## QA checklist

### Spacing & alignment
- [ ] 4px grid: no odd arbitrary paddings (`py-[3.5px]`-class values eliminated or justified)
- [ ] Row heights: session 30 · artifact 28 · tool 24 · menu 32 · toolbar 36 · titlebar 28 · status 24
- [ ] Chat column `max-w-3xl` centered; composer aligned to same column
- [ ] Turn rhythm: 12px intra-turn gaps, 14px turn separation, border-b between turns
- [ ] Panel paddings: 12px card inner, 12px list gaps, 24px section spacing
- [ ] Icon optical alignment in rows (icon 14px centered to 24px row text line)

### Typography
- [ ] Type roles only (file 18): display 20 / heading 16 / subheading 14 / body 14 / body-sm 13 / caption 12 / label 11 / mono 12 / mono-sm 11
- [ ] No half-point sizes remain (11.5, 12.5, 13.5 eliminated)
- [ ] Mono used for: timestamps, durations, counts, commands, paths, badges, status bar — nowhere else
- [ ] Numeric cells right-aligned tabular mono in every table
- [ ] Markdown: h1 20 border-b · h2 16 border-b · h3 14 semibold

### Colors
- [ ] Zero hardcoded hex in components (grep `#[0-9a-fA-F]{3,8}` in `components/` → only FileIcon brand colors allowed, plus token definitions)
- [ ] Semantic mapping exact: COMPLIANT/PASS→success · EXCEPTION/FAIL→danger · WARNING/HIGH RISK→warning · CONTROL DEFICIENCY→info · NOTE→muted
- [ ] Accent used only for interactive/brand; one blue anywhere
- [ ] Contrast pairs from file 14 pass AA (body 4.5:1, graphics 3:1)

### Borders / radius / shadows
- [ ] Radius scale only (4/6/8/12/16/full); modals 16, cards 12, controls 8, chips 6, badges 4
- [ ] Border weights: 1px everywhere; callouts `border-l-[3px]`
- [ ] Shadow ladder: sm (cards) / md (popovers) / lg (modals); dark shadows carry explicit alpha

### Hover / focus / active
- [ ] Every interactive element: hover state (120ms) + **focus-visible ring** (accent, 2px offset)
- [ ] Focus order: titlebar → sidebar → chat → composer → viewer; Tab never escapes an open modal/menu/lightbox
- [ ] Active states: scale only on ≥28px buttons (.99); no layout shift on any state change

### Loading / streaming / error
- [ ] Spinner = tool/procedure running · Dots = agent thinking · Skeleton = deferred content — never mixed
- [ ] Streaming: caret visible; Stop visible; composer accepts queue with hint
- [ ] Error disclosures: Terminated/Disconnected/Stopped with correct severity colors; Continue present
- [ ] Failed tool rows: danger verb + icon + auto-expanded once

### Scrolling / resizing / panels
- [ ] Autoscroll armed/disarmed consistently (single 20px threshold)
- [ ] Scroll-anchored pagination: no jump on "Load earlier"
- [ ] Resize: both panels keyboard-accessible; widths persist across reload
- [ ] Sticky user header never covers the WorkLog toggle (44px scroll-margin)
- [ ] Viewer maximize → "Return to chat" pill + Esc

### Dark & light mode
- [ ] Both themes fully themed — **no always-dark components** (compare titlebar, toolbar, banners, sign-in, settings)
- [ ] Theme presets (Default/OLED/Antigravity/Pure White) apply to all new tokens
- [ ] `prefers-reduced-motion`: dots/spinners/pulse disabled; transitions ≤150ms

### Keyboard & accessibility
- [ ] Shell shortcuts (⌘B, ⌘., ⌘K, Esc hierarchy, ⌘Enter proceed)
- [ ] All controls operable by keyboard; menus arrow-navigable; context menu openable via keyboard
- [ ] `aria-live` announcements: turn start / tool summary / completion
- [ ] axe-clean on: empty, chat streaming, viewer (each type), settings, history, modals

### Performance
- [ ] Streaming: no long task >100ms; heap plateaus
- [ ] Session open <300ms at 100 turns; "Load earlier" <150ms
- [ ] Terminal/console DOM capped; soak test passes (file 13 plan)

## Screenshot comparison methodology

1. **Fixed harness:** viewport 1512×932, `prefers-reduced-motion: reduce` OFF for motion shots, deterministic mock scenarios (the scripted-SSE approach used in this research — reuse `scripts/mock_backend.mjs` scenarios as fixtures).
2. **Canonical set:** re-capture the same 28 states from file 07 at every phase gate (the filenames double as the spec).
3. **Comparison:** side-by-side diff at 100% zoom; overlay diff (pixelmatch-style) tolerances: Phase 1 token work ≤3% pixels; zero-tolerance for: overlap regressions, contrast failures, broken states.
4. **Annotate:** every diff screenshot gets region callouts (sidebar/chat/viewer/status) matching file 07's annotation scheme — reviewers must be able to name the responsible component for any pixel change.
5. **Both themes × 3 widths:** each canonical shot repeated dark/light at 1512/1200/900 → 6 variants; overlay-panel behavior verified at 1200.
6. **Gate rule:** a phase passes when its checklist section is green AND the canonical set shows no unintended drift outside the phase's declared visual effect (file 25).
