# 22 — App Shell Specification (Target Layout)

*Measurements chosen to preserve today's proven geometry (file 08) while fixing the documented issues.*

## The shell

```text
┌────────────────────────────────────────────────────────────────────────┐
│ TitleBar  28px   MASH · File View Window ·          ⏤   □   ✕        │  --m-bg-titlebar
├──────────┬───────────────────────────────────────────┬────────────────┤
│          │ Toolbar 36px  ◧ ‹ ›   Repo › Session      │ Viewer hdr 36px│
│  Sidebar │───────────────────────────────────────────│────────────────│
│  260px   │                                           │                │
│  (220–   │            CHAT COLUMN                    │   VIEWER       │
│   450)   │         max-w-3xl (768px)                 │   420px        │
│          │         centered                          │   (320–1100)   │
│          │                                           │                │
│          │                                           │                │
│          │───────────────────────────────────────────│                │
│          │ Composer dock (transparent, pb-3)         │                │
├──────────┴───────────────────────────────────────────┴────────────────┤
│ StatusBar 24px   session · model · budget   ● conn   ⧗ 2 procedures  │  NEW
└────────────────────────────────────────────────────────────────────────┘
```

## Panel specification

| Panel | Default | Min | Max | Resize | Collapse | Persisted |
|---|---|---|---|---|---|---|
| Sidebar | 260px | 220 | 450 | right-edge handle (4px hit / 2px grip), rAF, keyboard ←/→ | hides completely; toolbar shows logo+PanelLeft+nav cluster | **width → localStorage (NEW, fixes M4)** |
| Chat | fluid | 480 usable | 768 content | — (follows window) | only via viewer Maximize | n/a |
| Viewer | 420px | 320 | min(1100, vw−480) | left-edge handle, direct-DOM drag (keep), keyboard | hides; PanelRight toggle in toolbar | width + open-state + per-session tabs (memory kept; **width → localStorage NEW**) |

## Behavior rules

- **Heights:** titlebar 28 · toolbar 36 · viewer sub-header 32 · statusbar 24 — all `shrink-0`; only the three body columns scroll.
- **Scrolling:** each column scrolls independently (existing). Scrollbars remain hidden (existing global rule) with **scroll shading** (gradient fades) on sidebar (existing) extended to Working Papers list (NEW) so hidden scrollbars still communicate position.
- **Maximize viewer:** viewer → `flex-1 w-full`; chat column hidden; **"Return to chat" pill** floats bottom-left of viewer (NEW). Esc also un-maximizes (NEW).
- **Composer placement:** docked at chat column bottom, `max-w-3xl` aligned with feed; never overlaid by viewer.
- **Sticky user header:** stays, **but** the WorkLog toggle gains a 44px top clearance (scroll-margin) so it can never be covered (fixes C3).
- **Z-order:** content < sticky(20) < FAB(30) < toolbar(40) < titlebar(50) < popover(60) < modal(70) < lightbox(80) < nested confirm(90).
- **Responsive:** ≥1440 all three panels comfortable · 1200–1439 viewer default 380px · **<1200 viewer becomes overlay** (slides from right, 480px or 90vw, chat dimmed, Esc/click-outside closes) · **<900 sidebar auto-collapses** to toolbar cluster · <640 not supported (desktop product; show a friendly notice).

## TitleBar (window chrome)

- Keep the desktop metaphor (28px, menus, window buttons) — it's the product's identity.
- **Menus become real (NEW):** File (New session/Export transcript), View (toggle panels/theme), Window (maximize viewer) — today they're dead text (M9). v1 may just open Settings/shortcuts; the point is they stop being lies.
- Window buttons keep current semantics but get honest tooltips: "Toggle sidebar" / "Fullscreen" / "New session (reset)".

## Toolbar (36px, per column)

- Sidebar toolbar (when sidebar open): logo · PanelLeft · ‹ › (only when history exists — **NEW: disabled state instead of dead buttons**) · New Conversation
- Chat toolbar: breadcrumb (Repo › Session, truncation kept) · PanelRight (when viewer closed) · connection indicator on narrow
- Viewer toolbar: Explorer/Editor mode icons · tabs · Maximize · PanelRight

## StatusBar (NEW, 24px)

`◐ sess_demo… · model default · budget high │ ● Connected │ ⧗ 2 procedures running`
- Left: session id (mono-sm) · model · thinking budget (future picker)
- Center/right: connection dot (success=danger only on loss, running pulse during reconnect) · running procedures count (click → viewer explorer)
- Housed in `AppShell`; data from existing polls (no new endpoints)

## Keyboard map (shell-level)

| Keys | Action |
|---|---|
| ⌘/Ctrl+B | toggle sidebar |
| ⌘/Ctrl+. | toggle viewer |
| ⌘/Ctrl+K | command palette |
| Esc | close: lightbox → context menu → palette → modal → un-maximize viewer |
| ⌘/Ctrl+Enter | Proceed (plan card focused/hovered — existing global rule kept) |
| ←/→ on resize handle | resize panel by 8px (focus on handle) |

## Density options (v2)

- Default (spec above) · Compact: rows 30→26, tool rows 24→22, turn gap 12→8 — via `data-density="compact"` swapping 6 spacing tokens (Linear-style). Not in v1.
