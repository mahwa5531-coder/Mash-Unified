# 04 — Component Inventory & Relationship Tree

Every UI component in the frontend, with responsibility, props, state, data sources, and styling approach. File paths relative to `frontend/src/`.

## Component tree (actual)

```text
page.tsx (App shell — no router)
│
├── [Title bar] (inline in page.tsx — NOT a component)
│   └── MASH · File · View · Window · minimize / maximize(fullscreen) / close(reset)
│
├── ErrorBoundary scope="workbench-root"            ← fallbackRender: "MASH Recovered From Error"
│   └── TooltipProvider (Radix, delay 150ms)
│       ├── Sidebar                                  (left rail, 1101 L)
│       │   ├── Header row: M logo · PanelLeft · ArrowLeft/Right
│       │   ├── "New Conversation" button (Plus)
│       │   ├── "Conversation History" row (Clock)
│       │   ├── Section: PINNED (sticky top-0)
│       │   ├── Section: WORKSPACES (project folders → nested sessions)
│       │   │   ├── WorkspaceSwitcher popover (New Project / Quick Start)   [inline]
│       │   │   └── SessionItem rows (spinner | unread-dot | relative-time | ⋮)
│       │   ├── Section: CONVERSATIONS (flat sessions)
│       │   ├── ContextMenu (fixed, viewport-clamped: Pin/Rename/Copy ID/Archive/Delete) [inline]
│       │   ├── RenameInput (inline edit)
│       │   ├── Bottom gradient fade
│       │   └── Footer: Settings button
│       │
│       ├── Center column
│       │   ├── Toolbar row (inline in page.tsx): M logo (when sidebar closed) · PanelLeft ·
│       │   │   back/forward · Breadcrumb (Repo › Session|History) · PanelRight toggle
│       │   │
│       │   ├── [isHistoryActive]
│       │   │   └── ConversationHistory              (full-page list)
│       │   │       ├── Search box + clear ✕
│       │   │       ├── Active / Archived tabs
│       │   │       ├── Filter pill (all|workspace|outside)
│       │   │       └── History rows (hover: Archive / Delete + inline confirm)
│       │   │
│       │   └── ChatCanvas                           (426 L)
│       │       ├── History error tile (Retry) | Buffering skeleton (pulse)
│       │       ├── Turn feed (flex flex-col space-y-3.5)
│       │       │   └── Turn
│       │       │       ├── UserMessage              (sticky note card, sticky header)
│       │       │       │   └── hover: timestamp · Copy · Undo2
│       │       │       └── AssistantMessage(s)      (ErrorBoundary scope="assistant-turn")
│       │       │           ├── TaskWorkLogAccordion (activity timeline)
│       │       │           │   ├── "Worked for Xs" header / "Thinking for Xs…" live
│       │       │           │   ├── Thought row (expandable markdown card)
│       │       │           │   ├── Tool rows (command/file_read/edit/search/subagent/…)
│       │       │           │   │   ├── FilePill (clickable file chip)
│       │       │           │   │   └── Command console (expandable output)
│       │       │           │   └── [disabled] group cards: command_group/exploration_group/edit_group
│       │       │           ├── Markdown body (ReactMarkdown + GFM + math)
│       │       │           │   ├── p/h1-h4/strong/a/ul/hr custom renderers
│       │       │           │   ├── code → CodeBlock | MermaidRenderer | KaTeX
│       │       │           │   ├── table → TableContainer (Copy for Excel / CSV)
│       │       │           │   ├── blockquote → CalloutBlockquote → Blockquote
│       │       │           │   ├── img → framed card → Lightbox (portal)
│       │       │           │   └── inline: audit status badges + file-path pills
│       │       │           ├── Error disclosure ("Terminated"/"Disconnected" + Continue)
│       │       │           ├── Aborted disclosure ("Stopped")
│       │       │           ├── ArtifactCard[] (per turn-message)
│       │       │           ├── FilesChangedDrawer (N files changed +N −N, Review)
│       │       │           └── Footer: timestamp · copy response
│       │       ├── Pagination pills (Load earlier / Jump to latest)
│       │       ├── QueuedMessageCard (inject / edit / delete)
│       │       ├── QuotaBanner (inline above composer)
│       │       ├── ScrollToBottomButton (FAB, -top-11)
│       │       └── ChatComposer
│       │           ├── Attachment chips (thumb/Paperclip + name + ✕)
│       │           ├── textarea (auto-resize ≤220px)
│       │           └── buttons: attach(+) | send ▲ | queue ▲ | stop ■
│       │
│       └── RightSidebar                              (1285 L)
│           ├── Header: FolderKanban(explorer) | BookOpen(editor) · tabs · Maximize · PanelRight
│           ├── Explorer mode
│           │   ├── CollapsibleSection "Working Papers" (count badge, filter input, See all)
│           │   │   └── artifact rows (FileIcon + title + extension badge)
│           │   ├── CollapsibleSection "Audit Procedures in Progress" (collapsed by default)
│           │   │   └── task rows (spinner/Clock/Check + mono command + kill)
│           │   └── Empty state ("No workpaper selected" + Browse Workpapers)
│           └── Editor mode
│               ├── Tab bar (file/terminal tabs, close ✕)
│               ├── Sub-header: breadcrumb · Preview|Raw pill · ⋮ dropdown (Copy/Download/Close)
│               ├── SafeFileViewer (ErrorBoundary scope="safe-file-viewer")
│               │   ├── Loading / image / UniverExcelViewer / PDF embed /
│               │   │   markdown preview (→ Mermaid/TableContainer/Callout) /
│               │   │   Monaco code / raw pre / unsupported download card
│               │   └── Toolbar (lines · KB · Preview/Raw · Format JSON · Wrap · Copy · Download)
│               └── Terminal viewer (status chip · command · Cancel Task · SSE log + gutter)
│
└── SettingsModal (createPortal → body)
    ├── Left nav: General/Appearance/Application/Browser · PROJECTS · Shortcuts ·
    │             Provide Feedback · profile chip (→ Account)
    └── Right pane: Appearance (theme engine) | Project (folder + Danger Zone) |
                    Account (toggles, plan, Sign Out → confirm overlay)

Unattached (dead): PlanApprovalModal — approval UI never mounted anywhere.
```

## Component inventory table

Legend: **R** = reusable-primitive, **F** = feature-specific. Styling: **CV** = CSS variables, **Z** = zinc Tailwind palette + dark: variants, **H** = hardcoded hex.

| Component | Path | Responsibility | Parent | Key props | Local state (summary) | External state / APIs | Styling | R/F |
|---|---|---|---|---|---|---|---|---|
| `Home` | `app/page.tsx` | App shell, layout orchestration, theme, auth gate | — | — | authUser, sessionId/Title/Repo, sidebar/right states, archived ids | fetchAuthMe, fetchSessions, deleteSession | Z+H (#0d0d0f, #121214) | F |
| `Sidebar` | `components/Sidebar.tsx` | Session/workspace nav, context menus, resize | page.tsx | selection + 13 callbacks + width | sessions, projects, pinned, menus, rename, folders, width | fetchSessions/Projects (5s poll), rename, delete, selectFolder, createProject | Z+H (#121214) | F |
| `ChatCanvas` | `components/ChatCanvas.tsx` | Chat surface, turn windowing, empty state | page.tsx | sessionId, callbacks | queueExpanded, quotaBanner, windowOffset | useChatStream (send/stop/turns/artifacts) | CV+Z | F |
| `ChatComposer` | `components/chat/ChatComposer.tsx` | Input, attachments, send/queue/stop | ChatCanvas | inputPrompt, onSend, onStop, isStreaming | localPrompt, attachedFiles, isUploading, isSubmitting | uploadSessionFile | Z | F |
| `AssistantMessage` | `components/messages/AssistantMessage.tsx` | Renders one AI message end-to-end | ChatCanvas | msg, artifacts, isLast, isStreaming, onOpenFile | lightbox state | — (pure render + memo) | Z+CV | F |
| `UserMessage` | `components/messages/UserMessage.tsx` | User card, hover actions, expand/collapse | ChatCanvas | msg, onUndo | expanded | — | Z+H (#f4f4f6/#18181b) | F |
| `TaskWorkLogAccordion` | `components/chat/TaskWorkLogAccordion.tsx` | Agent activity timeline | AssistantMessage | steps, thoughts, tools, isStreaming | clusterOpen, expandedThoughts, expandedCmd, copied, liveThinkingSeconds | — (onOpenFile cb) | Z | F |
| `ArtifactCard` | `components/chat/ArtifactCard.tsx` | Deliverable card | AssistantMessage | artifact, onOpen | (proceeded local flag) | BASE_URL raw download | Z | F |
| `FilesChangedDrawer` | `components/chat/FilesChangedDrawer.tsx` | Edited files summary | AssistantMessage | files, totals, onOpenFile | isOpen | — | Z | F |
| `CodeBlock` | `components/messages/CodeBlock.tsx` | Fenced code + highlighter | AssistantMessage, SafeFileViewer | language, code, isStreaming | copied, collapsed | — | CV | R |
| `CalloutBlockquote` | `components/messages/CalloutBlockquote.tsx` | GitHub alerts/color callouts | markdown renderers | children | — | — | Z | R |
| `TableContainer` | `components/messages/TableContainer.tsx` | Table wrapper + exports | markdown renderers | children | copied | clipboard, Blob download | Z | R |
| `MermaidRenderer` | `components/chat/MermaidRenderer.tsx` | Diagram render + zoom + fallback | markdown code renderer | chart, isStreaming | svg, zoom, view, err | dynamic import mermaid | CV+Z | F |
| `QuotaBanner` | `components/chat/QuotaBanner.tsx` | Quota upsell banner | ChatCanvas | open, title, actions | — | — | **H (always dark)** | F |
| `ScrollToBottomButton` | `components/chat/ScrollToBottomButton.tsx` | Jump-to-latest FAB | ChatCanvas | onClick | — | — | **H (always dark)** | R |
| `SafeFileViewer` | `components/SafeFileViewer.tsx` | Type-dispatched file viewer | RightSidebar | filename, content, viewMode | showAll, copied, json, wrap | BASE_URL image/pdf URLs | CV+Z | F |
| `UniverExcelViewer(+Inner)` | `components/common/Univer*.tsx` | Spreadsheet canvas | SafeFileViewer | data/filename/path | workbook, loading, error | /files/univer | Z | F |
| `FileIcon` | `components/common/FileIcon.tsx` | Brand file icons | many | filename, size | — | — | H (brand hexes) | R |
| `Blockquote` | `components/common/Blockquote.tsx` | Colored quote primitive | CalloutBlockquote | color, cite | — | — | Z | R |
| `RightSidebar` | `components/RightSidebar.tsx` | Explorer + editor + terminal | page.tsx | fileToOpen, isMaximized | tabs, content, artifacts, tasks, width, statuses | fetchSessionArtifacts (3s poll), fetchBackgroundTasks, fetchFileContent, fetchTaskLog, SSE task stream | Z+H (#121214) | F |
| `ConversationHistory` | `components/ConversationHistory.tsx` | Session list page | page.tsx | sessions, callbacks | search, tab, visibleCount, confirmDelete | formatRelativeTime, generateCleanSessionTitle (utils) | CV+Z | F |
| `SettingsModal` | `components/SettingsModal.tsx` | Settings dialog | page.tsx (portal) | isOpen, onThemeChange… | activeTab, themeConfig, projects, confirmSignOut | fetchProjects, deleteProject, fetchAuthMe, logoutUser | Z+H (#141416…) | F |
| `DesktopSignInView` | `components/auth/DesktopSignInView.tsx` | OAuth gate | page.tsx | onAuthSuccess | email, password, isSignUp, isPolling | fetchAuthMe (1500ms poll), gateway URL | **H (always dark)** | F |
| `PlanApprovalModal` | `components/PlanApprovalModal.tsx` | ⚠️ Plan approval (DEAD) | *(none)* | sessionId, planContent | executionMode, feedback, submitting | approvePlan | CV | F |
| `ErrorBoundary` | `components/ErrorBoundary.tsx` | Scoped crash containment | page, ChatCanvas, RightSidebar | scope, fallbackRender | hasError, error | — | Z | R |
| `ui/*` (11 files) | `components/ui/` | shadcn primitives (badge, breadcrumb, button, card, dropdown-menu, input, label, separator, tabs, tooltip) | everywhere | — | — | — | Z (CVA variants) | R |

## Hooks

| Hook | Path | Responsibility |
|---|---|---|
| `useChatStream` | `hooks/useChatStream.ts` | The streaming engine: sessionStore, SSE handlers, send/stop/retry/undo, pagination, artifacts map, background-task polling (3500ms). Returns 20+ values consumed by ChatCanvas. |
| `useScrollToBottom` | `hooks/useScrollToBottom.ts` | Velocity-aware autoscroll (scroll-up disarms, at-bottom re-arms; 20px threshold). |
| `useIsDarkMode` | `hooks/useIsDarkMode.ts` | Reactive dark detection via MutationObserver on `<html>` class/data-theme. |

## Data-layer modules

| Module | Path | Responsibility |
|---|---|---|
| `apiClient` | `utils/apiClient.ts` | 30 endpoint functions, safeFetch retry, streamQuery SSE parser, title generator, formatters, caches/tombstones. |
| `turns` | `lib/turns.ts` | `parseTranscriptLines` (raw→Message[]) + `buildTurns` (Message[]→Turn[]). |
| `types` | `lib/types.ts` | Turn/ArtifactItem/EditedFileItem + canonical re-exports. |
| `artifactExtraction` | `lib/artifactExtraction.ts` | `extractArtifacts` (tool args + markdown links), `extractEditedFiles` (edit tools + patch parsing), canonical grouping. |
| `parseTranscript` | `utils/parseTranscript.ts` | Types only (Message/ToolCall/SubTask/Step/TurnStatus/ExecutionStep). |

## Reuse / duplication notes

- **Feature-specific dominates**: only `ui/*`, `CodeBlock`, `FileIcon`, `Blockquote`, `CalloutBlockquote`, `TableContainer`, `ScrollToBottomButton`, `ErrorBoundary` are broadly reusable.
- **Inline sub-components** (context menu, workspace popover, file pills, status badges, FilePill, FileViewer toolbar) live inside their parents — they cannot be reused or independently tested. The largest offenders: `Sidebar` (menu + popover + rename), `RightSidebar` (explorer + editor + terminal), `TaskWorkLogAccordion` (7 row types + console + pills).
- **Two parallel markdown render stacks**: `AssistantMessage` (chat, with badges/pills/streams) and `SafeFileViewer` (viewer, with mermaid/tables/callouts but different `th` styles) — duplicated renderer config, different table header styles.
