# 23 — Target Frontend Architecture

*Proposed only — NOT implemented. Guiding rule: conservative, reuse-first (see mapping in file 24).*

```text
MASh UI
│
├── Foundation                      src/foundation/
│   ├── tokens.css                  all --m-* tokens (file 18) + legacy aliases
│   ├── typography.css              type roles, markdown-body system
│   ├── motion.css                  durations/easings + prefers-reduced-motion
│   ├── a11y.css                    focus-visible rings, aria-live regions, sr-only
│   └── theme-engine.ts             SettingsModal's runtime var writer,
│                                   extracted + typed (presets, persistence)
│
├── Primitives                      src/components/primitives/  (from ui/* + new)
│   Button · IconButton · Input · Textarea · Pill · Badge · Chip · Tooltip ·
│   Menu · Modal · ConfirmDialog · SegmentedControl · Switch · Spinner · Dots ·
│   Skeleton · EmptyState · ContextMenu · Lightbox · CopyButton (one impl)
│
├── App Shell                       src/components/shell/
│   AppShell (state owner: panels, theme, shortcuts, status)
│   TitleBar · StatusBar · Sidebar · SidebarSection · SessionRow ·
│   ResizeHandle · ConversationHistory
│
├── Conversation                    src/components/chat/
│   ChatCanvas (orchestrator only) · Composer · AttachmentChip ·
│   UserBubble · ResponseBlock · StreamingText · TurnReceipt ·
│   MessageFooter · QueuedCard · StatusBadge · FilePill · QuotaBanner
│
├── Agent Activity                  src/components/agent/
│   WorkLog · ActivityRow · ToolRow · CommandConsole · ThoughtCard ·
│   ApprovalGate · ProcedureCard
│
├── Tools                           src/lib/agent/
│   toolVerbs.ts        (name → type/verb/icons mapping — extracted from
│                        TaskWorkLogAccordion's parseToolItem)
│   toolFilters.ts      (severity filter for WorkLog rows)
│   receipts.ts         (turn receipt computation)
│
├── Artifacts                       src/components/artifacts/ + src/lib/artifacts/
│   ArtifactCard · ArtifactGrid · VersionChip · FilesChangedSummary ·
│   ChangeSetReview
│   artifactExtraction.ts (existing, extended: pdf/docx classification)
│
├── Viewer                          src/components/viewer/
│   ViewerPanel · ViewerTabs · ViewerToolbar · BreadcrumbBar ·
│   PreviewRawToggle · viewers/ (MarkdownViewer, CodeViewer, SheetViewer,
│   TerminalViewer, ImageViewer, PdfViewer, UnsupportedCard)
│
├── Overlays                        src/components/overlays/
│   SettingsDialog · ProjectPicker · CommandPalette · QuotaBanner(rehomed) ·
│   ErrorDisclosure
│
└── Infrastructure                  src/infra/
    ├── api/            apiClient split by domain: sessions.ts · files.ts ·
    │                   tasks.ts · projects.ts · auth.ts · stream.ts · http.ts
    │                   (safeFetch + typed errors + single uploads impl)
    ├── stream/         event-parser.ts (SSE frame parser, pure) ·
    │                   event-handlers.ts (6 callbacks → store mutations) ·
    │                   stall-watchdog.ts
    ├── store/          session-store.ts (today's module Map + pub/sub,
    │                   extracted & typed) · local-storage.ts (namespaced
    │                   mash.*, migrates nexau_*)
    ├── markdown/       shared-renderer.tsx (ONE config for chat+viewer)
    │                   + audit extensions (badges, pills, numeric cells)
    └── format/         time.ts · numbers.ts · titles.ts (existing fns)
```

## Key architectural decisions

1. **No new libraries.** React 19 + Tailwind 4 + Radix + module stores stay. The pain is organization and tokens, not tech.
2. **`useChatStream` becomes thin.** Its 1182 lines split: transport → `infra/stream`, state → `infra/store/session-store`, policy (queue/retry/undo) stays in a smaller hook. Public API of the hook stays identical so ChatCanvas barely changes.
3. **One markdown engine.** `infra/markdown` serves chat and viewer; audit extensions (status badges, file pills, numeric cell alignment, callouts) become remark/rehype-adjacent renderer components registered once.
4. **Sidebar/RightSidebar decompose** into shell + section components with data hooks (`useSessions`, `useArtifacts`, `useBackgroundTasks`) owning fetch/poll. Rendering becomes pure.
5. **Theme engine is extracted and token-native** — it writes `--m-*` vars; legacy var names are aliased during migration.
6. **Event vocabulary codified** in `infra/stream/event-parser.ts` with a typed union — today's stringly-typed `.toUpperCase()` matching gets exhaustive switch + unknown-event counter (headroom events: RUN_STARTED, USAGE_UPDATE, COMPACTION_* get no-op handlers with TODO markers).
7. **Accessibility as architecture**: `a11y.css` + primitives own focus/trap/live-region behavior so feature code can't skip it.

## What explicitly does NOT change

- The AG-UI event contract and connector API (frontend-side only refactor).
- sessionStore semantics (LRU-25, buffers, pub/sub) — moved, not redesigned.
- The 768px chat column, 260/420 panel defaults, all current measurements that work.
- Memoization strategy (module-stable plugin arrays, WeakMap caches, turn windowing).
- The audit visual vocabulary (badges, verbs, pills, mono numerals) — codified, not replaced.

## Risks & mitigations

| Risk | Mitigation |
|---|---|
| Regression in streaming during store extraction | Phase it (file 25 P2) behind the existing hook API; property tests in `tests/fuzz_session_store.ts` extended to new modules |
| Token migration breaks theme engine | Co-exist legacy + new vars; visual QA per phase (file 26) |
| Decomposing Sidebar loses optimistic-delete nuance | Extract `useSessions` with the exact 7-step delete sequence as a unit test fixture |
| Shared markdown renderer subtly changes chat rendering | Snapshot existing chat DOM for 6 canonical messages before switch |
