# 15 — Reference Product Research

Study of leading agent/developer products. **OBSERVED FACT** vs **DESIGN RECOMMENDATION** are separated throughout. Sources: product documentation, reviews, and the agent-UX literature surfaced by web research (key article: "Agent UX Patterns: Chat-First UX Fails" — hatchworks.com; "Agent UX: designing UI for AI agents" — fuselabcreative.com; Antigravity coverage — gend.co, ortemtech.com; Raycast analyses — airframe.ai, skywork.ai). Where a claim is from my general product knowledge rather than a fetched source, it is marked *(general knowledge)*.

---

## ChatGPT (OpenAI)

**OBSERVED FACTS** *(general knowledge + ref image `ref-chatgpt-sidebar-and-chat-layout.jpg`)*
- Left rail: New chat, Search, Library, Projects — collapsible to icon rail; conversation list grouped by date buckets (Today/Yesterday/Previous 7 days).
- Composer is the visual anchor; empty state offers prompt starters; model picker lives in the composer header.
- Streaming uses a blinking-caret cursor; stop is always visible during generation; message actions appear on hover at the bottom of a message.
- Canvas/artifacts open a right side panel with its own toolbar; chat stays interactive.

**PATTERN** → sidebar as librarian (search-first, date-grouped), composer as command center, persistent stop.
**WHY IT WORKS** → zero-training surface; actions live exactly where attention is.
**MASh ADAPTATION** → date-grouped session list + search-in-sidebar; keep composer-centered hierarchy; make Stop persistent during turns.
**DOWNSIDE** → ChatGPT is consumer-calm; MASh needs audit-grade density — copy the structure, not the airiness.

## Claude (Anthropic)

**OBSERVED FACTS** *(ref image `ref-claude-sidebar-and-chat.jpg`; general knowledge)*
- Sidebar: Chats / Projects / Code sections — flat, minimal chrome.
- Artifacts: right panel with version switching, preview/code toggle per artifact type; artifact updates badge the panel rather than stealing focus.
- Thinking shown as collapsed "Thought for Xs" chip above the answer — exactly the pattern MASh already implements.

**PATTERN** → artifact panel with versions; unobtrusive thinking disclosure.
**WHY IT WORKS** → parallel work surface: read the report while the agent continues.
**MASh ADAPTATION** → artifact versioning in Working Papers (v1/v2 with canonical-group suppression already half-built); keep the thought-chip idiom.
**DOWNSIDE** → Claude's artifact panel is single-artifact; MASh audits produce multi-file working-paper sets — needs tabbed/list approach instead.

## OpenAI Codex

**OBSERVED FACTS** *(reviews: williamspurlock.com, arstechnica.com — fetched)*
- Task-centric: runs are first-class objects with diffs, logs, and approval gates; review happens per-task, not per-message.
- Diff review is the primary verification surface; chat is the coordination layer.

**PATTERN** → "review artifacts, not chat" (fetched source: "Agentic Engineering for PMs: Review Artifacts, Not Code").
**WHY IT WORKS** → matches how auditors actually sign off — inspect the workpaper, not the conversation.
**MASh ADAPTATION** → treat each generated working paper as a reviewable object: open → inspect → annotate/approve in the viewer, with the audit trail attached.
**DOWNSIDE** → task-first UIs need strong provenance links back to the prompt that spawned them.

## Cursor

**OBSERVED FACTS** *(reviews fetched: labhub "Diff View dramatically improved in 2.0", stork.ai model-switching; ref image `ref-cursor-ide-editor-panel.jpg`)*
- Agent activity inline in the editor gutter + sidebar; multi-file diffs reviewed as one changeset; accept/reject per hunk.
- Composer/agent panel shows plan → tool calls → edits as a compact stream; model switching per task.

**PATTERN** → unified changeset review (all edits in one drawer with +/− counts), per-hunk accept.
**WHY IT WORKS** → verification at the granularity of change; bulk trust is never required.
**MASh ADAPTATION** → FilesChangedDrawer → full changeset review with per-file diff open in viewer; "accept working paper" checkpoint.
**DOWNSIDE** → IDE-native; MASh's chat-first layout must approximate this via the right panel.

## Google Antigravity

**OBSERVED FACTS** *(fetched: gend.co, ortemtech.com, glbgpt.com, scribd docs)*
- **Manager view** orchestrates multiple parallel agents; **Artifacts** surface = plans, screenshots, recordings produced by agents; a Changes Sidebar shows what agents touched.
- Browser-in-the-loop for visual verification; artifact-first verification philosophy.

**PATTERN** → agent runs as parallel cards with artifact outputs; "verify by artifact, not by log".
**WHY IT WORKS** → scales oversight to multiple concurrent agents.
**MASh ADAPTATION** → the queued-message card and "Audit Procedures in Progress" list already nod to this; a future "procedures board" could show parallel audit steps as cards with status + artifact links.
**DOWNSIDE** → parallel-agent views add cognitive load MASh's single-auditor flow may not need yet.

## Linear

**OBSERVED FACTS** *(ref images `ref-linear-dark-dashboard.png`, `ref-linear-mobile-clean-minimal.png`; general knowledge)*
- Ruthlessly consistent type scale (12/13/14 + display), 6-8px spacing grid, keyboard-first (C/T/A shortcuts), density slider; dark mode with near-black surfaces and hairline borders.
- Icons at 14-16px, muted until hover; status via small colored dots/pills.

**PATTERN** → density without noise; keyboard as first-class; small consistent tokens.
**WHY IT WORKS** → enterprise users live in it all day; every pixel is accounted for.
**MASh ADAPTATION** → the token scale (file 18) borrows Linear's discipline: 3 body sizes, 1 mono size family, 4-step spacing, hairline borders.
**DOWNSIDE** → Linear's cold minimalism can feel uninviting — MASh should keep its audit-specific color language (emerald deliverables, amber warnings).

## Raycast

**OBSERVED FACTS** *(fetched: airframe.ai "keyboard-first launcher… single consistent interface", skywork.ai, explainx.ai DESIGN.md)*
- One command surface, list-first navigation, instant filtering, actions on Enter, everything reachable by keyboard; subtle borders + blur; 8px radii.

**PATTERN** → command-palette as universal navigation layer.
**MASh ADAPTATION** → a ⌘K palette for: switch session, open working paper, run audit procedure, toggle panels — over the existing structure.
**DOWNSIDE** → palette discoverability; needs shortcut cheat-sheet (Settings already has a Shortcuts tab placeholder).

## VS Code

**OBSERVED FACTS** *(general knowledge)*
- Activity bar → sidebar views → editor tabs → panel (terminal/problems); status bar carries ambient state; command palette for everything.
- Persistent identity: the same layout skeleton for a decade; users transfer skills instantly.

**PATTERN** → stable panel grammar + ambient status bar.
**MASh ADAPTATION** → MASh's shell already mirrors this (left rail / center / right panel / header). A thin status bar (session, model, connection, task count) would complete the metaphor and house the currently-invisible connection state.

## Cross-cutting agent-UX principles (from fetched literature)

From "Agent UX Patterns: Chat-First UX Fails. Use These Patterns Instead" (hatchworks.com, fetched 2026):
- **Chat-first fails for agents** because agentic work is asynchronous, long-running, multi-step; failure modes: invisible actions, unclear state, no pause, no recovery, no accountability trail.
- Prescribed control surfaces: **approvals, receipts, activity logs, rollback hooks, autonomy sliders** — "the UX you design is the control surface: start/stop, approvals, receipts, logs, rollback".
- Activity log pattern: "chronological log of agent decisions, tool calls, and state changes, filterable by severity and type, with collapsible verbosity levels".

From fuselabcreative.com (fetched): transparency, override architecture, confidence signaling as the three pillars of agent UI trust.

**MASh SCORECARD vs these principles:** activity log ✅ (TaskWorkLog), start/stop ✅ (composer + procedures), rollback ⚠️ (Undo exists per-user-message; no artifact rollback), approvals ❌ (dead PlanApprovalModal), receipts ⚠️ (artifact cards; no per-run summary receipt), autonomy slider ❌ (thinking budget exists in code, no UI), severity filtering ❌.

---

## Pattern → MASh opportunity table (DESIGN RECOMMENDATIONS ONLY)

| Reference pattern | MASh adaptation | Priority |
|---|---|---|
| ChatGPT date-grouped sidebar + search | Regroup sessions by date under Workspaces | High |
| Persistent Stop + streaming caret | Keep stop always visible during turns; add caret | High |
| Claude artifact versioning | Version chips on Working Papers (canonical groups exist) | High |
| Codex/Cursor changeset review | Upgrade FilesChangedDrawer → reviewable changeset | High |
| Antigravity artifacts-as-verification | Artifact-first turn summary card (receipt) | Medium |
| Linear token discipline | Adopt file-18 token scale | High |
| Linear density control | Optional compact mode (row heights 30→26px) | Low |
| Raycast command palette | ⌘K over existing shell | Medium |
| VS Code status bar | Connection/model/session status strip | Medium |
| Agent-UX approvals + autonomy | Revive PlanApprovalModal; expose thinking budget | High |
| Agent-UX receipts | End-of-turn receipt: files created, tools run, duration, exceptions | High |
