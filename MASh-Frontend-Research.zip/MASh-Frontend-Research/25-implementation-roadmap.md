# 25 — Implementation Roadmap (Phased)

*Plan only — no repository changes were made. Phases are sized to be independently shippable; each ends in a QA gate (file 26).*

## Phase 0 — Cleanup & safety net
**Goal:** make the repo safe to change.
- Files: `tests/`, `.github` (CI), `frontend/package.json` (scripts)
- Work: extend `tests/fuzz_session_store.ts`; add Playwright smoke specs for: load, send (mock SSE), session switch, viewer open; capture 6 canonical chat DOM snapshots for the markdown regression; baseline Lighthouse run.
- Delete dead code: `showTasksBar`, `fetchUploads`, `clearSessionQueue` (or wire), dead menu labels → decide.
- Risk: LOW · Visual effect: none · Testing: CI green with smoke suite.

## Phase 1 — Design tokens (the wedge)
**Goal:** one source of visual truth; light mode stops being broken.
- Files: **NEW** `src/foundation/tokens.css` (+ import in `globals.css`), `SettingsModal.tsx` (writes new vars), `page.tsx` (titlebar/toolbar consume tokens)
- Work: land file-18 tokens + legacy aliases; replace the 18 near-black hexes and `#0d0d0f/#121214` with `--m-bg-raised/titlebar/toolbar`; theme QuotaBanner, ScrollToBottomButton, sign-in, settings fallbacks.
- Components affected: all (class swaps only).
- Dependencies: Phase 0 · Risk: MEDIUM (wide but shallow) · Visual effect: subtle dark shifts (#18181b-family → #1A1A1D), **light mode fixed**.
- Testing: full-suite visual QA both themes; contrast audit vs file-14 pairs.

## Phase 2 — Infrastructure extraction
**Goal:** split the god-files without behavior change.
- Files: `utils/apiClient.ts` → `infra/api/*`; `hooks/useChatStream.ts` → `infra/store/session-store.ts` + `infra/stream/*`; `lib/turns.ts` rename plan.
- Components: none (hooks/lib only) · hook's public API frozen.
- Risk: MEDIUM-HIGH (streaming) · Visual effect: none · Testing: fuzz tests extended; streaming smoke on slow network; stall-watchdog unit tests.

## Phase 3 — Primitives + shared markdown
**Goal:** one Button, one CopyButton, one renderer.
- Files: `components/ui/*` → `primitives/*`; NEW SegmentedControl, ContextMenu, ConfirmDialog, CopyButton, Skeleton, EmptyState; `AssistantMessage` + `SafeFileViewer` → `infra/markdown/shared-renderer`.
- Risk: MEDIUM · Visual: identical intent (snapshot-verified) · Testing: DOM snapshots for 6 canonical messages; a11y axe pass on primitives.

## Phase 4 — App shell
**Goal:** stable shell + new StatusBar.
- Files: `page.tsx` → `shell/AppShell`, `TitleBar`, `StatusBar` (NEW), `Sidebar` split (`SidebarSection`, `SessionRow`, `useSessions`), `ResizeHandle` (shared, keyboard, persisted widths).
- Fixes shipped: C3 (scroll-margin on worklog toggle), M4 (persist widths), M9/M10 (real menus, honest tooltips), dead back/forward → disabled state.
- Risk: MEDIUM · Visual: +24px status bar; otherwise same geometry · Testing: shell keyboard map; resize persistence; Esc hierarchy.

## Phase 5 — Chat surface
**Goal:** composer + response polish.
- Files: `ChatComposer` → `chat/Composer` (+AttachmentChip), `AssistantMessage` → `chat/ResponseBlock` (+StreamingText caret), `UserMessage` → `chat/UserBubble`; QuotaBanner themed.
- Fixes: Stop always visible during streaming; queueing hint in placeholder; focus rings; `aria-live` turn announcements.
- Risk: MEDIUM · Visual: caret + button layout change · Testing: streaming QA both themes; SR pass.

## Phase 6 — Agent activity
**Goal:** the audit differentiator.
- Files: `TaskWorkLogAccordion` → `agent/WorkLog/ToolRow/CommandConsole/ThoughtCard`; NEW `TurnReceipt`; `lib/agent/toolVerbs.ts`.
- Fixes: **re-enable grouping** (H1); **failed tool state** (H4); console DOM cap (P4); severity filter (v2).
- Risk: MEDIUM · Visual: grouped rows, receipt line · Testing: replay fixture streams (tools/failures/cancel); perf trace on 50-tool turn.

## Phase 7 — Artifacts & viewer
**Goal:** complete artifact coverage + viewer hardening.
- Files: `artifactExtraction.ts` (+pdf/docx), `ArtifactCard` states, `RightSidebar` → `viewer/*` split, `SafeFileViewer` → viewers/*, NEW `VersionChip`; revive `PlanApprovalModal` → `agent/ApprovalGate` **wired to plan artifacts**.
- Fixes: H5 (pdf/docx), H3-class viewer issues, terminal DOM cap + reconnect notice, Univer unmount race (H8).
- Risk: MEDIUM-HIGH (viewer matrix) · Visual: version chips, approval modal appears · Testing: 7-type viewer matrix; approval e2e against mock; screenshots for all artifact states.

## Phase 8 — Polish
**Goal:** motion + microcopy + empty states.
- Files: `foundation/motion.css`; empty states (welcome starters, working-papers guidance); keyboard shortcuts (⌘K palette NEW); tooltips audit; copywriting pass (Cancelled/Canceled etc.).
- Risk: LOW · Visual: noticeable but small · Testing: shortcut map; reduced-motion verification.

## Phase 9 — Accessibility & performance
**Goal:** ship-grade quality gates.
- Files: `foundation/a11y.css`; focus traps in Modal/Lightbox/ContextMenu; `aria-live` regions; contrast fixes already in tokens — verify; perf: virtualize terminal, content-visibility on turns, memo Sidebar poll.
- Risk: LOW-MEDIUM · Testing: axe clean on all screens; keyboard-only walkthrough; file-13 measurement plan executed (streaming jank, big history, soak).

## Phase 10 — QA & release
**Goal:** confidence.
- Full file-26 checklist both themes × 3 viewports (1512/1200/900) · 28-screenshot regression set re-captured and diffed · fuzz + smoke + e2e in CI · performance budgets asserted (no task >100ms during stream; session open <300ms @100 turns).

## Sequencing & dependencies

```text
P0 ─► P1 ─► P3 ─► P4 ─► P5 ─► P6 ─► P7 ─► P8 ─► P9 ─► P10
       │                    (P2 can run parallel to P3,
       └─► P2 ────────────►  lands before P5 needs the store)
```

## Effort signals (rough, for planning)

| Phase | Relative size |
|---|---|
| 0 | S | 1 | M | 2 | L | 3 | M | 4 | M | 5 | M | 6 | L | 7 | L | 8 | S | 9 | M | 10 | M |
