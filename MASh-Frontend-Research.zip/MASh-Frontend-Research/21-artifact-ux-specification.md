# 21 — Artifact UX Specification

MASh creates real work products: Excel working papers, CSV extracts, PDF/Word reports, Markdown plans/walkthroughs, images/charts. This spec defines how they surface, open, preview, download, fail, and group — and the chat↔viewer relationship.

## Principles

1. **One object, three views**: every artifact exists as (a) an inline card in chat, (b) a row in Working Papers, (c) a tab in the viewer — same title, same icon, same object identity (path).
2. **Evidence-first**: opening an artifact must feel like opening the evidence file, not a modal simulation (hence the real viewer stack: Univer/Monaco/embed-PDF).
3. **Never lose a deliverable**: every write the agent performs is discoverable in Working Papers, even when the chat scrolls away.

## Artifact card (in chat)

```text
┌────────────────────────────────────────────────────────────┐
│ [▣ 32px tile]  WP Trade Payables Vouching      DELIVERABLE │
│ emerald tile   MUS sample of 58 items across…   [v2] ⤓ ⌖  │
└────────────────────────────────────────────────────────────┘
```
- **Anatomy:** icon tile (32px, radius-md, type color) · title (13px medium, truncate) · tag badge · optional VersionChip · summary (12px muted, truncate) · actions (hover-revealed: Download, Open)
- **Types & tags:** spreadsheet→`DELIVERABLE` emerald · chart→`VISUAL CHART` purple · plan→`PLAN` accent (gets Proceed) · walkthrough→`WALKTHROUGH` info · document(pdf/docx)→`DOCUMENT` zinc *(NEW — closes H5)* · code→`CODE` zinc
- **States:** default · hover (border + surface-hover) · **generating (NEW)**: skeleton tile + shimmer + "Writing working paper…" while the write tool runs (today cards appear only after turn end — acceptable v1, generating state for v2) · **failed (NEW)**: danger border, "Failed to write — Retry" · proceeded → `IMPLEMENTED` emerald chip
- **Interactions:** click card → open in viewer (deep-link `onOpenFile`) · Download → `${BASE_URL}/files/content?path=…&raw=true` (existing xlsx path, extended to all types) · Proceed (plan only) → Ctrl/Cmd+Enter supported (existing)

## File chip / file pill

- Inline mentions of paths inside prose/outputs: amber mono chip (`FileIcon` 13 + name, `max-w-[280px]` truncate + optional `#L12-80`), radius-sm, hover glow (existing), click → viewer. Shared primitive across chat + worklog (today: two implementations).

## Artifact status vocabulary

| Status | Visual | Set when |
|---|---|---|
| generating | skeleton + label | tool running (v2) |
| ready | normal card / row | tool result success |
| failed | danger border + retry | tool result error |
| versioned | vN chip | canonical group revised |
| implemented | emerald chip | plan Proceed clicked |

## Open behavior

1. Entry points: ArtifactCard · FilePill · Working Papers row · FilesChanged row · lightbox "Open in Sidebar".
2. `onOpenFile(path)` → right panel opens (420px default) → tab dedupe by path → **Preview/Raw toggle defaults**: xlsx→Sheet, md→Preview, code→Preview (Monaco), images→image, pdf→embed, terminal→log.
3. Focus policy: panel opens but **chat scroll never moves** (existing); tab becomes active; breadcrumb shows `Mash › … › file`.

## Preview behavior (per type)

| Type | Preview | Raw |
|---|---|---|
| xlsx/xls/csv | Univer canvas, read-only badge, sheet tabs, formula bar | JSON dump (existing) |
| md | shared markdown renderer (tables/badges/callouts/mermaid) | plain pre |
| code | Monaco (readOnly, 12.5px, minimap >100 lines, theme-aware) | plain pre + wrap toggle |
| png/jpg/svg | framed image ≤460px + caption + lightbox | n/a (open raw) |
| pdf | `<embed FitH>` + open-in-tab | n/a |
| docx/zip/exe | UnsupportedCard with icon + explanation + Download | n/a |
| terminal | live SSE log, gutter, status chip, Cancel Task | n/a |

Oversized files (>1.5MB server cap): amber banner "Displaying initial 1.5MB preview" + Download Full File (existing — kept).

## Download behavior

- Icon in card + viewer toolbar + UnsupportedCard + QuotaBanner-adjacent flows
- `window.open(BASE_URL/files/content?path=…&raw=true)` (existing); downloads keep original filename; success → no toast (silent, standard).

## Generated / failure states

- Generating: see card spec; Working Papers row shows shimmer placeholder with mono filename.
- Failure: card + row get danger border; Retry re-invokes via chat message ("Rewrite …") rather than silent re-run — audit trail preserved.
- Partial write: treat as failed (no half-artifacts).

## Multiple artifacts & grouping

- Cards stack vertically in turn order (existing `mt-3 flex flex-col gap-2`).
- **Canonical groups** (existing logic, now visible): `implementation_plan*` → plan group, `*walkthrough*` → walkthrough group — older cards suppressed from earlier turns; latest shows `v2…vN` chip with popover history (path + timestamp + "Open").
- Working Papers list: type-colored rows + extension badges + filter + "See all (N)" beyond 5 (existing — kept).
- **Grouping by engagement phase (v2):** sections in Working Papers — Plans / Working Papers / Charts / Reports — collapsing today's flat list.

## Chat ↔ viewer relationship (the core layout contract)

```text
┌──────────┬───────────────────────────┬───────────────┐
│ Sidebar  │   Chat (narrative+control)│  Viewer       │
│ 260px    │   max-w-3xl centered      │  420px→1100px │
│          │   artifacts inline        │  evidence     │
└──────────┴───────────────────────────┴───────────────┘
```
- Chat is never hidden by the viewer unless **Maximize** (existing); maximize hides chat (existing) — spec keeps this but adds a "Return to chat" pill overlay in maximized viewer (NEW, since today's escape is only the toolbar icons).
- Opening an artifact while streaming: viewer opens, chat continues streaming (parallel — existing behavior verified).
- On narrow widths (<1200px): viewer overlays as a sliding panel from right (NEW — today it squeezes); <900px sidebar auto-collapses (NEW).
- Artifact updates during a turn badge the viewer tab (dot) — NEW; today tab title is static.

## Working Papers panel (right, explorer mode)

- Section 1: WORKING PAPERS (count) — filter input >5 items, type icons, extension badges (existing) + phase grouping (v2) + version chips
- Section 2: AUDIT PROCEDURES IN PROGRESS — collapsed by default (kept); pulsing count chip when running (NEW — signals hidden activity); rows = ProcedureCard
- Empty state (no papers): mini empty-state with icon + "No working papers yet — deliverables the agent creates will appear here." + "Start an audit procedure" secondary CTA (NEW — today: one italic line)
