# 13 — Performance Findings

What the code already does well, where the risks are, and what to measure before launch. (No profiling was run — this is a static + behavioral audit; measurement plan included.)

## What's already engineered for performance

1. **rAF-batched streaming flush** — one `setChatMessages` per frame regardless of token rate; buffers drained as strings (cheap concat) before any React work.
2. **Turn windowing** — `MAX_LIVE_TURNS = 100` DOM cap with "Load earlier" pill (window shifts by 50).
3. **Memoization discipline** — module-level `remarkPlugins`/`rehypePlugins` arrays (stable identity), custom `memo` comparator on AssistantMessage (status/content/tools/steps/durations), `EMPTY_ARTIFACTS` singleton, `getCachedArtifacts` WeakMap, frozen artifact map during streaming, `buildTurns` O(n) with stable keys ("avoid 120fps GC thrashing" per source comment).
4. **Caches** — file content LRU (25) + in-flight dedup; session store LRU (25); module-level sidebar seed from localStorage (0ms first paint of session list).
5. **Direct-DOM resize** — right sidebar mutates `style.width` in rAF during drag (no React renders); iframe pointer-events shield prevents iframe hit-testing costs.
6. **Deferred heavy engines** — Monaco, Mermaid, Univer all `dynamic(ssr:false)`; CodeBlock skips highlighting while streaming; minimap only >100 lines; `contentVisibility:auto` + `containIntrinsicSize` on raw `<pre>`; `stopRenderingLineAfter:10000`.
7. **Poll hygiene** — tasks poll (3500ms) and sidebar poll (5000ms) skip when `document.hidden` and refresh on visibility.

## Risk register (investigate before launch)

| # | Risk | Where | Why it matters | Suggested probe |
|---|---|---|---|---|
| P1 | **Markdown re-parse of the streaming message on every flush** | AssistantMessage renders `msg.content` through ReactMarkdown each frame | remark/rehype pipeline runs on the whole growing string ~60×/s; long answers (audit reports) can drop frames late in a turn | Chrome Performance trace on a 5,000-word streamed answer; compare frame times first vs last 10% |
| P2 | **`buildTurns` re-runs per flush** | `useMemo([chatMessages])` — new array identity every flush | O(n) per frame over full history; with 100-turn window × multiple aiMsgs this is per-frame allocation churn | React DevTools profiler "why did you render" on a 50-turn session |
| P3 | **Sticky header + backdrop-blur repaint cost** | `backdrop-blur-md` over scrolling feed | Blur over long content is one of the most expensive compositing effects; combined with streaming content growth can jank on integrated GPUs | Profile scrolling during active stream with "Paint flashing" |
| P4 | **Uncontrolled tool output length in console `<pre>`** | TaskWorkLog console renders full output (`max-h-24` visual only — DOM stays full) | A 10k-line tool result = huge text node per row × N tools | Generate synthetic 1MB tool output; measure DOM node count + style recalc |
| P5 | **History re-parse on pagination** | `loadEarlierTurns` re-parses the **entire** rawLines array | O(total history) per page load; 100k-line sessions will stall the main thread on click | Time `parseTranscriptLines` on 50k lines (node bench exists in tests/) |
| P6 | **Per-frame object churn in flush** | flush constructs new arrays (`next = [...s.chatMessages]`, steps copies) per frame | GC pressure at 60fps — the code comments show the authors already fought this | Memory allocation sampling during stream |
| P7 | **Mermaid re-render on theme flip** | MermaidRenderer keys on isDark | Full diagram re-parse + layout; big diagrams (audit flowcharts) can block 100ms+ | Flip theme with a 50-node diagram mounted |
| P8 | **Monaco instance per tab** | SafeFileViewer mounts an editor per open tab | Each instance ~2–5MB heap; 5 open tabs = noticeable; no instance pooling | Open 5 code tabs; watch heap |
| P9 | **SSE terminal auto-scroll + innerHTML append** | RightSidebar terminal builds line spans per chunk (100ms flush) | Long-running tasks (hours) accumulate unbounded DOM | 10k-line task log; count nodes |
| P10 | **Session-list 5s poll re-renders Sidebar** | fetchSessions → setSessions (new array identity) every 5s | Sidebar subtree re-render (mitigated by memo? — Sidebar is NOT memoized; page.tsx uses stable callbacks but state identity changes) | Profiler 30s idle with window visible |
| P11 | **`artifactExtraction` regex cost on history load** | per-message WeakMap cached, but first load of a 100-turn session runs all regexes synchronously | One-time hitch on session open | Time session switch with 100 turns |
| P12 | **Loading dots animation + spinners always running** | CSS keyframes on 3 dots + N spinners during streaming | Trivial individually; on low-end hardware combined with blur (P3) matters | — |
| P13 | **No virtualization anywhere** | turn feed, artifact list, working papers, history list (50-item pages OK) | Working Papers >100 files or a 500-item history degrades | Synthetic lists |
| P14 | **Images in markdown have no lazy loading** | AssistantMessage `img` renderer | A report with 20 charts loads all at once | Network throttling test |

## Pre-launch measurement plan

1. **Streaming jank test** — script a 10-minute turn with continuous tokens (the mock server in this research can do it); record: FPS, long tasks >50ms, heap growth. Acceptance: no task >100ms, heap plateau.
2. **Big-history test** — seed 100k transcript lines; measure session open, "Load earlier" click, scroll FPS.
3. **Soak test** — 2h with a running background task + open terminal tab; watch DOM node count and memory.
4. **Multi-tab viewer** — 5 files open (md, py, xlsx, png, terminal); heap + interaction latency.
5. **Theme flip** — with heavy content mounted; catch Mermaid/Monaco/Univer re-init costs.
6. **Network-degraded SSE** — throttle to 64kbps; verify watchdog behavior and UI responsiveness during backpressure.

## Quick wins (low-risk, high-yield) — for the redesign backlog

- Memoize `Sidebar` on its prop set; diff `sessions` by identity-stable comparator in the poll.
- Virtualize the terminal log (keep last N lines, "scroll up to load").
- `content-visibility: auto` on turn containers (pattern already proven in SafeFileViewer).
- Cap console output DOM (e.g. 2,000 lines + "open full log" action).
- Debounce `buildTurns` to flush cadence (it already rides the same frame).
