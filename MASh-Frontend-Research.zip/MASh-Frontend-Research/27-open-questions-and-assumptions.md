# 27 — Open Questions & Assumptions

## Assumptions made during research (verify before redesign)

1. **Auth model.** The running app falls back to `DEFAULT_LOCAL_USER` (`auditor@mash.local`, plan enterprise) whenever `/api/auth/me` fails. I treated the OAuth sign-in view as a secondary surface, and the local-user workbench as the primary experience. If production always gates behind OAuth, weight the sign-in view higher in redesign priorities.
2. **Model/effort context.** `useChatStream` sends `context.model` and `thinking_effort` (default `'default'` / `'high'`) but no UI exposes them (no model picker exists). I assumed the backend consumes them and that a picker is a *future* feature, not a regression.
3. **`msg.tasks` / SubTask.** `TASKS_UPDATED` events populate `msg.tasks`, but no chat component renders SubTasks today (only the right-panel procedures list, which polls `/api/tasks` instead). Assumed SubTask rendering is intended future work, not dead data.
4. **Compaction UI.** `compactionBoundary/compactionSummary` flow through transcripts and turns (synthetic "[Earlier Context]" turns) but no visual treatment exists. Assumed compaction indicators are planned.
5. **Repo/workspace mapping.** In the live run, sessions with `repo_name` did not nest under their Workspaces folders (folders showed "Empty"; sessions listed flat under CONVERSATIONS). This may be mock-data fidelity (my sessions' repo names vs. project names) rather than a frontend bug — **verify against the real connector** before treating it as a defect.
6. **Windows-first environment.** Launchers are `.bat`/`.ps1`; paths in transcripts are `C:\…`. Assumed Windows is the primary deployment; Linux/macOS paths in this research were normalized by the frontend's own path-cleaner (verified).
7. **Performance findings are static-analysis + behavioral observations**, not profiled numbers (file 13 includes the measurement plan to convert them).

## Research-tooling disclosure (how screenshots were produced)

- The frontend ran unmodified (`npm install` + `npm run dev`, Next 16.2.12/Turbopack).
- Because no real NexAU runtime/credentials were available in this environment, a **mock connector** was run on port 8000 implementing the subset of the API the frontend calls (`/api/auth/me`, `/sessions`, `/sessions/{id}/transcript`, `/stream` SSE with AG-UI event shapes, `/files/content`, `/files/univer`, `/api/tasks` + task-log SSE, `/artifacts/session/{id}`, `/api/projects`, rename/view/queue/stop endpoints). It is saved at `scripts/mock_backend.mjs` **outside the repository** and is reusable as a deterministic QA fixture harness (recommended in file 26).
- All UI behavior shown in screenshots is therefore genuine frontend behavior; only payload *content* is synthetic (e.g., "Reliance Infra" vendor data).
- Screenshots were taken with headless Chromium (1512×932) and each was verified by a vision model; console errors/warnings were logged during the session and are reflected in files 12/13.

## Open questions for the team

| # | Question | Why it matters |
|---|---|---|
| Q1 | Is `PlanApprovalModal` abandoned or awaiting wiring? (Dead code with a live API.) | Decides Phase-7 scope |
| Q2 | Should PDF/Word reports surface as artifact cards? (RUN_GUIDE advertises them; extraction skips them.) | H5 |
| Q3 | Why was tool-call grouping disabled? (`groupToolEntries` returns ungrouped.) | H1 — re-enable or delete |
| Q4 | Is the window frame (File/View/Window, min/max/close) bound to a real desktop shell (Electron) later, or permanently decorative? | Decides TitleBar investment |
| Q5 | Target light-mode priority: full parity or dark-first product? | Sizes Phase 1 |
| Q6 | Do auditors need multi-session parallel streaming today (the store supports it)? | Weights unread/steering polish |
| Q7 | Is the 5s sidebar poll + 3s tasks poll acceptable long-term, or should the connector push session deltas? | Backend coordination |
| Q8 | Where should usage/token telemetry surface (`USAGE_UPDATE` events currently dropped)? | StatusBar design |
| Q9 | Minimum supported viewport? (No layout exists below ~900px.) | File 22 responsive rules |
| Q10 | Retention policy for session drafts (currently memory-only) and sidebar width (not persisted)? | Small UX wins |
