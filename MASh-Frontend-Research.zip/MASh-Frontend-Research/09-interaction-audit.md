# 09 — Interaction Audit

Each interaction documented as **Trigger → State change → UI change → Backend/API → Final state**. Findings marked ⚠️ are missing/inconsistent states.

## Global / window

| Interaction | Flow |
|---|---|
| Click window "minimize" (Minus) | Button in title bar → `setIsSidebarOpen(v=>!v)` → sidebar collapses/expands → none → sidebar toggled. ⚠️ **Misleading affordance**: a minimize-styled button toggles the sidebar, not the window. |
| Click "maximize" (Square) | → `document.documentElement.requestFullscreen()` / exit → browser fullscreen → none → fullscreen toggled. |
| Click "close" (X) | → `handleNewSession('No Repo')` → resets to new conversation → none → session context cleared. ⚠️ Red X implies quit; actually resets. |
| File / View / Window menu labels | → **no handlers** — decorative text with hover color only. ⚠️ Dead affordances. |
| Back / Forward buttons | → `window.history.back()/forward()` → **no router** — no-op (no navigation history exists). ⚠️ Dead buttons rendered enabled. |

## Sidebar

| Interaction | Flow |
|---|---|
| Hover session row | → CSS only: `hover:bg-white/[0.06]`, right slot swaps relative-time → ⋮ button (`group-hover`). |
| Click session | → clear local unread dot + `markSessionViewed` POST → selection state in page.tsx → `onSelectSession` → ChatCanvas loads (0ms from sessionStore, else transcript fetch) → session rendered; streaming sessions show a sky spinner in the row. |
| Click ⋮ / right-click row | → `activeMenuSessionId + menuPos` → fixed context menu (clamped to viewport, re-measured after mount) → none → menu with Pin/Rename/Copy ID/Archive/Delete. |
| Pin to top | → `pinnedSessionIds` Set + localStorage → row moves to PINNED sticky section, Pin icon fills sky → none → pinned. |
| Rename | → `editingSessionId` → inline input in row → Enter commits: `renameSession` POST + local title update; Esc/blur cancels. |
| Archive | → `archivedSessionIds` + localStorage `nexau_archived_session_ids` → row leaves list; appears under History › Archived tab → none → archived (no server call — ⚠️ client-side only). |
| Delete | → 7-step optimistic: close menu → tombstone (`deletedSessionIds`) → remove from state → `sessionStore.delete` → switch away if active → `deleteSession` DELETE fire-and-forget → parent notified. |
| Drag resize edge | → rAF-throttled mousemove, clamp 220–450 → `onWidthChange` state → width applies. ⚠️ Not persisted (resets to 260 on reload). |
| New Conversation (sidebar) | → `handleNewSession(repo)` → clears selection, `pendingWorkspacePath` → ChatCanvas empty state → none → new-session ready. |
| Workspaces ⋮ / + | → popover: **New Project** → folder picker chain (electronAPI → showDirectoryPicker+resolveFolder → backend selectFolder) → `createProject` POST → project appears, new session bound to it. **Quick Start** → `getQuickstartFolder` POST → session bound to quickstart dir. |
| Conversation History | → `handleOpenHistory`: `isHistoryActive=true` + `fetchSessions()` → center pane swaps to list → GET /sessions → list rendered. |
| Settings (footer) | → `settingsTab='appearance'`, `isSettingsOpen=true` → modal portal mounts → fetchProjects + fetchAuthMe on demand. |

## Chat

| Interaction | Flow |
|---|---|
| Type in composer | → `localPrompt` state (controlled) → auto-resize (≤220px) → none → send button enables when non-empty. |
| Enter / Shift+Enter | → `onKeyDown`: Enter (no shift) → `handleSendClick` (300ms lock) → send flow (05-A) → streaming begins; Shift+Enter inserts newline. |
| Paste image/file | → clipboard items → `uploadSessionFile` POST multipart → chip with preview → attachment staged; sent message gains `[Attached file: path]` markers. |
| Drag file over composer | → `isDragOver` → emerald border+ring, placeholder swaps → none → drop = upload. |
| Send while streaming (empty→text) | → queue path: `queuedMessage` + `queueSteeringMessage` POST → **Queued Messages card** appears (inject/edit/delete) → auto-dispatched 100ms after turn end (server queue also drained). |
| Inject queued (→) | → `injectQueued` (`isImmediate=true`) → abort + POST /stop → current turn aborted → queued message sent immediately. ⚠️ Destructive: silently kills the running turn. |
| Stop (■) | → `handleStop` → steps→cancelled, msg→aborted, abort + POST /stop force → "Stopped" disclosure → composer returns to Send. ⚠️ Only visible when input is empty; with text present the button becomes Queue (discovery issue). |
| Hover user card | → actions fade in (timestamp, Copy, Undo). |
| Undo up to here | → `handleUndoTurn(flatIdx, text, turnIdx)` → abort if needed, truncate messages, restore text to composer → DELETE /sessions/{sid}/undo `{from_turn}` → conversation truncated. |
| Click "Worked for Xs" | → `clusterOpen` toggle → `animate-in` rows reveal → none. ⚠️ At some scroll offsets the sticky user header covers this toggle (reproduced in research). |
| Click "Thought for Xs" | → expandedThoughts[id] → markdown card expands (auto-scrolls if near bottom). |
| Click tool row / chevron | → expandedCmdIndex (single-open) → console box with full command + output + copy + status icon. |
| Click FilePill | → `onOpenFile(path)` → right sidebar opens + tab + content fetch → file viewed. |
| Click artifact card | → same open flow → viewer shows file; xlsx downloads via raw URL link; plan shows **Proceed** button. |
| Proceed (plan) + Ctrl/Cmd+Enter global | → local "Implemented" chip + `onProceed` callback → none (chat-level; full approval API unused) → plan marked implemented. ⚠️ Approval POST /approve only reachable via dead PlanApprovalModal. |
| Copy for Excel (table) | → TSV to clipboard → button shows ✓ emerald 2s → none. CSV → Blob download `audit_table.csv`. |
| Copy code / response / prompt | → clipboard + ✓ state 2s. |
| Click image in markdown | → Lightbox portal (Esc/✕ close, "Open in Sidebar", external-link). |
| Mermaid zoom cluster | → zoom state 0.4–2.5 step 0.2 → `transform:scale` transition .15s; `</> Code` toggles source; SVG copies. |
| Scroll up during stream | → velocity hook disarms autoscroll (20px threshold) → streaming stops following; ScrollToBottom FAB appears when >~1 screen away. ⚠️ Second threshold (80px) in useChatStream can fight this. |
| Load earlier turns | → fetch offset page → prepend + scroll-anchor preserve → pill spinner during load. |
| Error → Continue | → `onContinue` (ChatCanvas resends last prompt) → new turn. |

## Right sidebar / viewer

| Interaction | Flow |
|---|---|
| Toggle open (PanelRight) | → `isRightSidebarOpen` → panel mounts (last width; per-session tabs restored from memory Map) → artifacts + tasks polls start (3s). |
| Explorer ↔ Editor icons | → `viewMode` → body swaps. |
| Click artifact row | → `openFileTab` (dedupe by id) → tab + content fetch (cache-aware) → viewer renders by type. |
| See all (N) | → `expandedSection.artifacts` → full list + filter input appears. |
| Filter working papers | → `artifactFilter` → client-side title match → filtered rows / "No matching working papers". |
| Collapse section | → `openSections[key]` → chevron rotates −90°, rows unmount. ⚠️ "Audit Procedures" collapsed by default (intended, but the count-only header hides running work). |
| Click task row | → terminal tab opens → `EventSource /api/tasks/{id}/stream` → live log appends (100ms flush), gutter line numbers, auto-scroll ≤60px from bottom → on `[DONE]` status chip → COMPLETED. |
| Cancel Task | → `killBackgroundTask(pid)` POST → optimistic remove → refetch. |
| Preview ↔ Raw | → `fileViewMode` → markdown/code ↔ raw pre toggle. |
| ⋮ menu | → Copy Content / Copy Path / Download-Open Raw (`window.open …&raw=true`) / Close Tab (red). |
| Close tab (✕) | → tab removed; last tab closes → "No file open" empty state. |
| Drag left edge | → direct DOM width mutation (rAF), iframe pointer-shield, clamp [320, min(1100, vw−420)] → commit on mouseup. |
| Maximize | → `isRightSidebarMaximized` → panel `flex-1 w-full`; **center column hides** (`hidden`) → restore returns width. |
| Wheel on breadcrumb | → horizontal scroll mapping. |

## Settings

| Interaction | Flow |
|---|---|
| Mode segmented (System/Light/Dark) | → ThemeConfig.mode; system follows `matchMedia` live → `<html>` class/data-theme + CSS vars set → localStorage `mash_theme_settings`. ⚠️ Runtime vars override but many hardcoded hexes don't respond (light-mode breakage). |
| Preset select | → preset values fill bg/fg/accent fields → vars applied immediately (live preview behind modal). |
| Edit hex fields | → "Custom" preset appears → same application path. |
| Delete project | → `window.confirm` guard → `deleteProject` DELETE → list updates; active session reset if it belonged to project. |
| Sign Out | → confirm overlay (zoom-in card) → `logoutUser` POST → `onSignOut` → auth gate view. ⚠️ Local fallback user makes sign-out cosmetic in dev. |
| Escape | → closes modal (keydown handler). |
| Telemetry/Updates toggles | → localStorage `mash_telemetry` / `mash_marketing` → no API call. |

## Missing / inconsistent states (summary)

1. No prompt starters/suggestions on the empty state.
2. No empty-state guidance when Working Papers has zero artifacts beyond one italic line (button exists but only in editor-mode empty state).
3. Streaming indicator relies on accordion only — no composer-level "working" pill or elapsed timer.
4. Tool **failure** state indistinguishable from success in the row (output text only).
5. Two "Collapse sidebar" tooltips (left PanelLeft & right PanelRight) — identical labels, different panels.
6. Back/Forward rendered but non-functional (no history).
7. No hover/active distinction for the breadcrumb (static text).
8. `retryLoadHistory` resets flags but the transcript effect's deps (`[sessionId, scrollContainerRef, updatePaginationState]`) may not re-run it — retry can require a session re-select.
