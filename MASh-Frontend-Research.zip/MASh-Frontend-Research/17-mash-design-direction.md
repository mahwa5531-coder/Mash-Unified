# 17 — MASh Design Direction

*Forward-looking specification — nothing in this section is implemented. Grounded in: the current frontend (files 02–14), MASh's product reality (audit workpapers, evidence, sign-off), and the reference research (file 15).*

## What MASh is, product-wise

A **professional evidence instrument**: an auditor asks, an agent reads ledgers, runs queries, and returns signed-off working papers. The UI's job is not to entertain — it is to make **what the agent did legible** and **what the agent produced verifiable**. Every design decision below serves those two jobs.

## Character evaluation (target scores)

| Axis | Target | Rationale |
|---|---|---|
| Professional | ●●●●● | CA-firm context; zero playfulness in chrome |
| Technical | ●●●●○ | mono for data, precise numerals, real paths |
| Precise | ●●●●● | audit = precision; no vague statuses |
| Calm | ●●●●○ | long-running procedures must not flicker/nag |
| Dense but readable | ●●●●○ | auditors scan hundreds of rows/day |
| Enterprise | ●●●●○ | multi-project, sign-in, plans |
| Fast | ●●●●● | instant switches (already 0ms from sessionStore — keep) |
| Minimal | ●●●○○ | minimal chrome, not minimal information |
| Agent-native | ●●●●● | activity/artifacts are first-class, not decoration |
| Audit-oriented | ●●●●● | the differentiator — lean in |

## What MASh should feel like

> **"A well-lit audit room at 9pm: quiet, precise, everything in its place, evidence within arm's reach."**

- Opening it should feel like opening a **workpaper file set** — not a chat toy. The empty state should read like an engagement launchpad (recent engagements, procedure starters), not a lone sparkle icon.
- A running turn should feel like **watching a colleague work**: compact status lines, occasional detail on demand, no theatrics. Time is always visible; progress is always attributed to a tool.
- A completed turn should feel like **receiving a signed document**: a receipt (what ran, what was produced, how long), the deliverables up-front, and one obvious next action (Review).
- The right panel is the **evidence drawer**: working papers, live procedures, diffs — the things an auditor will actually open and inspect.

## What MASh should NOT feel like

- Not a consumer chatbot (no cute empty states, no bouncing gradients, no emoji-adjacent motion).
- Not an IDE (auditors are not developers; no tab-soup, no gutter noise without labels).
- Not a dashboard (chat remains the spine; widgets don't replace narrative).
- Not a "black box" (never hide what the agent did behind vague spinners — the current design already avoids this; preserve it).
- Not loud: no accent abuse, no toast spam, no auto-opening panels that steal focus.

## Visual hierarchy (target)

1. **Content (answer + artifacts) > activity (what happened) > chrome (navigation).** Chrome is zinc-muted; answers are high-contrast; activity sits between at reduced weight.
2. **One accent** (audit blue #007ACC lineage) for interactive/brand; **semantic colors reserved for audit meaning** (emerald = verified deliverable, amber = caution/exception-adjacent, rose = exception/error). Never use semantic colors decoratively.
3. **Numbers are mono and right-aligned, always.** (MASh already does this in tables — promote to law.)
4. **Headers are labels, not content**: 11px uppercase section labels stay, but get a single definition.

## Information density

- Row heights: 28–32px standard (today's 30px is right); tool rows compact at ~24px with 8px gaps.
- Prefer **one-line summaries with expand** (current accordion idiom) over truncated paragraphs.
- Tables remain dense (12.5px cells) — they are the audit artifact, not marketing copy.
- Whitespace is spent on **separating turns and phases**, not inside rows.

## Interaction philosophy

- **Nothing destructive without a visible consequence preview** (Stop shows what will be cancelled; Inject warns it aborts the current run).
- **Every agent action is inspectable** (click anything → its evidence: file, command output, or thought summary).
- **Keyboard is professional-grade**: Enter/Shift+Enter (exists), Esc hierarchy, ⌘K palette, Ctrl+Enter proceed (exists), arrow-key menus.
- **Interruptibility is sacred**: Stop always reachable during a run; queueing is explicit and reversible (exists — keep and make the abort-warning explicit).
- **State is never a mystery**: connection, model, session, running procedures always visible (status strip).

## Decoration & animation budget

- Decoration: hairlines + one soft shadow level for overlays; **no gradients** (keep the existing bottom fade in sidebar — it's functional); no glassmorphism beyond existing overlay blur.
- Motion vocabulary (all respect `prefers-reduced-motion`):
  - 120–150ms color/opacity for hover/focus (matches current de-facto standard)
  - 200ms height/transform for accordion/drawer reveals (current)
  - Spinner + 3-dot loader retained as the only loading motifs
  - **No** streaming caret caret? — see decision below. *(Decision: add a subtle caret; it is the single most-requested "is it alive" signal in reference products, and MASh's dots live only inside the accordion.)*

## Chat ↔ artifacts relationship

- Chat is the **narrative and control** plane; artifacts are the **outcome** plane. The right viewer is where outcomes get inspected.
- Every artifact generated gets: an inline card (chat), a row (Working Papers), and a potential tab (viewer) — all pointing at the same object with the same title. (Mostly true today; needs versioning + PDF/DOCX coverage.)
- The viewer never blocks chat: maximize exists; on narrow widths, viewer wins over sidebar (already implicit — document it).

## Agent activity ↔ final answer relationship

- Activity is **collapsed by default, complete on demand** (current "Worked for Xs" — keep exactly this idiom).
- Activity rows summarize in **audit verbs** (Analyzed, Ran, Edited, Sampled) — extend the existing verb table rather than replacing it.
- The answer opens with a **turn receipt** when tools ran: `12 tool calls · 4 files · 46s · 3 exceptions` — a compact, scannable header for the result.
- Thinking stays a duration-only summary with expandable text; **never** surface raw chain-of-thought as first-class content (matches current behavior and the constraint in the task brief).

## Anti-goals (explicit)

- Do not copy ChatGPT's airiness, Claude's single-artifact panel, Cursor's IDE density, or Linear's coldness wholesale.
- Do not introduce a new framework, animation library, or state library to achieve this direction (see file 23 — target architecture stays React + Tailwind + module stores).
- Do not restyle everything at once — the token wedge (file 18) must land before any component work.
