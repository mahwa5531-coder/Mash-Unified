# 28 — Highest-Priority Findings

Ranked by (user impact × audit-domain criticality × effort to fix). Each entry: finding → evidence → recommended action → where it lands in the roadmap (file 25).

## 1. Approval UX is missing entirely (dead code + live API)
**Finding:** `PlanApprovalModal.tsx` (121 lines, fully styled, `approvePlan()` wired) is imported nowhere. The agent-approval control surface — the single most important *trust* control for an audit product — does not exist in the running UI.
**Evidence:** repo-wide import search; apiClient.ts:301 unused export.
**Action:** revive as `agent/ApprovalGate`, triggered by plan artifacts (`implementation_plan` group already detected).
**Roadmap:** Phase 7 · Effort M.

## 2. Light mode is broken in primary chrome
**Finding:** Window title bar (`#0d0d0f`), all 36px toolbar rows (`#121214`), QuotaBanner, ScrollToBottomButton, sign-in view, and Settings fallback tabs render dark-only; the theme engine promises otherwise.
**Evidence:** screenshots 21/22/27; hex inventory (file 08); SettingsModal hardcoded classes.
**Action:** token wedge (file 18) replaces ~40 literals; theme engine writes new tokens.
**Roadmap:** Phase 1 · Effort M.

## 3. Sticky header can block the activity log toggle
**Finding:** At certain scroll offsets the sticky user-message header covers the "Worked for Xs" button — the only way to inspect agent activity for that turn.
**Evidence:** reproduced live during capture (agent-browser "covered by" error).
**Action:** 44px `scroll-margin-top` on the accordion toggle (or non-sticky user header).
**Roadmap:** Phase 4 · Effort S.

## 4. Tool failures are visually indistinguishable from successes
**Finding:** `TOOL_CALL_RESULT` always maps to `status:'completed'`; failures appear only as text inside outputs (e.g., Python tracebacks).
**Evidence:** apiClient stream handler; parseTranscript paths; reproduced error scenario.
**Action:** failed status propagation + danger verb/icon + auto-expand (file 20).
**Roadmap:** Phase 6 · Effort S-M.

## 5. PDF/Word deliverables never become artifacts
**Finding:** Classification covers xlsx/csv/images/md/plan/walkthrough only; RUN_GUIDE's advertised PDF reports surface solely as inline file pills.
**Evidence:** artifactExtraction.ts regexes.
**Action:** add `.pdf/.docx` → document type + viewer already supports both (embed / download card).
**Roadmap:** Phase 7 · Effort S.

## 6. No focus-visible system; modals don't trap focus
**Finding:** Rings exist on ~3 surfaces; SettingsModal/Lightbox/context menu are portals without traps; ~60% of interactive surface is clickable divs.
**Evidence:** file 14 audit.
**Action:** a11y.css + primitives own focus/trap; convert divs to buttons during component migration.
**Roadmap:** Phases 3–9 · Effort M (amortized).

## 7. Tool-call grouping is implemented but disabled
**Finding:** `groupToolEntries()` returns entries ungrouped; `command_group`/`edit_group`/`exploration_group` render paths are unreachable. Long tool runs render as unbounded lists.
**Evidence:** TaskWorkLogAccordion source.
**Action:** re-enable (or delete the ~200 lines); grouped rows are specified in file 20.
**Roadmap:** Phase 6 · Effort S (flip + QA) — **highest impact-to-effort ratio in this list**.

## 8. Two autoscroll thresholds fight during streaming
**Finding:** 20px (useScrollToBottom) vs 80px (useChatStream) produce inconsistent follow/jump behavior.
**Evidence:** both hooks' constants; behavioral note in file 09.
**Action:** single exported threshold (20px).
**Roadmap:** Phase 2 · Effort S.

## 9. Contrast of muted text fails WCAG AA
**Finding:** `--text-muted #71717A` ≈ 4.0:1 on `#101010` (3.7:1 on surface); 9.5–11px badges compound it.
**Evidence:** file 14 measured pairs.
**Action:** token raise (dark `#8E8E96`, light `#5F5F66`) — already in file 18.
**Roadmap:** Phase 1 · Effort S.

## 10. `retryLoadHistory` may not re-trigger the fetch
**Finding:** Retry resets flags but the transcript effect's dependency array doesn't include them — button can no-op.
**Evidence:** useChatStream effect deps; noted in file 09.
**Action:** include a retry counter in deps or imperative refetch.
**Roadmap:** Phase 2 · Effort S.

## 11. Streaming markdown re-parse risk on long answers
**Finding:** the growing message string re-renders through remark/rehype per rAF flush; long audit reports may jank late in turns.
**Evidence:** static analysis (file 13 P1/P2); measurement plan included.
**Action:** profile with the mock harness; if needed, paragraph-level memoization of parsed blocks.
**Roadmap:** Phase 9 · Effort M.

## 12. Duplicate/conflicting affordances erode trust in the shell
**Finding:** two different buttons titled "Collapse sidebar" (left & right panels); minimize-styled button toggles sidebar; close-styled button resets session; File/View/Window menus and back/forward buttons are dead.
**Evidence:** live reproduction + code (file 09).
**Action:** honest tooltips, real menus or removal, disabled states for no-op buttons.
**Roadmap:** Phase 4 · Effort S.

---

## Quick-win batch (ship in a day, high perceived quality)

1. scroll-margin fix (#3) · 2. threshold unify (#8) · 3. muted-token raise (#9) · 4. QuotaBanner/ScrollToBottom theming (#2 partial) · 5. grouping flip (#7) · 6. tooltip honesty (#12) · 7. delete dead `showTasksBar`/`fetchUploads` (file 12).
