# 10 — State Matrix

Existing states verified in code and live captures. ✅ = exists, ⚠️ = partial/inconsistent, ❌ = missing.

## Buttons

| Component | Default | Hover | Focus | Active | Loading | Disabled | Error | Success |
|---|---|---|---|---|---|---|---|---|
| Send (composer) | `bg-zinc-900`/dark:white circle, Send icon | `hover:bg-zinc-800` | (none distinct) | — | — | empty input: `disabled:opacity-40` zinc-200 | — | — |
| Queue (streaming+text) | same circle, ArrowUp | same | ⚠️ none | — | — | — | — | — |
| Stop (streaming+empty) | `bg-zinc-100`/`#242424` circle, red ■ | `hover:bg-zinc-200` | ⚠️ none | — | — | — | — | — |
| Attach (+) | ghost icon btn | `hover:bg-zinc-200/80` | ⚠️ none | — | `Loader2` spinner replaces + | `disabled:opacity-40` | ⚠️ upload error only in chip | — |
| New Conversation | bordered row, Plus | bg deepen | ⚠️ none | — | — | — | — | — |
| Settings rows / nav items | transparent | `hover:bg-zinc-200/60` | ⚠️ | — | — | — | — | active = `bg-zinc-200/80 font-medium` |
| Pagination pills | bordered pill | `hover:bg-[var(--bg-hover)]` | ⚠️ | — | spinner inside pill | none (click guard) | — | — |
| Proceed (plan) | `#1a73e8` rounded-lg | `#1557b0` | ⚠️ | `#174ea6` | — | — | — | "Implemented" emerald chip |
| Danger buttons | red variants | deepen | ⚠️ | `active:scale-[0.99]` (some) | — | `disabled:opacity-50` | — | — |
| Icon buttons (viewer/toolbars) | ghost | `hover:bg-*` + icon brighten | ⚠️ mostly none | — | — | ⚠️ ad-hoc | — | — |

**Systemic gaps:** focus-visible rings are rare (`focus-visible:ring-1` exists on history rows and inputs only); no `aria-busy`; success feedback limited to copy-✓ swaps.

## Inputs

| Component | Default | Hover | Focus | Filled | Loading | Disabled | Error |
|---|---|---|---|---|---|---|---|
| Composer textarea | surface card, border zinc-200/`white/[0.08]` | border zinc-300 | `focus-within:border-zinc-400`/`white/[0.2]` + auto-grow | — | — | `opacity-65 select-none` + placeholder swap | — |
| Filter inputs (sidebar/panel) | `h-7 bg-muted/40` | — | focus bg swap | ✕ clear appears | — | — | — |
| Search (history) | rounded-xl card | — | `focus-within:border-zinc-400` | ✕ clear | — | — | — |
| Hex ColorField | swatch + mono input | — | ⚠️ | "Custom" preset appears | — | — | ⚠️ invalid hex unhandled |
| Rename input (sidebar) | inline in row | — | auto-focused | — | — | — | — |
| File input | hidden behind + button | — | — | — | chip state | — | chip `error` flag (unused path) |

## Messages

| Element | States |
|---|---|
| UserMessage | default · hover (actions fade in) · expanded/collapsed (>3 lines → line-clamp-3 + click-to-expand, guarded against text selection) · streaming n/a |
| AssistantMessage | streaming (math/fence auto-balance, unhighlighted code, artifacts suppressed) · completed · error (Terminated/Disconnected + details + Continue) · aborted (Stopped + "stopped by user after Ns") · background-completed (unread dot on session) |
| Markdown islands | CodeBlock: collapsed (>45 lines, fade + "Show N more") / expanded / copied; table: copied; callout variants; badge variants; mermaid: streaming-pill / rendered / zoomed / code-view / fallback card |

## Work log / tool calls

| Element | States |
|---|---|
| Accordion | collapsed ("Worked for Xs") · expanded · streaming ("Thinking for Xs…" live + dots / "Working…" dots) |
| Thought row | collapsed toggle · expanded markdown card (auto-scroll ≤50px) · running (live seconds) · completed |
| Tool row | running (sky spinner + present-tense verb) · completed (past tense + duration) · cancelled ("Ran (Cancelled)") · expanded console (single-open) · ⚠️ **failed** — no distinct visual (output text only) |
| Command console | header (path + full cmd + copy) · output pre (max-h-24) · status icon Check/AlertCircle · file:// links clickable |
| FilePill | default · hover (bg + shadow glow) · active (`scale-[0.98]`) |

## Artifacts & files

| Element | States |
|---|---|
| ArtifactCard | default · hover (border + bg deepen) · streaming-suppressed (only after turn end) · type variants (spreadsheet/chart/plan/walkthrough/doc) · proceeded (plan) · ⚠️ no generating/failed states |
| FilesChangedDrawer | open (default) · collapsed · hover rows · Review action |
| Working papers row | default · hover · filtered-out · see-all expanded |
| Viewer tab | active (border+shadow) · inactive · hover close ✕ · terminal variant (amber icon) |
| File content | loading (spinner) · loaded · raw/preview · cached-instant · oversized (1.5MB banner) · unsupported (download card) · error (red tile + Download) |
| Background task | running (pulsing dot + spinner) · completed · failed (red chip) · killing (optimistic remove) |

## Sidebar / sessions

| Element | States |
|---|---|
| Session row | idle · hover (⋮ reveals) · selected (`white/[0.1]` + font-medium) · streaming (sky spinner) · unread (blue dot) · pinned (sky pin icon) · archived (hidden from list) · renaming (inline input) |
| Sections | open/closed (chevron −90°) · scroll shading top/bottom (gradient fades toggle at 4px/12px) |
| Sidebar | open · collapsed · resizing (cursor-col-resize) · width 220–450 |

## Viewer / panels

| Element | States |
|---|---|
| Right sidebar | closed · open (320–1100px) · maximized (center hidden) · resizing (direct DOM) · explorer/editor modes |
| Terminal | running (live append) · completed (chip) · failed · reconnect-fallback (fetchTaskLog) |
| Preview/Raw pill | preview active · raw active |
| Queued card | present · hover actions · injecting · count badge |

## Dialogs / menus / overlays

| Element | States |
|---|---|
| Settings modal | open/closed (fade-in 150ms) · tab active · system/light/dark · preset/custom · sign-out confirm nested overlay |
| Context menu | open (clamped) · item hover · delete-hover (red) · closed |
| Dropdown (Radix) | standard checked/unchecked/highlighted |
| Lightbox | open · zoom (css) · close (Esc/✕/backdrop) |
| ErrorBoundary fallback | error shown · retry resets |
| Quota banner | visible · dismissible · action → (no plan page exists — ⚠️ dead-end CTA) |

## Priority missing states (for redesign)

1. **Tool failure state** (row-level error icon/color + retry affordance).
2. **Artifact generating/failed states** (skeleton card while write in progress; error card on failure).
3. **Connection status** (offline/reconnecting indicator — currently only error disclosures after failure).
4. **Empty-state actions** (starter prompts; empty working-papers guidance in explorer mode).
5. **Focus-visible system** (consistent rings on all interactive elements).
6. **Drag-over states** for artifact rows → viewer (drag file from list into chat).
