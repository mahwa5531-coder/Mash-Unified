# 12 — Technical Debt & Duplication Register

Prioritized: **Critical** (breaks UX or blocks redesign) / **High** (significant effort or confusion) / **Medium** / **Low**. Nothing was fixed during this research.

## Critical

| # | Item | Evidence | Impact |
|---|---|---|---|
| C1 | **PlanApprovalModal is dead code — approval UX absent** | `grep -r "PlanApprovalModal"` → only its own file; `approvePlan()` in apiClient.ts:301 has no caller | The agent's plan-approval flow (a core audit control) has no UI. 121 lines of styled, wired code rotting. Either mount it or remove it. |
| C2 | **Light mode is visually broken in chrome regions** | `#0d0d0f` title bar, `#121214` toolbar/sidebar headers, always-dark QuotaBanner/ScrollToBottomButton/sign-in/settings-fallbacks (screenshots 21/22/27) | Theme engine promises light mode; delivery is partial. Blocks any light-mode QA. |
| C3 | **Sticky user header covers the work-log toggle** | Reproduced live: "Worked for 46s" unclickable under sticky `bg-[var(--bg-app)]/90 backdrop-blur-md` header at certain offsets | Users can't open the activity log for the first turn without scrolling; automation hits "covered by" errors too. |

## High

| # | Item | Evidence | Impact |
|---|---|---|---|
| H1 | Tool-call grouping disabled | `groupToolEntries()` in TaskWorkLogAccordion returns ungrouped; `command_group/exploration_group/edit_group` render paths unreachable | Long tool runs render as unbounded row lists; grouping code (~200 L) maintained for nothing. |
| H2 | Two autoscroll thresholds fight | `useScrollToBottom` 20px vs `useChatStream.isAtBottomRef` 80px | Stream can auto-follow while the hook considers the user "scrolled up" (or vice-versa) — inconsistent jump behavior. |
| H3 | `retryLoadHistory` doesn't re-trigger fetch | Transcript effect deps `[sessionId, scrollContainerRef, updatePaginationState]`; retry only flips flags | Retry button can appear to do nothing until session re-selected. |
| H4 | Tool failure invisible at row level | `TOOL_CALL_RESULT` → always `status:'completed'` (apiClient + parse paths) | Auditors can't scan for failures; must read outputs. For an audit tool this is a trust issue. |
| H5 | PDF/DOCX never become artifacts | artifactExtraction.ts classification regexes (xlsx/csv/images/plan/walkthrough/md only) | RUN_GUIDE advertises PDF reports; they never surface as cards — only file pills. |
| H6 | `Step` vs `ExecutionStep` duality + misleading file name | `utils/parseTranscript.ts` is types-only; parser lives in `lib/turns.ts`; both shapes flow through messages | Every future contributor pays a discovery cost; history re-parse paths must keep both in sync. |
| H7 | 8 "god components" = 53% of code | Sidebar 1101, RightSidebar 1285, useChatStream 1182, TaskWorkLogAccordion 1074, apiClient 1028, SettingsModal 852, AssistantMessage 775, SafeFileViewer 551 | Untestable in isolation; mixing of data/presentation (RightSidebar owns fetch + SSE + tabs + render). |
| H8 | React "unmount during render" warnings | console during research (Univer/Mermaid dynamic roots) | Latent race → potential crashed panes; needs `queueMicrotask`/effect-guard cleanup. |

## Medium

| # | Item | Evidence |
|---|---|---|
| M1 | Duplicate upload APIs | `fetchUploads` (:219) vs `fetchSessionUploads` (:954) — same endpoint, different shapes |
| M2 | Dead state | `showTasksBar` in useChatStream (setter never called) |
| M3 | Unused `clearSessionQueue` export | apiClient :692 — discardQueued is local-only (server queue persists → surprise auto-sends) |
| M4 | Sidebar width not persisted | resets to 260px each reload (localStorage used for everything else) |
| M5 | localStorage prefix split | `nexau_*` (5 keys) vs `mash_*` (3 keys) |
| M6 | `custom-scrollbar` no-op class | 6+ usages style nothing |
| M7 | QuotaBanner typo | `bg-[#1f1f1]` (invalid 6-digit) |
| M8 | Spelling drift | "Cancelled" vs "Canceled" in tool rows |
| M9 | Dead window affordances | File/View/Window menus, Back/Forward buttons — no handlers |
| M10 | Duplicate title "Collapse sidebar" | Left PanelLeft and right PanelRight both titled "Collapse sidebar" |
| M11 | `th` styles differ between the two markdown stacks | AssistantMessage vs TableContainer defaults |
| M12 | Background-session step loss | `finally` background drain merges content/thoughts but not `steps` — steps appear only after transcript refetch |
| M13 | Session titles "now" flood | mock/live: relative times all "now" (formatRelativeTime buckets) — actually correct behavior, but the sidebar's 4 items showing identical "now" hints the label adds little |
| M14 | Settings fallback tabs dark-only | General/Application/Browser panes hardcode dark styles in themed modal |
| M15 | Upload error path unused | `AttachedFile.error` field never set by upload handler |

## Low

| # | Item | Evidence |
|---|---|---|
| L1 | Console warnings: Univer 404s cached | early 404 responses cached in fileContentMemoryCache until eviction |
| L2 | `EMPTY_ARTIFACTS` module singleton | fine, but signals missing memo plumbing |
| L3 | `generateCleanSessionTitle` heuristic sprawl | 100 L of regex politeness-stripping — candidate for backend |
| L4 | `formatRelativeTime` dual epoch handling | ms vs s heuristic (>1e11) — fragile |
| L5 | Two file-icon systems in markdown | FileIcon component vs inline amber pills |
| L6 | `bg-card`/`text-card-foreground` used only in RightSidebar | shadcn tokens half-adopted |
| L7 | `CodeBlock` custom highlighter | 181 L regex tokenizer replaces Prism — works, but keyword lists are static and untested for SQL-heavy audit output |
| L8 | Stock README | frontend/README.md is create-next-app boilerplate |

## Unused / dead code summary

- `PlanApprovalModal.tsx` (entire file) · `approvePlan` (apiClient) · `showTasksBar` · `clearSessionQueue` · `AttachedFile.error` · group-card render paths in TaskWorkLogAccordion · `fetchUploads` (shadowed duplicate) · `ErrorBoundary`'s `fallback` prop (only `fallbackRender` used) · `CollapsibleSection.rightAction` kill-all path only renders with running tasks (fine) · window menu labels · back/forward handlers.

## Components mixing business logic and presentation (worst offenders)

1. **RightSidebar** — fetch + poll + SSE + tab memory + resize math + 3 view modes + file-type dispatch.
2. **Sidebar** — polling + optimistic mutations + folder-picker fallback chain + context menu geometry + localStorage.
3. **useChatStream** — transport handling + state machine + title generation + queue policy + pagination (a hook doing a store's job).
4. **SettingsModal** — theme engine (writes DOM vars) + project CRUD + account + nested confirm.
5. **AssistantMessage** — markdown config + badge/pill lexing + lightbox + error policy + artifact ordering.
