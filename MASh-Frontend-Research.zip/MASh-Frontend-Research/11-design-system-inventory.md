# 11 — Existing Design System Inventory

## Verdict

MASh has **the beginnings of a token system, applied to ~30% of the UI**. The remaining 70% is direct Tailwind zinc classes, ~40 hardcoded hexes, and per-component magic values. There is no tokens file, no radius/spacing/motion scale, no component variant registry beyond shadcn defaults. Visual decisions are **distributed across 47 files** rather than centralized.

## What exists

### CSS custom properties (`src/app/globals.css`)

| Token | Defined | Used by |
|---|---|---|
| `--bg-app` `--bg-surface` `--bg-hover` `--bg-active` | globals.css:11-44 (light+dark) | page, ChatCanvas, history, PlanApproval, SafeFileViewer backgrounds |
| `--border` `--border-subtle` `--border-strong` | same | hairlines, code blocks, tables |
| `--text-primary/secondary/muted` | same | prose, subtitles, metadata |
| `--accent` `--accent-hover` `--accent-soft` | same | spinners, welcome icon, links, retry button, PlanApproval buttons |
| `--font-sans` `--font-mono` | `@theme` | body + all `font-mono` usages |
| `--color-border` | `@theme` alias | Radix components via `border` utility |

**Runtime theme engine** (SettingsModal) additionally writes `--bg-app`, `--bg-surface`, `--text-primary`, `--accent` at runtime from 6 presets + custom hexes, persisted in localStorage `mash_theme_settings`. It toggles `<html>` `class="dark"` + `data-theme`.

### shadcn/Radix primitives (`src/components/ui/`)

11 files with CVA variants — the only true component-variant registry: `button.tsx` defines `default/secondary/ghost/link` × `default/sm/lg/icon`. These are consistently styled (zinc + dark variants).

### Reusable primitives built in-house

`CodeBlock`, `FileIcon`, `Blockquote` (10 colors), `CalloutBlockquote` (5 alert types), `TableContainer`, `ScrollToBottomButton`, `ErrorBoundary`, `CollapsibleSection` (inside RightSidebar — not extracted), `FilePill` (inside TaskWorkLogAccordion — not extracted).

## Duplication & inconsistency register

### Radius

| Value | Occurrences (approx) | Examples |
|---|---|---|
| `rounded-md` (6px) | ~40 | icon buttons, rows, tabs, toolbar buttons |
| `rounded-lg` (8px) | ~35 | menu items, buttons, console, inputs, artifact tiles |
| `rounded-xl` (12px) | ~25 | cards, callouts, diagram, settings cards, empty tiles |
| `rounded-2xl` (16px) | ~15 | modals, composer, user card, context menu, queued card |
| `rounded-[3px]/[4px]/[5px]/[6px]` | ~8 | swatches, badges, pills |

→ 9 distinct radii with no scale; same element class varies by file (menu items `rounded-lg` in Sidebar but `rounded-lg`+`h-8` vs RightSidebar's `rounded-md`+`h-7`).

### Color duplication

- **Dark surfaces**: `#141414 #141416 #151518 #161616 #161618 #161619 #181818 #18181a #18181b #1a1a1c #1a1a1d #1c1c1f #1e1e22 #1f1f1f #202022 #242424 #252528 #27272c` — 18 literals within ΔRGB ≤ 6 of each other, in 9 files. All should be 1–2 tokens (`--surface-raised`, `--surface-overlay`).
- **Accent blues**: token `#007ACC` vs `#1a73e8/#1557b0/#174ea6` (Proceed) vs `#2d86e6/#3a93f3` (QuotaBanner) vs sky-400/500 utilities — 4 blue systems.
- **Danger reds**: red-500/rose-500 Tailwind + `#dc3545/#c82333/#bd2130` (Bootstrap palette) + red-600.
- **Zinc + alpha white**: light theme uses zinc-100/200/300; dark uses `white/[0.04|0.05|0.06|0.08|0.1|0.12|0.14]` — 7 alpha steps, no mapping doc.

### Typography duplication

Font sizes used (px): 10, 10.5, 11, 11.5, 12, 12.5, 13, 13.5, 14, 15.5, 17.5, 18, 21 (+ `text-xl` welcome). Line heights: 1.5, 1.6, `[1.48]`, `[1.72]`, `[22px]`, `leading-relaxed/tight`. Mono is applied ad hoc (timestamps, counts, commands, badges, paths — but not session titles or artifact titles).

### Spacing

Padding/gap values in use: 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 7, 8 (Tailwind steps) **plus** arbitrary `py-[3.5px]`, `py-[7px]`, `pl-[28px]` (user msg action reserve), `max-w-[280px]/[240px]/[200px]` truncation widths. Row heights: `h-7 h-8 h-9 h-[30px] h-14`.

### Component-level duplication

| Pattern | Implementations |
|---|---|
| Markdown renderer config | AssistantMessage (chat stack) vs SafeFileViewer (viewer stack) — separate plugin arrays, different `th` styles (11px py-2 px-3 vs 11.5px py-2.5 px-3.5) |
| File pill | `renderFileButton` (AssistantMessage, amber) vs `FilePill` (TaskWorkLog, amber) — same visual, two code paths |
| Copy button with ✓ swap | ≥6 hand-rolled instances (CodeBlock, console, footer, user card, viewer toolbar, context menu) |
| Segmented pill (Preview/Raw) | RightSidebar + SafeFileViewer toolbar (two implementations of the same control) |
| Context menu | Sidebar's custom clamped menu vs Radix dropdown-menu (both in production tree) |
| Scroll-to-bottom logic | `useScrollToBottom` hook (20px) vs `isAtBottomRef` inside useChatStream (80px) |
| File fetch | `fetchFileContent` + LRU cache vs `fetchExcelData` (separate, uncached) |
| Upload list | `fetchUploads` vs `fetchSessionUploads` (same endpoint, different return shapes) |
| Loading spinner + label | ≥5 bespoke layouts |
| Empty-state card | RightSidebar editor empty vs explorer italic line vs ChatCanvas welcome — three unrelated designs |

## Dead/vestigial styling

- `custom-scrollbar` class: referenced 6+ times, styles nothing (scrollbars are globally hidden).
- `QuotaBanner` typo `bg-[#1f1f1]` (6-digit truncated — compiles as-is in TW4, silently wrong).
- `shadow-2xs` (non-standard utility name, works only if defined; otherwise dropped).
- SettingsModal fallback tabs (General/Application/Browser) hardcode `text-white` + `#18181b` cards — dark-only inside a theme-aware modal.

## Summary matrix

| Layer | Exists? | Coherent? | Centralized? |
|---|---|---|---|
| Color tokens (surfaces/text/accent) | ✅ (12 vars) | ⚠️ overridden by zinc + 40 hexes | ❌ (globals.css + SettingsModal runtime + literals) |
| Typography tokens | ⚠️ fonts only | ❌ 13 sizes, no scale | ❌ |
| Spacing tokens | ❌ | ⚠️ mostly Tailwind steps | n/a |
| Radius tokens | ❌ | ❌ 9 values | n/a |
| Shadow tokens | ❌ | ⚠️ ladder is intuitive | ❌ |
| Motion tokens | ❌ | ⚠️ 150/200ms conventions | ❌ |
| Dark mode | ✅ dual mechanism | ❌ (class+data-theme+runtime vars+hardcoded) | ❌ |
| Component variants | ⚠️ shadcn only | ✅ for ui/* | ⚠️ |
| Icons | ✅ lucide + 2 custom | ✅ | ✅ |
