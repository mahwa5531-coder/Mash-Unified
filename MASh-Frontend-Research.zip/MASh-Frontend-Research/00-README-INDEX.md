# MASh Frontend — Complete Discovery, Reverse Engineering & Design Research Package

**Repository analyzed:** `https://github.com/mahwa5531-coder/Mash-Unified` (folder `frontend/`)
**Date of research:** 2026-09-27
**Method:** Full static code read of all 47 source files (~13.3K lines) + live run of the application (Next.js dev server) with a scripted mock connector backend + 28 annotated UI screenshots + visual model verification of every capture + external reference research.
**Zero modifications were made to the repository.** The only artifact created outside this package was a mock inspection server used to drive UI states for screenshots (documented in `27-open-questions-and-assumptions.md`).

---

## What is MASh?

MASh is an **enterprise AI Audit Operating System** — a desktop-grade chat interface where an AI agent (NexAU runtime, bridged by a local FastAPI "connector") performs Indian statutory audit work: vouching, Benford's Law analysis, Monetary Unit Sampling, and production of real deliverables (Excel working papers, CSV, PDF, charts, audit reports).

---

## Document Map (read in this order for a full picture)

| # | File | Covers (Task Part) | Content |
|---|------|--------------------|---------|
| 01 | `01-executive-summary.md` | 24.1 | TL;DR of the whole research |
| 02 | `02-existing-frontend-architecture.md` | 1 | Framework, state, styling, API, streaming, auth, persistence + architecture map |
| 03 | `03-repository-structure.md` | 24.3 | Full file tree with per-file purpose |
| 04 | `04-component-inventory-and-tree.md` | 2 | Every component: purpose, props, state, API deps, styling + component tree |
| 05 | `05-data-flow-lifecycle.md` | 3 | Prompt → SSE → state → render lifecycles for all 10 flows |
| 06 | `06-agent-event-flow-mapping.md` | 8 | Backend SSE event → state → rendered component mapping |
| 07 | `07-screenshot-gallery.md` | 4 | All 28 screenshots, annotated with regions/components/mechanisms |
| 08 | `08-visual-audit.md` | 5 | Layout/typography/color/shape/depth/motion with concrete values |
| 09 | `09-interaction-audit.md` | 6 | Trigger → state → UI → API → final state for every interaction |
| 10 | `10-state-matrix.md` | 7 | State matrix per component + missing states |
| 11 | `11-design-system-inventory.md` | 9 | Existing tokens, where defined/used, duplication, inconsistencies |
| 12 | `12-technical-debt.md` | 10 | Prioritized debt register (Critical → Low) |
| 13 | `13-performance-findings.md` | 20 | Rendering/streaming perf analysis + what to investigate before launch |
| 14 | `14-accessibility-findings.md` | 19 | Current a11y audit + target behavior |
| 15 | `15-reference-product-research.md` | 11 | ChatGPT/Claude/Cursor/Antigravity/Linear/Raycast/VS Code pattern research |
| 16 | `16-visual-reference-board.md` | 12 | Reference image board with what-to-study annotations |
| 17 | `17-mash-design-direction.md` | 13 | Target character, philosophy, what it should(n't) feel like |
| 18 | `18-mash-design-tokens.md` | 14 | Proposed full token spec (light+dark, type, spacing, radius, shadows, motion) |
| 19 | `19-component-system.md` | 15 | Target component architecture (Foundation→Overlays) with anatomy/variants/states |
| 20 | `20-agent-chat-design-system.md` | 16 | Visual spec for every agent-chat element (tool calls, activity, streaming…) |
| 21 | `21-artifact-ux-specification.md` | 17 | Artifact cards, viewer, download, failure, grouping + chat↔viewer relationship |
| 22 | `22-app-shell-specification.md` | 18 | Target shell layout with measurements |
| 23 | `23-target-architecture.md` | 21 | Target frontend architecture (proposed, NOT implemented) |
| 24 | `24-current-to-target-component-mapping.md` | 21 | Conservative current → target component map |
| 25 | `25-implementation-roadmap.md` | 22 | Phase 0–10 plan with files/risk/testing |
| 26 | `26-visual-qa-checklist.md` | 23 | QA spec + screenshot comparison methodology |
| 27 | `27-open-questions-and-assumptions.md` | 24.28 | Assumptions, mock-server disclosure, open questions |
| 28 | `28-highest-priority-findings.md` | 24.29 | Top findings ranked |

## Image Inventory

- `images/01-…` to `images/28-…` — **28 verified screenshots of the running application** (dark mode unless stated). Each was captured from the live app and verified with a vision model.
- `images/ref-*.jpg|png` — **6 external reference images** (ChatGPT, Claude, Claude Code, Cursor, Linear) collected for the visual reference board. These are third-party screenshots gathered via image search for study purposes only.

## Critical Rule Respected

This package is a **research and understanding deliverable**. The MASh frontend was NOT redesigned, rewritten, restyled, refactored, or "improved" during this task. All design proposals (files 17–26) are **clearly-labeled forward-looking specifications** for a future redesign effort, grounded in the current implementation documented in files 02–14.
