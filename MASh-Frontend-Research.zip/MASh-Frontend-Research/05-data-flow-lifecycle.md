# 05 — Data Flow: Complete Lifecycle of a User Request

All flows verified against code (files/lines cited) and observed live during the research run.

## Flow A — Normal text response (the master flow)

```text
User types in ChatComposer textarea (auto-resize ≤220px, Enter=send / Shift+Enter=newline,
300ms isSubmittingRef double-send lock)
   ↓ handleSendClick → onSend(localPrompt)
ChatCanvas.handleSend → useChatStream.send(text)
   ↓ handleSendMessage (useChatStream.ts:539)
1. New session? → activeSid = `sess_${Date.now().toString(36)}_${random10}`
   → onSessionCreated(sid, generateCleanSessionTitle(text), repo)   [page.tsx sets state]
   → renameSession(sid, title) fire-and-forget POST /sessions/{sid}/rename
2. Currently streaming? → queuedMessage = text (local slot)
   → queueSteeringMessage POST /sessions/{sid}/queue → return (no new turn)
3. Append 2 messages to sessionStore[sid].chatMessages:
   user {role:'user', turnId, status:'completed', timestamp:'HH:MM'}
   assistant placeholder {role:'assistant', turnId, status:'running', steps:[], content:''}
   → if viewing session: setChatMessages(next), setIsStreaming(true)
   → rAF scroll-to-bottom + second scroll after 50ms
4. streamQuery(activeSid, text, handlers, context, abortController.signal)
   ↓ apiClient.ts:358
POST {BASE_URL}/stream  {session_id, messages:"<text>", context:{workspace_uri,
working_directory, section, title, custom_title, model, thinking_effort}}
   ↓ connector/app/routers/chat.py:170
   - resolves project/workspace, scaffolds Audit_Deliverables dir,
     binds sandbox work_dir, applies per-request model override
   - server.handle_streaming_request(...)  [NexAU SSETransportServer]
   ↓ SSE frames: "data: {\"type\":\"TEXT_MESSAGE_CONTENT\",\"delta\":\"…\"}\n\n"
Frontend reader loop (apiClient.ts:~470):
   response.body.getReader() + TextDecoder('utf-8')
   buffer.split("\n\n") → frames starting with "data:" → JSON.parse → event.type
   ↓ normalized callback
onToken(delta) → sessionStore[sid].tokenBuffer += delta
   → scheduleFlush(): requestAnimationFrame(flushActiveStreamBuffer)   [~16.7ms cadence]
   ↓ flush (useChatStream.ts:198)
   - pin thinkingDuration at first token
   - complete running 'thinking' steps → append to running 'text' step
   - msg.content += tokenDelta → setChatMessages (viewed session only)
   - if isAtBottomRef (≤80px from bottom) → scrollTop = scrollHeight
   ↓ React render
buildTurns(chatMessages) [O(n) memo] → ChatCanvas turn window (last 100 live)
   → AssistantMessage (memoized; re-renders while last+streaming)
   → ReactMarkdown → CodeBlock/tables/badges/pills stream progressively
   (formatMathInMarkdown auto-balances unclosed \[ \( $$ fences while streaming)
   ↓ stream ends (reader.done)
finally block (useChatStream.ts:907):
   - drain buffers; finalize steps (running→completed); msg.status = 'completed'
   - if background session: hasUnread = true (sidebar dot) else markSessionViewed POST
   - queued message? → auto re-send after 100ms  |  else GET /sessions/{sid}/queue,
     dispatch server-queued[0]
```

## Flow B — Streaming response (deltas already covered in A)

Buffer coalescing is the core: **one React state update per animation frame regardless of token rate**. Hidden-tab streams accumulate in `tokenBuffer`/`thoughtBuffer` (rAF pauses); `visibilitychange` → synchronous `flushActiveStreamBuffer()` on return. Thinking duration = turn start → first text token, pinned once.

## Flow C — Tool call

```text
TOOL_CALL_START {tool_call_id, run_id, tool_call_name}
   → onToolCall({id:`${run_id}_${rawId}`, name, args:{}, status:'running'})
   → flush pending text buffers first; complete running text/thinking steps
   → msg.tools merge-by-id; steps push {type:'tool', status:'running'}
TOOL_CALL_ARGS {delta} → per-tool arg string buffer; best-effort incremental JSON.parse
   → onToolCall({…, args: parsed, status:'running'})
TOOL_CALL_END → final JSON.parse → onToolCall (still 'running')
TOOL_CALL_RESULT {content|output|result, duration_seconds}
   → onToolCall({output: stringified, status:'completed', durationSeconds})
   → TaskWorkLogAccordion renders by tool name:
     run_shell_command → "Running/Ran (Cancelled)" + mono cmd + expandable console
     read_file/view_file → "Analyzing/Analyzed" + FilePill + #L12-80
     replace/write_file → "Editing/Edited" + FilePill + +n −n
     search/glob/grep → "Searching/Searched" + pattern + "N results"
     …(see 20-agent-chat-design-system for the full verb table)
```

## Flow D — Command execution + live terminal

- In-chat: tool result rendered in the accordion's console (`max-h-24` output, `file:///` links clickable).
- Right sidebar: `Audit Procedures in Progress` rows (3s poll `GET /api/tasks`); clicking opens a terminal tab; `RightSidebar` opens `EventSource(/api/tasks/{id}/stream)` — 100ms buffered flush, `[DONE]` sentinel, auto-scroll only within 60px of bottom, fallback to `fetchTaskLog` (`GET /tasks/{id}/log`) on error; Cancel Task → `killBackgroundTask(pid)`.

## Flow E — File operation (read/write/edit → FilesChangedDrawer)

```text
write_file/replace_file/multiedit/apply_patch tool calls
   → artifactExtraction.extractEditedFiles(msg):
     isReplace/isWrite/multiedit/patch matchers on tool names
     line counts from new_string vs old_string | edits[] | CodeContent | patch hunks
     excludes *.md, scratch/, .nexau/, tmp/ …
     groups by cleanPath, accumulates +added/−deleted
   → FilesChangedDrawer: "N files changed  +A −D" (starts open), rows open file in viewer
```

## Flow F — Generated artifact

```text
Tool args contain path-ish keys (TargetFile|AbsolutePath|file_path|path|…)
   → extractArtifacts classifies by regex:
     .xlsx/.xls/.csv → spreadsheet; .png/.jpg/.svg/.webp → chart;
     *implementation_plan*|plan.md → plan; *walkthrough* → walkthrough; .md → doc
     ⚠️ .pdf and .docx are NOT classified (gap)
   → summary from args.ArtifactMetadata.Summary else type default
   → useChatStream.artifactsByTurnMsg (WeakMap cached; frozen during streaming)
   → canonical-group suppression: revised implementation_plan/walkthrough
     vanish from older turns, show only in latest
   → ArtifactCard: icon tile + title + tag badge (Deliverable/Visual Chart/Plan/…)
     + summary + Download (xlsx) / Proceed (plan, Ctrl+↵)
   → click → page.handleOpenFile → RightSidebar opens tab + fetchFileContent
     (LRU-25 cache + in-flight dedup; Excel → /files/univer → Univer render)
```

## Flow G — Error

```text
RUN_ERROR | TRANSPORT_ERROR → onError(formatErrorMessage(msg), errId)
   formatErrorMessage maps: 404→"model unavailable…", 429/quota→"Rate limit…",
   401→"API authentication failed…"; truncates >200 chars → 197+"…"
   → msg.error/errorId, status:'error' (persists through finally)
   → AssistantMessage error disclosure: "Terminated" (rose) + chevron
     → expanded: mono box + errorId + Copy + Continue (onContinue)
   → ChatCanvas also regex-matches the error text for quota keywords
     (quota exceeded|rate limit|429…) → QuotaBanner "Baseline model quota reached"
```

## Flow H — Cancellation

```text
Stop button (composer, streaming+empty input) → handleStop (useChatStream.ts:1016)
   → flush buffers → running steps → 'cancelled' → msg.status='aborted'
   → abortController.abort() + POST /stop {session_id, force:true} (server kill)
   → streamQuery catch sees signal.aborted → resolves silently
   → AssistantMessage aborted disclosure: "Stopped" + "stopped by user after Ns"
Server-side disconnect: connector raises CancelledError on request.is_disconnected()
   → handle_stop_request(force) → agent terminated immediately
```

## Flow I — Reconnect

There is **no automatic stream resumption**. Protections: 5-minute stall watchdog (`STREAM_IDLE_TIMEOUT_MS=300000`) fed by server 15s keepalives; offline detection; `safeFetch` retries GET/HEAD once after 350ms (synthetic 503 on failure); transcript refetch on session re-entry recovers committed state. A dropped mid-turn stream = error disclosure; user must resend (Continue button re-prompts).

## Flow J — File upload

```text
Paste / drag-drop / "+" button (accept="image/*,.xlsx,.xls,.csv,.pdf,.txt,.json")
   → uploadSessionFile POST /api/uploads/{sid} (multipart "file")
   → chip with previewUrl (images) or Paperclip + name + ✕
   → on send: text defaults to "Please inspect and analyze the attached audit documents:"
     and "[Attached file: path]" markers are appended to the outgoing message
```

## Flow K — Viewer opening

```text
Entry points: ArtifactCard click · FilePill in chat · Working Papers row ·
              FilesChangedDrawer row · image lightbox "Open in Sidebar"
   → page.handleOpenFile(path) → isRightSidebarOpen=true, fileToOpen=path
   → RightSidebar effect: openFileTab(basename, path) — dedupe by tabId
     (img-/file- prefix) → editor mode → fetchFileContent (cache-aware)
   → SafeFileViewer dispatch by extension:
     image → <img> framed; xlsx/csv → Univer; pdf → <embed>; md → markdown preview;
     code → Monaco (readOnly, minimap>100 lines, 12.5px, vs-dark/light);
     docx/zip/exe… → download card; oversized → 1.5MB preview banner + download
```

## Flow L — History load & pagination

```text
Session selected → 0ms synchronous render from sessionStore (if cached)
   → if !isHistoryLoaded: GET /sessions/{id}/transcript?limit=100&shallow_tools=true
   → parseTranscriptLines: skip framework/compaction markers; user/assistant/tool
     branches; consecutive-assistant merge; tool outputs attach by tool_call_id;
     steps synthesized (thinking→tools→text) when backend didn't provide
   → streaming race: parsed history PREPENDED behind in-flight turns
"Load earlier turns (N older)" → fetch offset=loadedRawCount → prepend raw lines
   → full re-parse → scroll anchor preserved (prevScrollTop + ΔscrollHeight, rAF)
```
