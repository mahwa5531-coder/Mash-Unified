# 18 — MASh Design Token Specification

*Proposed initial design system. Values are chosen to (a) preserve the current dark-mode look auditors see today (it is already close to right), (b) fix the light-mode breakage, (c) collapse the 18-hex dark-surface sprawl and 13-size type sprawl into scales. All tokens named for role, not appearance.*

## Naming

```
--m-{category}-{role}[-{state}]
e.g. --m-bg-surface, --m-text-muted, --m-border-subtle, --m-accent-hover
```
`m` prefix avoids collision with the legacy vars during migration (both can coexist; file 25 phases the swap).

## Colors

### Light

| Token | Value | Role |
|---|---|---|
| `--m-bg-app` | `#F7F8F9` | app canvas (today #F8F9FA — nudge for contrast with surface) |
| `--m-bg-surface` | `#FFFFFF` | cards, composer, code blocks, viewer |
| `--m-bg-surface-hover` | `#F1F3F5` | row/menu hover |
| `--m-bg-surface-active` | `#E9ECEF` | selected rows, pressed fills |
| `--m-bg-raised` | `#FFFFFF` | popovers/menus (with shadow) |
| `--m-bg-inset` | `#F1F3F5` | consoles, code headers, inset wells |
| `--m-border-subtle` | `#E5E7EB` | hairlines (today's value kept) |
| `--m-border` | `#D6D9DE` | standard borders, inputs |
| `--m-border-strong` | `#C7CBD1` | table rules, dividers (kept) |
| `--m-text-primary` | `#18181B` | body |
| `--m-text-secondary` | `#4B4B52` | subtitles (darkened from #52525B for AA on surface) |
| `--m-text-muted` | `#5F5F66` | metadata — fixes today's #71717A (3.0:1 on white → now 5.5:1) |
| `--m-accent` | `#007ACC` | interactive/brand (kept — VS Code lineage) |
| `--m-accent-hover` | `#0062A3` | kept |
| `--m-accent-soft` | `rgba(0,122,204,0.10)` | selected tints |
| `--m-accent-contrast` | `#FFFFFF` | text on accent |
| `--m-success` | `#059669` | verified / compliant (emerald-600 for AA) |
| `--m-success-soft` | `rgba(5,150,105,0.10)` | compliant badge fills |
| `--m-warning` | `#B45309` | caution, significant deficiency (amber-700) |
| `--m-warning-soft` | `rgba(180,83,9,0.10)` | |
| `--m-danger` | `#DC2626` | exceptions, destructive (replaces the 3 bootstrap reds) |
| `--m-danger-soft` | `rgba(220,38,38,0.10)` | |
| `--m-info` | `#0369A1` | notes, control deficiency (sky-700) |
| `--m-info-soft` | `rgba(3,105,161,0.10)` | |
| `--m-running` | `#0284C7` | spinner/progress (sky-600) |
| `--m-focus-ring` | `#007ACC` | focus-visible rings |

### Dark

| Token | Value | Role / replaces |
|---|---|---|
| `--m-bg-app` | `#101012` | canvas (today #101010) |
| `--m-bg-surface` | `#141416` | cards (kept) |
| `--m-bg-surface-hover` | `rgba(255,255,255,0.05)` | kept |
| `--m-bg-surface-active` | `rgba(255,255,255,0.09)` | selected (unifies /0.08 and /0.1) |
| `--m-bg-raised` | `#1A1A1D` | **replaces #18181a/b, #1c1c1f, #1e1e22, #202022, #252528** — menus/popovers |
| `--m-bg-inset` | `rgba(255,255,255,0.03)` | consoles, wells — **replaces /0.02 /0.015 /0.03 variants** |
| `--m-bg-titlebar` | `#0D0D0F` | window chrome (kept, now tokenized) |
| `--m-bg-toolbar` | `#121214` | header rows (kept, now tokenized — fixes light mode) |
| `--m-border-subtle` | `rgba(255,255,255,0.08)` | kept |
| `--m-border` | `rgba(255,255,255,0.12)` | inputs, standard |
| `--m-border-strong` | `rgba(255,255,255,0.16)` | rules |
| `--m-text-primary` | `#ECECED` | kept |
| `--m-text-secondary` | `#A1A1AA` | kept |
| `--m-text-muted` | `#8E8E96` | **raised from #71717A** → 5.3:1 on app (AA) |
| `--m-accent` | `#2F9BE8` | interactive on dark (lightened from #007ACC for 4.6:1 contrast; brand hue preserved) |
| `--m-accent-hover` | `#1F87D6` | |
| `--m-accent-soft` | `rgba(47,155,232,0.14)` | |
| `--m-success` | `#34D399` | dark emerald (kept from today's chips) |
| `--m-success-soft` | `rgba(52,211,153,0.12)` | |
| `--m-warning` | `#FBBF24` | |
| `--m-warning-soft` | `rgba(251,191,36,0.12)` | |
| `--m-danger` | `#F87171` | |
| `--m-danger-soft` | `rgba(248,113,113,0.12)` | |
| `--m-info` | `#7DD3FC` | |
| `--m-info-soft` | `rgba(125,211,252,0.12)` | |
| `--m-running` | `#38BDF8` | spinner |
| `--m-focus-ring` | `#2F9BE8` | |
| `--m-shadow-key` | `rgba(0,0,0,0.55)` | dark shadows need explicit alpha (today's insight) |

Semantic mapping to audit badges: COMPLIANT/PASS→success · EXCEPTION/MATERIAL WEAKNESS/FAIL→danger · SIGNIFICANT DEFICIENCY/HIGH RISK/WARNING/CAUTION→warning · CONTROL DEFICIENCY→info · MEDIUM/LOW RISK/NOTE→neutral (text-muted). This codifies today's ad-hoc mapping (file 08 §Color).

## Typography

| Role | Value | Replaces |
|---|---|---|
| `--m-font-sans` | `Inter, -apple-system, …` (kept) | — |
| `--m-font-mono` | `Fira Code, Consolas, Menlo…` (kept) | — |
| `--m-text-display` | 20px / 1.3 / 600 | welcome title (today text-xl) |
| `--m-text-heading` | 16px / 1.4 / 600 | modal H2 (18→16), markdown h2 |
| `--m-text-subheading` | 14px / 1.5 / 600 | markdown h3/h4, card titles |
| `--m-text-body` | 14px / 1.65 / 400 | prose (today 14/1.72 — tightened) |
| `--m-text-body-sm` | 13px / 1.55 / 400 | list items, rows (today 13 & 13.5 unify) |
| `--m-text-caption` | 12px / 1.5 / 400 | subtitles, hints (today 11.5/12/12.5 unify) |
| `--m-text-label` | 11px / 1.4 / 600 / 0.06em uppercase tracking | section labels (today's idiom, formalized) |
| `--m-text-mono` | 12px / 1.6 mono | ALL mono usage (today 10–12.5px, 6 values) |
| `--m-text-mono-sm` | 11px / 1.5 mono | gutters, durations, badges |
| markdown h1 | 20px/600 + border-b (from 21px) | |
| table th | 11px label style; td 12.5px (numeric → mono right) | kept, formalized |

## Spacing

4px base grid (Tailwind steps retained but constrained):

```
--m-space-1: 4px    (icon gaps, chip padding-y)
--m-space-2: 8px    (row inner padding, related-element gaps)
--m-space-3: 12px   (card padding-x, list gaps)
--m-space-4: 16px   (card padding, block spacing)
--m-space-5: 24px   (section spacing, markdown block top)
--m-space-6: 32px   (empty-state padding, modal section)
--m-space-7: 48px   (welcome block)
```
Component rules: composer inner `p-3` (12px) kept; turn gaps `space-y-3.5` → 12px; toolbar heights fixed: titlebar 28 / toolbar 36 / sub-header 32 / status strip 24 (new).

## Radius

```
--m-radius-xs: 4px   (badges, swatches)
--m-radius-sm: 6px   (chips, pills, small buttons)
--m-radius-md: 8px   (buttons, inputs, rows, consoles)
--m-radius-lg: 12px  (cards, tiles, callouts)
--m-radius-xl: 16px  (modals, composer, user cards)
--m-radius-full: 9999px (status dots, count pills)
```
Eliminates `rounded-[3px]/[4px]/[5px]/[6px]` arbitrary values (9 → 6 steps).

## Shadows

Only three levels + one dark-mode rule:

```
--m-shadow-sm: 0 1px 2px rgba(0,0,0,0.10)                    (cards; dark: 0 1px 2px rgba(0,0,0,0.55))
--m-shadow-md: 0 4px 16px rgba(0,0,0,0.14)                  (popovers, dropdowns; dark ×0.6 alpha)
--m-shadow-lg: 0 25px 60px -15px rgba(0,0,0,0.25)           (modals; dark 0.8 — today's literal kept)
```
Plus `--m-shadow-none` for flat surfaces. Current `shadow-xs/2xs/sm` collapse into `sm`; `xl/2xl` into `md/lg`.

## Motion

| Token | Value | Used for |
|---|---|---|
| `--m-motion-instant` | 0ms | selection state, checkbox |
| `--m-motion-fast` | 120ms | hover, focus rings, icon color |
| `--m-motion-normal` | 200ms | accordions, drawers, tab switches, panel resize settle |
| `--m-motion-slow` | 300ms | modal enter/exit, maximize |
| easings | `--m-ease-out: cubic-bezier(0,0,0.2,1)` standard; `--m-ease-spring` NOT introduced (no new animation lib) |
| `prefers-reduced-motion` | all motion → instant; dots/spinners → static text ("Working…") | required (today: missing) |

Loading motifs stay: spinner (running tools), 3-dot (working/thinking), skeleton (history buffering) — each mapped to exactly one meaning.

## Z-index scale (bonus — currently ad-hoc)

```
--m-z-sticky: 20   (sticky headers — today's z-20)
--m-z-toolbar: 40  (toolbars)
--m-z-titlebar: 50 (window chrome)
--m-z-fab: 30      (scroll button)
--m-z-popover: 60  (menus)
--m-z-modal: 70    (settings)
--m-z-lightbox: 80 (today's 99999 collapsed)
--m-z-max: 90      (sign-out confirm nesting)
```

## Migration notes

1. Ship tokens as a drop-in `tokens.css` alongside legacy vars; components migrate per phase (file 25).
2. `SettingsModal` theme engine writes these tokens instead of the legacy four — presets map to the new names (OLED Black = dark with `--m-bg-app: #000000`, etc.).
3. Contrast targets: body ≥ 4.5:1, large text/graphics ≥ 3:1, verified pairs listed in file 14.
