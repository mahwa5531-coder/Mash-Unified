# 14 — Accessibility Findings

Audit of the current implementation, with concrete evidence. "Do not assume accessibility is correct merely because shadcn/Radix is used" — verified per case.

## What's done right

1. **Radix primitives** give real semantics to dropdown-menu, dialog (Settings uses createPortal + overlay but ⚠️ not Radix Dialog — see gaps), tabs, tooltip, separator, label.
2. **`aria-expanded` + `role="button"` + keyboard (Enter/Space)** on CollapsibleSection headers (RightSidebar.tsx:121-132) — the best a11y moment in the codebase.
3. **History rows**: `role="button"`, `tabIndex`, `focus-visible:ring-1 ring-[var(--accent)]` (ConversationHistory).
4. Most icon-only controls carry `title` **and** `aria-label` (window controls, panel toggles, attach, send/stop).
5. `ErrorBoundary` fallback buttons are real `<button type="button">`.
6. Breadcrumb uses nav/aria structure from the shadcn primitive.

## Gaps (with evidence)

### Keyboard navigation

- **No global shortcut map** (Ctrl+Enter plan-proceed is the only chat shortcut; Escape only closes Settings and Lightbox — not the context menu, not the quota banner).
- Tab order is DOM order — with the right sidebar mounted, focus flows through every artifact row and toolbar before the composer.
- ⚠️ Context menu (Sidebar) is mouse-first: no keyboard path to open it (no ⋮ focus trap / Menu key handling); once open, items are divs with hover styles — no arrow-key navigation, no `role="menu"`.
- The "Worked for Xs" accordion toggle is a `<button>` (good) but is coverable by the sticky header (C3) — keyboard Tab reaches it while pointer users can't click it.

### Focus visibility

- Focus rings exist on: history rows, inputs (`focus-visible:ring` in ui/input), Radix components (default).
- **Missing on**: composer send/stop/queue buttons, all sidebar rows, settings nav items, artifact cards, file pills, tool-row expanders, pagination pills, explorer rows, tab close buttons. They rely on hover affordances only — keyboard users get no visible location.
- No `:focus-visible` styling in globals.css at all.

### Dialogs / overlays

- **SettingsModal is not a focus trap**: plain `createPortal` + div overlay; Tab escapes to background; no `role="dialog"`, no `aria-modal`, no describedby; focus is not moved on open nor restored on close (Escape keydown closes, but focus is left on body).
- Same for Lightbox (Escape handled ✅, focus trap ❌), sign-out confirm overlay, and the sidebar context menu.
- Radix `dropdown-menu` IS properly trapped — the inconsistency proves the team has the tools.

### Contrast (measured against token values)

| Pair | Ratio (approx) | WCAG |
|---|---|---|
| `--text-muted` #71717A on `--bg-app` #101010 | ~4.0:1 | ❌ AA body (needs 4.5) |
| `--text-muted` on `--bg-surface` #141416 | ~3.7:1 | ❌ |
| zinc-500 icons on #101010 | ~4.6:1 | ⚠️ borderline for text, OK for 3:1 graphics |
| `--text-secondary` #A1A1AA on #101010 | ~7.2:1 | ✅ |
| `--text-primary` #ECECED on #101010 | ~13:1 | ✅ |
| Badge amber-200 on amber-500/10 (light: amber-800 on /10) | ~6+:1 | ✅ |
| Light: #18181B on #F8F9FA | ~16:1 | ✅ |
| Light muted #71717A on #F8F9FA | ~4.6:1 | ⚠️ |
| sky-400 timestamps on dark card | ~7:1 | ✅ |
| Placeholder text (default browser 50%) | varies | ⚠️ |
| Extension badges `text-[9.5px]` at muted colors | small + low contrast | ❌ doubly hard |

### Screen-reader semantics

- Streaming regions have **no `aria-live`** — screen readers get silence during generation, then a giant re-announcement per flush (worst case). Needs `aria-live="polite"` + a summary strategy.
- Tool rows / durations / spinners: status conveyed visually only (no `aria-busy`, no role="status").
- Unread dot, streaming spinner, pulsing dot: decorative images without `aria-hidden` or text alternatives.
- Tables: TableContainer adds buttons inside `<th>`-adjacent header bar (outside table) — fine; but numeric right-alignment is visual only (no `headers`/scope attributes).
- Mermaid diagrams: rendered SVG has no `role="img"` + `aria-label` (title text exists in header only).
- Console output: `<pre>` without label/context for SR.
- Toasts/✓-copy feedback: visual-only state changes.

### Buttons vs clickable divs

- Real buttons: composer actions, window controls, pagination, Proceed, settings nav, accordion headers, CollapsibleSection, CodeBlock actions, viewer toolbar.
- **Clickable divs** (no role/tabIndex/keyboard): session rows (Sidebar — hover/click only), workspace folder rows, artifact rows, task rows, tool-row expanders, file pills, breadcrumb root crumb, queued-card actions (are buttons ✅), context-menu items, user-message expand area, workspace popover items.
- Estimated: ~60% of interactive surface is mouse-only.

### Forms

- Composer textarea has `placeholder` as its only label (no aria-label — placeholder disappears on input).
- Filter inputs have placeholders only.
- Hex ColorField: color input is visually hidden behind a swatch (acceptable pattern) but has no accessible name.
- Rename input: no label, focus management ad hoc.

### Reduced motion

- **Zero handling** — `loadingEllipsis`, spinners, `animate-in` transitions, pulsing dots all run regardless of `prefers-reduced-motion`. (globals.css has no media query.)

## Target behavior (for redesign)

1. Focus management: `:focus-visible` token ring globally; move focus into modals on open, restore on close; trap in modals/menus/lightbox.
2. Replace clickable divs with buttons (or add role+tabIndex+key handlers) across the lists/pills/rows above.
3. `aria-live="polite"` region announcing turn start ("Working…"), tool summaries ("Running query — done, 1.2s"), and completion ("Response ready").
4. Escape hierarchy: lightbox → context menu → dropdown → modal (currently partial).
5. Contrast: raise `--text-muted` to ≥4.5:1 on both surfaces (e.g. dark #8E8E96 ≈ 5.4:1 on #101010); audit badge/badge-adjacent small text.
6. `prefers-reduced-motion`: disable dots/pulse/scale animations; keep opacity fades ≤150ms.
7. Label every icon-only control (most have titles — promote to aria-labels); label the composer.
8. Skip-to-content link; landmark roles (nav/main/complementary) — currently implicit at best.
9. Keyboard route to context menu (⋮ button focusable — it is a button ✅ — make menu a proper `role="menu"` with arrow keys, or switch to Radix Menu).
10. Diagram alt text from chart title; console gets `aria-label="Command output"`.
