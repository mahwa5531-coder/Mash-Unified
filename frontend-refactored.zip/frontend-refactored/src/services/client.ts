// HTTP transport core: base URL + safe fetch wrapper shared by all services.

export const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000";

// ponytail: safeFetch retries once on transient network drops ONLY for idempotent methods (GET, HEAD)
// to prevent duplicate side-effects on POST/DELETE/PATCH mutations.
export async function safeFetch(url: string, init?: RequestInit): Promise<Response> {
  const method = (init?.method || 'GET').toUpperCase();
  const isIdempotent = method === 'GET' || method === 'HEAD';
  try {
    return await fetch(url, init);
  } catch {
    if (isIdempotent) {
      await new Promise((r) => setTimeout(r, 350));
      try {
        return await fetch(url, init);
      } catch {}
    }
    return new Response(JSON.stringify({ error: "Backend unavailable" }), {
      status: 503,
      statusText: "Backend unavailable",
      headers: { "Content-Type": "application/json" }
    });
  }
}
