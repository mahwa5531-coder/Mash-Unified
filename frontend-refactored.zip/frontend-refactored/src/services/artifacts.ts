// Session artifacts: deliverable files for the explorer panel.

import { BASE_URL, safeFetch } from './client';

export interface ArtifactFileItem {
  name: string;
  path: string;
  type: 'walkthrough' | 'plan' | 'doc' | 'code';
}

export async function fetchSessionArtifacts(sessionId: string): Promise<ArtifactFileItem[]> {
  try {
    const res = await safeFetch(`${BASE_URL}/artifacts/session/${encodeURIComponent(sessionId)}`);
    if (!res.ok) return [];
    const data = await res.json();
    const files: string[] = data.files || [];
    const brainDir: string = data.brain_directory || '';
    return files.map(f => {
      const lower = f.toLowerCase();
      let type: 'walkthrough' | 'plan' | 'doc' | 'code' = 'doc';
      if (lower.includes('walkthrough')) type = 'walkthrough';
      else if (lower.includes('plan')) type = 'plan';
      else if (/\.(py|ts|tsx|js|sql|sh|ps1)$/.test(lower)) type = 'code';
      return {
        name: f,
        path: brainDir ? `${brainDir}/${f}`.replace(/\\/g, '/') : f,
        type,
      };
    });
  } catch (err) {
    console.warn("Failed to fetch session artifacts:", err);
    return [];
  }
}
