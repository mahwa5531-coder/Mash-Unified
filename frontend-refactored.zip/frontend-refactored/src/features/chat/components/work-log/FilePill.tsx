"use client";

// Clickable file chip used in tool rows + markdown output link renderer.
import React from 'react';
import { cn } from '@/lib/utils';
import FileIcon from '@/components/renderers/FileIcon';

export function FilePill({
  filename,
  filePath,
  lineRange,
  onOpenFile,
}: {
  filename: string;
  filePath: string;
  lineRange?: string | null;
  onOpenFile?: (path: string) => void;
}) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onOpenFile?.(filePath);
      }}
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-[5px] font-mono text-[12px] bg-zinc-100 hover:bg-zinc-200/90 dark:bg-[#1e1e22] dark:hover:bg-[#27272c] text-zinc-900 dark:text-zinc-200 border border-zinc-300/80 dark:border-white/[0.08] hover:border-zinc-400 dark:hover:border-white/[0.22] hover:shadow-sm dark:hover:shadow-[0_0_10px_rgba(255,255,255,0.08)] transition-all duration-150 ease-out cursor-pointer select-none shadow-xs group/file active:scale-[0.98]"
      title={`Open ${filePath}`}
    >
      <FileIcon filename={filename || filePath} size={13} className="shrink-0 group-hover/file:scale-105 transition-transform" />
      <span className="truncate max-w-[240px] font-medium text-zinc-800 dark:text-zinc-200 group-hover/file:text-zinc-950 dark:group-hover/file:text-white transition-colors">{filename}</span>
      {lineRange && (
        <span className="text-zinc-500 dark:text-zinc-400 font-mono text-[11px] shrink-0 font-normal ml-0.5">
          {lineRange}
        </span>
      )}
    </button>
  );
}

export function renderOutputWithLinks(text: string, onOpenFile?: (path: string) => void) {
  if (!text) return null;
  const linkRegex = /(file:\/\/\/[^\s\)\"\']+)/g;
  const parts = text.split(linkRegex);
  if (parts.length === 1) return text;

  return parts.map((part, idx) => {
    if (part.startsWith('file:///')) {
      const cleanPath = decodeURIComponent(part.replace(/^file:\/\/\/?/, '')).replace(/^\/([a-zA-Z]:)/, '$1');
      const basename = cleanPath.split(/[/\\]/).pop() || cleanPath;
      return (
        <button
          key={idx}
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onOpenFile?.(cleanPath);
          }}
          className="inline-flex items-center gap-1 text-sky-400 hover:text-sky-300 hover:underline cursor-pointer font-mono font-medium underline-offset-2 select-text"
          title={`Open ${cleanPath}`}
        >
          {basename}
        </button>
      );
    }
    return part;
  });
}
