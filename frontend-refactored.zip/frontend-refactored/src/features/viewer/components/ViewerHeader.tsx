"use client";

// Row-1 header: mode buttons, open-tab pills, maximize/collapse.
// Container/view split: props mirror RightSidebar identifiers.
import React, { MouseEvent as ReactMouseEvent } from 'react';
import { BookOpen, X, Terminal, Maximize2, Minimize2, PanelRight, FolderKanban } from 'lucide-react';
import FileIcon from '@/components/renderers/FileIcon';
import type { TabItem } from '../types';

interface ViewerHeaderProps {
  viewMode: 'explorer' | 'editor';
  setViewMode: React.Dispatch<React.SetStateAction<'explorer' | 'editor'>>;
  openTabs: TabItem[];
  activeTabId: string | null;
  setActiveTabId: React.Dispatch<React.SetStateAction<string | null>>;
  openSections: { artifacts: boolean; backgroundTasks: boolean };
  setOpenSections: React.Dispatch<React.SetStateAction<{ artifacts: boolean; backgroundTasks: boolean }>>;
  isMaximized: boolean;
  onToggle: () => void;
  handleToggleMaximize: () => void;
  handleCloseTab: (e: ReactMouseEvent, tabId: string) => void;
}

export function ViewerHeader({
  viewMode,
  setViewMode,
  openTabs,
  activeTabId,
  setActiveTabId,
  openSections,
  setOpenSections,
  isMaximized,
  onToggle,
  handleToggleMaximize,
  handleCloseTab,
}: ViewerHeaderProps) {
  const activeTab = openTabs.find(t => t.id === activeTabId);
  return (
            <div className="h-9 bg-[#121214] border-b border-zinc-200/70 dark:border-white/[0.06] flex items-center justify-between px-2 shrink-0 w-full overflow-hidden select-none">
        {/* Left: Quick Navigation Icons + Divider */}
        <div className="flex items-center space-x-1 shrink-0 mr-1.5">
          {/* Audit Workpapers & Overview Icon */}
          <button
            type="button"
            onClick={() => {
              setViewMode('explorer');
              setOpenSections(prev => ({ ...prev, artifacts: true }));
            }}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              viewMode === 'explorer' 
                ? 'text-zinc-100 bg-white/[0.08]' 
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04]'
            }`}
            title="Audit Workpapers & Schedules"
          >
            <FolderKanban size={14} />
          </button>

          {/* Workpaper Viewer Switch Icon */}
          <button
            type="button"
            onClick={() => {
              if (openTabs.length > 0) {
                setViewMode('editor');
              }
            }}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              viewMode === 'editor' && activeTab?.type !== 'terminal'
                ? 'text-zinc-100 bg-white/[0.08]' 
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04]'
            }`}
            title="Workpaper Viewer"
          >
            <BookOpen size={14} />
          </button>

          {/* Vertical subtle divider */}
          <div className="h-3.5 w-[1px] bg-zinc-700/60 mx-1 shrink-0" />
        </div>

        {/* Center: Open File Tabs (Clean pill style with logo, filename, and X close button) */}
        <div className="flex-1 flex items-center gap-1.5 overflow-x-auto overflow-y-hidden no-scrollbar h-full shrink min-w-0 py-1">
          {openTabs.map(tab => {
            const isActive = activeTabId === tab.id && viewMode === 'editor';
            const rawName = tab.title || tab.path || '';
            const fileName = tab.type === 'terminal' 
              ? (tab.title || 'Terminal') 
              : (rawName.split(/[/\\]/).pop() || rawName);
            return (
              <div 
                key={tab.id}
                onClick={() => { setActiveTabId(tab.id); setViewMode('editor'); }}
                className={`flex items-center gap-1.5 pl-2 pr-1.5 py-1 rounded-md text-[11.5px] transition-all cursor-pointer select-none max-w-[200px] shrink-0 font-medium group/tab ${
                  isActive 
                    ? 'bg-zinc-800 text-zinc-100 border border-white/[0.08] shadow-xs' 
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04] border border-transparent'
                }`}
                title={tab.path || fileName}
              >
                {tab.type === 'terminal' ? (
                  <Terminal size={13} className="shrink-0 text-amber-400" />
                ) : (
                  <FileIcon filename={fileName} size={13} className="shrink-0" />
                )}
                <span className="truncate font-medium flex-1">{fileName}</span>
                <button
                  type="button"
                  onClick={(e) => handleCloseTab(e, tab.id)}
                  className="p-0.5 ml-0.5 rounded text-zinc-400 hover:text-zinc-100 hover:bg-white/10 opacity-70 group-hover/tab:opacity-100 transition-opacity cursor-pointer shrink-0"
                  title="Close tab"
                  aria-label={`Close ${fileName}`}
                >
                  <X size={11} />
                </button>
              </div>
            );
          })}
          {openTabs.length === 0 && (
            <span className="text-[11px] text-zinc-500 italic truncate select-none">No file open</span>
          )}
        </div>

        {/* Right: Maximize Button beside Toggle Button */}
        <div className="flex items-center gap-1 shrink-0 ml-1.5">
          {/* Maximize Button */}
          <button
            type="button"
            onClick={handleToggleMaximize}
            className={`p-1.5 rounded-md text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.06] transition-colors cursor-pointer ${
              isMaximized ? 'text-zinc-100' : ''
            }`}
            title={isMaximized ? 'Restore sidebar width' : 'Maximize'}
          >
            {isMaximized ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
          </button>

          {/* Right Sidebar Toggle Button */}
          <button
            type="button"
            onClick={onToggle}
            className="p-1.5 rounded-md text-zinc-100 bg-white/[0.08] hover:bg-white/[0.12] transition-colors cursor-pointer"
            title="Collapse sidebar"
          >
            <PanelRight size={15} />
          </button>
        </div>
      </div>
  );
}
